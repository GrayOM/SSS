/**
 * i18n Image Loader
 *
 * - html lang 변경 감지
 * - 업로드 이미지 (img, background-image) 언어별 경로 자동 전환
 * - 게시물 / 배너 / 썸네일 / 정책 상세 공통 처리
 * - Swiper 등 레이아웃 재계산 트리거
 */
(() => {
    /**
     * ==========================================
     * 1. 이미지 경로 변환
     * ==========================================
     */
    const getTranslatedSrc = (src, lang) => {
        if (!src || !lang) return src;

        const lastDot = src.lastIndexOf('.');
        if (lastDot === -1) return src;

        const ext = src.slice(lastDot);
        const langPattern = /\.(?:[a-z]{2,3}(?:-[A-Z]{2})?)(?=\.[a-zA-Z]+$)/;

        // 기존 언어코드 제거 후 새 언어코드 추가
        const cleanBase = src.replace(langPattern, '').replace(ext, '');

        // 한국어일 경우 원본 (.ko 제거)
        if (lang === 'ko' || lang === 'ko-KR') {
            return `${cleanBase}${ext}`;
        }

        return `${cleanBase}.${lang}${ext}`;
    };

    /**
     * ==========================================
     * 2. 공통 유틸
     * ==========================================
     */
    const checkImageExists = async (url) => {
        try {
            const res = await fetch(url, {method: 'HEAD'});
            return res.ok;
        } catch {
            return false;
        }
    };

    const updateSwipers = () => {
        const swipers = window.mySwipersForMain;
        if (!Array.isArray(swipers) || swipers.length === 0) {
            console.log('Swiper 인스턴스 없음 또는 비어있음');
            return;
        }
        swipers.forEach(swiper => swiper.update());
    };

    /**
     * ==========================================
     * 3. img 태그 처리
     * ==========================================
     */
    const updateImgTags = async (lang) => {
        const imgs = Array.from(
            document.querySelectorAll(
                'img[src*="/upload/popupbanner/"], ' +
                'div#shareMediaList.lecture_video_list img[src*="/upload/board/"], ' +	// 영상 나눔
                'div.policy_alarm_detail.policy_board_detail div.detail_body img[src*="/upload/board/"], ' +	// 이벤트
                'div#policy_board_list div#realizationList img[src*="/upload/board/"], ' +    // 정책 실현
                'div.contents.policy_board.realization div.policy_board_detail img[src*="/upload/board/"]'	// 정책 실현 상세보기
            )
        );

        await Promise.all(
            imgs.map(async (img) => {
                const originalSrc = img.getAttribute('src');
                const newSrc = getTranslatedSrc(originalSrc, lang);

                if (newSrc === originalSrc) return;     // 동일 경로면 패스

                const exists = await checkImageExists(newSrc);
                if (exists) {
                    img.src = newSrc;
                } else {
                    console.log(`❌ 번역 이미지 없음 -> 원본 유지: ${originalSrc}`);
                    img.src = originalSrc;
                }
            })
        );
    };

    /**
     * ==========================================
     * 4. background-image 처리
     * ==========================================
     */
    const updateBackgroundImages = async (lang) => {
        const els = Array.from(document.querySelectorAll('[style *= "/upload/popupbanner/"]'));

        await Promise.all(
            els.map(async (el) => {
                const style = el.getAttribute('style');
                if (!style) return;

                const match = style.match(/url\(["']?(.*?)["']?\)/);
                if (!match) return;

                const originalUrl = match[1];
                const newUrl = getTranslatedSrc(originalUrl, lang);

                if (newUrl === originalUrl) return;

                const exists = await checkImageExists(newUrl);
                if (exists) {
                    el.style.backgroundImage = `url("${newUrl}")`;
                } else {
                    console.log(`❌ 번역 배경 이미지 없음, 원본 유지: ${originalUrl}`);
                    el.style.backgroundImage = `url("${originalUrl}")`;
                }
            })
        );
    };

    /**
     * ==========================================
     * 5. 언어 변경 트리거
     * ==========================================
     */
    const handleLanguageChange = (lang) => {
        console.log(`🌐 언어 변경 감지: ${lang}`);
        updateImgTags(lang);
        updateBackgroundImages(lang);
        updateSwipers();
    };

    /** html lang 속성 MutationObserver 감시 */
    const observeLangAttribute = () => {
        const observer = new MutationObserver(() => {
            const currentLang = document.documentElement.lang;
            handleLanguageChange(currentLang);
        });

        observer.observe(document.documentElement, {
            attributes: true,
            attributeFilter: ['lang'],
        });
    };

    /**
     * ==========================================
     * init
     * ==========================================
     */
    observeLangAttribute();
})();
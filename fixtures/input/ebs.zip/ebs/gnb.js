$(function(){
    var $gnbNav = $('header .gnb nav');
    var $gnbLinks = $gnbNav.find('> ul > li > a');
    var $subMenus = $gnbNav.find('.web_over_2depth');
    var $hasDepth3 = $('header .gnb nav .has-depth3');
    var subBaseHeight = 32; // 20260430 높이값 수정

    function updateNavHeight() {
        var maxHeight = subBaseHeight;
        
        $subMenus.each(function() {
            var $thisSubMenu = $(this);
            var totalExtraHeight = 0;

            // 현재 서브메뉴 내의 모든 'opened'된 3차 메뉴 높이를 합산
            $thisSubMenu.find('.has-depth3.opened').each(function() {
                var $openedDepth3 = $(this).next('.web_over_3depth');
                if ($openedDepth3.length > 0) {
                    totalExtraHeight += $openedDepth3.outerHeight() || 0;
                }
            });
            
            // 합산된 높이를 rem으로 변환하여 계산
            var calculated = subBaseHeight + (totalExtraHeight / 10 + 2.8);
            if (calculated > maxHeight) maxHeight = calculated;
        });

        if ($('.wrap').is('#main')) {
            $gnbNav.stop().animate({ "height": maxHeight + 5 + "rem" }, 300);
        } else {
            $subMenus.css('overflow', 'hidden'); 
            $subMenus.stop().animate({ "height": maxHeight + 'rem' }, 300);
        }
    }

    if ($(window).width() >= 981) {
        $gnbLinks.on('mouseenter', function () {
            var $this = $(this);
            
            // 대메뉴 이동 시 초기화 (원치 않으시면 이 줄을 삭제하세요)
            // $hasDepth3.removeClass('opened');
            
            $this.addClass('over').next('.web_over_2depth').addClass('active');
            $gnbLinks.not($this).removeClass('over');
            $subMenus.not($this.next()).removeClass('active');

            if ($('.wrap').is('#main')) {
                $this.parents('.gnb').addClass('over');
            } else {
                $gnbNav.addClass('over');
            }
            updateNavHeight();
        });

        $subMenus.on('mouseenter', function () {
            var $this = $(this);
            $this.addClass('active').prev('a').addClass('over');
            $subMenus.not($this).removeClass('active');
            $gnbLinks.not($this.prev('a')).removeClass('over');
        });

        $gnbNav.on('mouseleave', function () {
            $gnbLinks.removeClass('over');
            $hasDepth3.removeClass('opened');
            $subMenus.removeClass('active').removeClass('maintain');

            if ($('.wrap').is('#main')) {
                setTimeout(function () {
                    $('#main > header .gnb').removeClass('over');
                }, 300);
                $(this).stop().animate({ "height": "3rem" }, 300);
            } else {
                setTimeout(function(){
                    $('.wrap:not(#main) > header .gnb nav').removeClass('over');
                }, 300);
                $subMenus.stop().animate({"height":"0"}, 300);
            }
        });

        // has-depth3 오버 시 동작 수정
        $hasDepth3.on('mouseenter', function() {
            var $this = $(this);
            var $parent = $this.closest('.web_over_2depth');

            // 기존에 다른 opened를 지우는 로직(removeClass)을 제거하여 
            // 마우스를 올리는 족족 opened가 추가되도록 함
            $this.addClass('opened');
            $parent.addClass('maintain');
            
            // 추가된 높이들에 맞춰 전체 높이 재계산 (누적됨)
            updateNavHeight();
        });
    }
});
var WordFilter = function() {
    this.wordList = [];
};

WordFilter.prototype.init = function(opt) {
    var _this = this;

    var defaultOptions = {
        url: "/uploads/getWordFilterList",
        param: "COMM",
        successCallback: null,
        errorCallback: null
    };

    var settings = $.extend({}, defaultOptions, opt);

    $.ajax({
        url: settings.url,
        data: {rwTgDsCd: settings.param},
        type: "get",
        dataType: "json",
        async: false,
        cache: false,
        success: function(data) {
            _this.wordList = data;
            if (settings.successCallback) {
                settings.successCallback(data);
            }
        },
        error: function(err) {
            if (settings.errorCallback) {
                settings.errorCallback(err);
            }
        }
    });
};

WordFilter.prototype.check = function(txt) {
    if (txt === undefined) {
        txt = "";
    }

    var result = this.wordList.filter(function(word) {
        return txt.indexOf(word.rwNm) > -1;
    });

    if (result.length) {
        var forbiddenWord = result[0].rwNm;
        alert(forbiddenWord + " 은(는) 금지어입니다.");
        return false;
    } else {
        return true;
    }
};
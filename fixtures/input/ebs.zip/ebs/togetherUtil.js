function gfn_makePaging(currentPage, totalRowSize, pageRowSize, pageBlockSize, pagingDivId, pagingFuncNm) {
    var totalPageBlockSize = 0;
    var currentBlockPage = 0;
    var totalPage = 0;
    var startPage = 0;
    var endPage = 0;
    var pagingHtml = "";

    if (currentPage == "") currentPage = 1;
    if (pageRowSize == "") pageRowSize = 15;

    totalPage = Math.ceil(totalRowSize / pageRowSize);
    totalPageBlockSize = Math.ceil(totalPage / pageBlockSize);
    currentBlockPage = Math.ceil(currentPage / pageBlockSize);

    if (currentBlockPage > totalPageBlockSize) currentBlockPage = totalPageBlockSize;

    startPage = ((currentBlockPage - 1) * pageBlockSize) + 1;
    endPage = startPage + pageBlockSize - 1;

    if (startPage < 1) startPage = 1;
    if (endPage > totalPage) endPage = totalPage;
    if (endPage < 1) endPage = 1;

    pagingHtml += '<ul>';

    if (currentBlockPage > 1) {
        pagingHtml += '<li><a href="javascript:pageMove(\'1\');" class="first"></a></li>';
        pagingHtml += '<li><a href="javascript:pageMove(\'' + (startPage - 1) + '\');" class="before"></a></li>';
    }

    for (var i = startPage; i <= endPage; i++) {
        if (i == currentPage) {
            pagingHtml += '<li class="on"><a href="javascript:;" class="page">' + i + '</a></li>';
        } else {
            pagingHtml += '<li><a href="javascript:pageMove(\'' + i + '\');" class="page">' + i + '</a></li>';
        }
    }

    if (currentBlockPage < totalPageBlockSize) {
        pagingHtml += '<li><a href="javascript:pageMove(\'' + (endPage + 1) + '\');" class="next"></a></li>';
        pagingHtml += '<li><a href="javascript:pageMove(\'' + totalPage + '\');" class="last"></a></li>';
    }

    pagingHtml += '</ul>';

    if (pagingFuncNm != undefined) pagingHtml = pagingHtml.replace(/pageMove/g, pagingFuncNm);

    $("#" + pagingDivId).html(pagingHtml);
    $("#current_" + pagingDivId).text(currentPage); //현재페이지
    $("#total_" + pagingDivId).text(totalPage); //총페이지
}


/**
* gfn_fetchData('get', '/dataRoom/ListAjax', 'TalkList', 'filterForm', 'html');
* */
function gfn_fetchData(type, url, targetElementId, formName, dataType, onSuccess) {
    $.ajax({
        type: type,
        url: url,
        data: $(`[name="${formName}"]`).serialize(),
        dataType: dataType,
        beforeSend: function() {
            //console.log("gfn_fetchData beforeSend");
        },
        success: function(response) {
            //console.log("gfn_fetchData success");
            const targetElement = $(`#${targetElementId}`);
            targetElement.fadeOut(50, function() {
                targetElement.html(response).fadeIn(50);
                if (onSuccess) {
                    onSuccess();
                }
            });
        },
        complete: function() {
            //console.log("gfn_fetchData complete");
        },
        error: function(jqXHR) {
            // Handle error here
        }
    });
}

function updateHiddenInputs() {
    console.log("updateHiddenInputs enter");
    const hiddenUserTotal = document.querySelector("#hidden_user_total");
    const hiddenUserStudent = document.querySelector("#hidden_user_student");
    const hiddenUserParents = document.querySelector("#hidden_user_parents");
    const hiddenUserTeacher = document.querySelector("#hidden_user_teacher");
    const hiddenUserNormal = document.querySelector("#hidden_user_normal");

    const allCheckbox = document.querySelector('#userTypeTotalChckCd');
    hiddenUserTotal.value = allCheckbox.checked ? "true" : "false";
    hiddenUserStudent.value = document.querySelector("#userTypeStuChckCd").checked ? "true" : "false";
    hiddenUserParents.value = document.querySelector("#userTypeParentChckCd").checked ? "true" : "false";
    hiddenUserTeacher.value = document.querySelector("#userTypeTeacherChckCd").checked ? "true" : "false";
    hiddenUserNormal.value = document.querySelector("#userTypeGeneralChckCd").checked ? "true" : "false";
    
    const hiddenPropTotal = document.querySelector("#hidden_prop_total");
    const hiddenPropProposal = document.querySelector("#hidden_prop_proposal");
    const hiddenPropDiscussion = document.querySelector("#hidden_prop_discussion");
}

function gfn_hasQueryParams(url) {
    const questionMarkIndex = url.indexOf('?');
    return !(questionMarkIndex === -1 || questionMarkIndex === url.length - 1);
}

function gfn_updateQueryStringParameter(key, value) {
    const uri = window.location.href;
    const re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
    const separator = uri.indexOf("?") !== -1 ? "&" : "?";

    if (uri.match(re)) {
        return uri.replace(re, "$1" + key + "=" + value + "$2");
    } else {
        return uri + separator + key + "=" + value;
    }
}

function gfn_removeAllQueryStringParameter() {
    let url = new URL(window.location.href);
    let params = new URLSearchParams(url.search);

    let newParams = new URLSearchParams();
    if (params.has('srchKeyword')) newParams.set('srchKeyword', params.get('srchKeyword'));
    if (params.has('sortType')) newParams.set('sortType', params.get('sortType'));
    if (params.has('dataPageNum')) newParams.set('dataPageNum', params.get('dataPageNum'));
    if (params.has('pageNum')) newParams.set('pageNum', params.get('pageNum'));

    let newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
    if (newParams.toString()) {
        newUrl += '?' + newParams.toString();
    }
    history.pushState({}, '', newUrl);
}
function gfn_removeQueryStringParameter(key) {
    var uri = window.location.href;
    var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i");
    if (uri.match(re)) {
        uri = uri.replace(re, function($0, $1, $2) {
            if ($2==="&") {
                return $1;
            } else {
                return "";
            }
        });
    }
    history.pushState(null, "", uri);
}

function gfn_pushHistory(key, value) {
    history.pushState(null, "", gfn_updateQueryStringParameter(key, value));
}

function gfn_getFileExtension(filename) {
    return filename.split('.').pop().toLowerCase();
}

function gfn_delCmt(pstCmtId,pstId){
    if (confirm("댓글을 삭제하시겠습니까?")) {
        $.ajax({
            type: 'POST',
            url: '/comment/deleteComment',
            data: JSON.stringify({"pstCmtId": pstCmtId, "pstId": pstId}),
            contentType: "application/json",
            success: function (result) {
                alert("댓글이 삭제 되었습니다.");
                //$('[name="page_num"]').val(1);
                //gfn_pushHistory("page_num", 1);
                fn_commentListAjax();
                $("#cmtCnt").text(result);
            },
            error: function(xhr, status, error) {
                if(xhr.status === 401) { // 401 Unauthorized 응답을 확인합니다.
                    // 로그인 페이지로 리디렉션합니다.
                    alert("자신이 쓴 댓글이 아닙니다.");
                } else {
                    // 다른 HTTP 에러에 대한 처리
                    alert("처리 중 에러 발생");
                }
            }
        });
    }
}

function gfn_getUrlParameters() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.toString();
}

function gfn_createBackParam() {
    const urlParams = new URLSearchParams(window.location.search);
    // pstId 파라미터를 제거합니다.
    urlParams.delete("pstId");
    urlParams.delete("page_num");
    return urlParams.toString();
}

$(function(){
    $('.professor_review_board').find('.bt.txt.s.f_r').click(function(){
        $('.popup.bbs').removeClass('hide');
    });

    $('.popup.bbs').find('.bt.ico.x').click(function(){
        $('.popup.bbs').addClass('hide');
    });
});


/******************************************************
 * Description :  maxLengthCheck
 *******************************************************/
function gfn_maxLengthCheck(object){
    if(object.value.length > object.maxLength) {
        object.value = object.value.slice(0, object.maxLength);
    }
}

/******************************************************
 * Description :  nvl 처리
 *******************************************************/
function gfn_nvl(A,B){
    if(gfn_isNull(A) || gfn_isUndefined(A)){
        return B;
    }else{
        return A;
    }
}

function gfn_isUndefined(value){
    if(typeof(value)==undefined || typeof(value)=="undefined"||value=="undefiend"||value==undefined){
        return true;
    }
    return false;
}

/******************************************************
 * Description :  Ajax Request 공통함수
 * @param:  pUrl : 요청URL
 * @param:  pMethod : 요청메소드(get, post)
 * @param:  pParam : 파라메터
 * @param:  pCallback : 콜백함수
 * @return :  void
 *******************************************************/
function gfn_Ajax(pUrl, pMethod, pParam, pCallback){
    $.ajax({
        type:pMethod,
        url:pUrl,
        data:pParam,
        dataType:"json",
        success:function(result){
            //var call = eval(pCallback);
            var call = window[pCallback];
            call;
        },error:function(request, status, error){
            console.log("요청하신 페이지에 문제가 발생했습니다." + " status:: "+status+"  error::" + error);
        }
    });
}

/******************************************************
 * Description :  Ajax Request 공통함수 (json ContentType)
 * @param:  pUrl : 요청URL
 * @param:  pMethod : 요청메소드(get, post)
 * @param:  pParam : 파라메터
 * @param:  pCallback : 콜백함수
 * @return :  void
 *******************************************************/
function gfn_AjaxJson(pUrl, pMethod, pParam, pCallback){
    $.ajax({
        type:pMethod,
        url:pUrl,
        data:pParam,
        dataType:"json",
        contentType:"application/json",
        success:function(result){
            //var call = eval(pCallback);
            var call = window[pCallback];
            call;
        },error:function(request, status, error){
            console.log("요청하신 페이지에 문제가 발생했습니다."+ " status:: "+status+"  error::" + error);
        }
    });
}

/******************************************************
 * Description :  팝업창를 화면 중앙에 띄우기 위한 함수
 * @param:  pUrl : 팝업창 URL
 * @param:  width : 팝업창 넓이
 * @param:  height : 팝업창 높이
 * @return :  void
 *******************************************************/
function gfn_OpenWindow(url, width, height){

    var top, left;
    var features = "";

    if(width == '' || width == null){
        width = 480;
    }

    //height가 '' 또는 Null이면 기본 크기 설정
    if(height == '' || height == null){
        height = 480;
    }

    top  = gfn_CenterY(height);
    left = gfn_CenterX(width);


    features += "top=" + top;
    features += ",left=" + left;
    features += ",width=" + width;
    features += ",height=" + height;

    window.open(url,'popup',features);
}

/******************************************************
 * Description :   팝업창(모달)
 * @param:  url : url
 * @param:  target : target
 * @param:  width : 창 넓이
 * @param:  height : 창 높이
 * @return:  void
 *******************************************************/
function gfn_popWin(url, target, width, height) {
    // window open property set
    var sURL		= url;
    var sTarget		= target;
    var sStatus		= "";
    var bReplace	= false;

    if(sURL == ""){
        alert("주소가 잘못되었습니다..");
        return;
    }

    //sStatus property set
    var vHeight 	= "dialogHeight=" + height+"px";
    var vWidth	= "dialogWidth=" + width+"px";

    //sStatus default set
    var vlocation = "location=no";
    var scrollbar = "scrollbars=yes";
    var toolbar = "toolbar=no";
    var menubar = "menubar=no";
    var resizeStatus = "resizable=no";
    var statusBar = "status=yes";

    sStatus = vlocation + ";" + statusBar + ";" + scrollbar + ";" + menubar + ";" + toolbar + ";" + resizeStatus + ";" + vWidth + ";" + vHeight;

    var newWin;

    if(sTarget.length > 0) {
        newWin = window.showModalDialog(sURL,sTarget,sStatus);
    } else {
        newWin = window.showModalDialog(sURL,self,sStatus);
    }
}

/******************************************************
 * Description :   팝업창(모달) 리턴값 추가
 * @param:  url : url
 * @param:  target : target
 * @param:  width : 창 넓이
 * @param:  height : 창 높이
 * @return:  화면에서 전달받은 값
 *******************************************************/
function gfn_popWin2(url, target, width, height, stddPop) {
    // window open property set
    var sURL		= url;
    var sTarget		= target;
    var sStatus		= "";
    var bReplace	= false;

    if(sURL == ""){
        alert("주소가 잘못되었습니다..");
        return;
    }

    //sStatus property set
    var vHeight = "";
    var vWidth = "";

    //소속팝업인 경우
    if(stddPop == "stddPop") {
        vHeight 	= "dialogHeight=580px";
        vWidth	= "dialogWidth=820px";
    } else {
        vHeight 	= "dialogHeight=" + height+"px";
        vWidth	= "dialogWidth=" + width+"px";
    }

    //sStatus default set
    var vlocation = "location=no";
    var scrollbar = "scrollbars=no";
    var toolbar = "toolbar=no";
    var menubar = "menubar=no";
    var resizeStatus = "resizable=no";
    var statusBar = "status=yes";

    sStatus = vlocation + ";" + statusBar + ";" + scrollbar + ";" + menubar + ";" + toolbar + ";" + resizeStatus + ";" + vWidth + ";" + vHeight;

    var newWin;

    if(sTarget.length > 0) {
        return newWin = window.showModalDialog(sURL,sTarget,sStatus);
    } else {
        return newWin = window.showModalDialog(sURL,self,sStatus);
    }
}

/******************************************************
 * Description :   팝업창(모달리스)
 * @param:  theURL : url
 * @param:  winName : target
 * @param:  w : 창 넓이
 * @param:  h : 창 높이
 * @param:  features : 팝업창 속성
 * @return:  void
 *******************************************************/
function gfn_open_popCen(theURL,winName,w,h,features) {
    var winl = (screen.width - w) / 3;
    var wint = (screen.height - h) / 3;
    features = 'width='+w+',height='+h+',left='+winl+',top='+wint+','+features;

    var newWin = window.open(theURL,winName,features);

    newWin.focus();
}

/******************************************************
 * Description :   화면 가로 중앙 좌표값
 * @param:  width : 창 넓이
 * @return:  가로 중앙 좌표
 *******************************************************/
function gfn_CenterX(width){
    var retVal;
    retVal = (document.body.clientWidth / 2) - (width / 2);
    return retVal;
}

/******************************************************
 * Description :   화면 세로 중앙 좌표값
 * @param:  height : 창 넓이
 * @return:  세로 중앙 좌표
 *******************************************************/
function gfn_CenterY(height){
    var retVal;
    retVal = (document.body.clientHeight / 2) - (height / 2);
    return retVal;
}

/******************************************************
 * Description :   문자열 앞뒤 공백제거
 * @param:  str : 문자열
 * @return:  공백제거된 문자열
 *******************************************************/
function gfn_trim(str) {
    str = str.replace(/(^\s*)|(\s*$)/g, "");
    return str;
}

/******************************************************
 * Description :   문자열의 특정길이 만큼 자름(...)
 * @param:  str : 문자열
 * @param:  len : 문자열 자를 길이
 * @return:  문자열
 *******************************************************/
function gfn_cut_str(str, len) {
    var curLen = 0;

    for (var i=0; i<str.length; i++) {
        curLen += (str.charCodeAt(i) > 128) ? 2 : 1;
        if (curLen > len) return str.substring(0,i) + "...";
    }

    return str;
}

/******************************************************
 * Description :   숫자체크
 * @param:  control : -
 * @param:  msg : -
 * @return:  boolean
 *******************************************************/
function gfn_isNumber(control, msg) {

    var val = control;
    var Num = "1234567890";
    for (i=0; i<val.length; i++) {
        if(Num.indexOf(val.substring(i,i+1))<0) {
            alert(msg+' 형식이 잘못되었습니다.');
            return false;
        }
    }
    return true;
}

/******************************************************
 * Description :   날짜체크
 * @param:  val : 날짜 입력값
 * @param:  msg : 에러 메시지
 * @return:  boolean
 *******************************************************/
function gfn_isDate(control, msg) {
    //'/'나 '-' 구분자 제거
    var val = gfn_getRemoveFormat(control);

    //숫자, length 확인
    if (gfn_isNumber(val, msg) && val.length == 8) {
        var year = val.substring(0,4);
        var month = val.substring(4,6);
        var day = val.substring(6,8);

        //유효날짜 확인
        if(gfn_checkDate(year,month,day,msg)){
            return true;
        } else {
            return false;
        }
    } else {
        alert(msg + "이(가) 유효하지 않은 년,월,일(YYYY-MM-DD)입니다. 다시 확인해 주세요!");
        return false;
    }
}

/******************************************************
 * Description :   날짜체크 및 날짜입력 값 설정
 * @param:  dateVal : 날짜 입력값
 * @param:  msg : 에러 메시지
 * @param:  element : 설정할 element
 * @return:  boolean
 *******************************************************/
function gfn_validDateValue(dateVal, msg, element) {
    if(dateVal.length > 0) {
        if(gfn_isDate2(dateVal, msg)) {
            //$("#"+element).val(gfn_setDateFormat(dateVal));
            return true;
        } else {
            return false;
        }
    } else {
        return true;
    }
}
/******************************************************
 * Description :   날짜체크 및 날짜입력 값 설정 2
 * @param:  dateVal : 날짜 입력값
 * @param:  msg : 에러 메시지
 * @param:  element : 설정할 element
 * @return:  boolean
 *******************************************************/
function gfn_validDateValue2(dateVal, msg, element) {
    if(dateVal.length > 0) {
        if(gfn_isDate3(dateVal, msg)) {
            //$("#"+element).val(gfn_setDateFormat(dateVal));
            return true;
        } else {
            return false;
        }
    } else {
        return true;
    }
}
/******************************************************
 * Description :   날짜체크
 * @param:  val : 날짜 입력값
 * @param:  msg : 에러 메시지
 *******************************************************/
function gfn_isDate2(val, msg) {
    //날짜만
    var testDate = val.replace("-", "").replace("-", "");
    //날짜형식
    var numberTF = /^[0-9]{4}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$/.test(testDate);
    //년, 월, 일
    var year = "";
    var month = "";
    var day = "";
    //결과값
    var result = false;

    if(numberTF) {
        year = testDate.substring(0,4);
        month = testDate.substring(4,6);
        day = testDate.substring(6,8);
        //2월
        if(month == "02") {
            var isleap = ((parseInt(year,10) % 4) == 0) && ((parseInt(year,10) % 100) == 0 || (parseInt(year,10) % 4) == 0);

            if (parseInt(day, 10) > 29) {
                result = false;
            } else if((day == "29") && !isleap) {
                result = false;
            } else {
                if(day == "28") {
                    result = true;
                } else {
                    result = true;
                }
            }
            //그밖의 달
        } else {
            if((month=="04")||(month=="06")||(month=="09")||(month=="11")){
                if(day == "31") {
                    result = false;
                } else {
                    result = true;
                }
            }else {
                result = true;
            }
        }
    } else {
        result = false;
    }

    if(!result) {
        alert(gfn_GetMessage("TC_CM_MSG_016", msg));
        return false;
    }

    return true;
};
/******************************************************
 * Description :   날짜체크2
 * @param:  val : 날짜 입력값
 * @param:  msg : 에러 메시지
 * @return:  boolean
 *******************************************************/
function gfn_isDate3(val, msg) {
    //날짜만
    var testDate = val.replace(".", "").replace(".", "");
    //날짜형식
    var numberTF = /^[0-9]{4}(0[1-9]|1[012])(0[1-9]|[12][0-9]|3[01])$/.test(testDate);
    //년, 월, 일
    var year = "";
    var month = "";
    var day = "";
    //결과값
    var result = false;

    if(numberTF) {
        year = testDate.substring(0,4);
        month = testDate.substring(4,6);
        day = testDate.substring(6,8);
        //2월
        if(month == "02") {
            var isleap = ((parseInt(year,10) % 4) == 0) && ((parseInt(year,10) % 100) == 0 || (parseInt(year,10) % 4) == 0);

            if (parseInt(day, 10) > 29) {
                result = false;
            } else if((day == "29") && !isleap) {
                result = false;
            } else {
                if(day == "28") {
                    result = true;
                } else {
                    result = true;
                }
            }
            //그밖의 달
        } else {
            if((month=="04")||(month=="06")||(month=="09")||(month=="11")){
                if(day == "31") {
                    result = false;
                } else {
                    result = true;
                }
            }else {
                result = true;
            }
        }
    } else {
        result = false;
    }

    if(!result) {
        alert(gfn_GetMessage("TC_CM_MSG_016", msg));
        return false;
    }

    return true;
};

/******************************************************
 * Description :   구분자 제거
 * @param:  val : 제거할 구분자
 * @param:  msg : -
 * @return:  str
 *******************************************************/
function gfn_getRemoveFormat(val) {
    if(val.length == 10) {
        var arrDate = new Array(3);
        arrDate = val.split("-");
        if(arrDate.length != 3) {
            arrDate = val.split("-");
        }
        return arrDate[0] + arrDate[1] + arrDate[2];
    } else {
        return val;
    }
}

/******************************************************
 * Description :   날짜 구분자 설정
 * @param:  val : 숫자만 입력된 날짜
 * @param:  msg : -
 * @return:  str :
 *******************************************************/
function gfn_setDateFormat(val) {
    //날짜 구분자
    var sepVal = "-";
    //년,월,일
    var year = "";
    var month = "";
    var day = "";
    //리턴 값
    var result = val;

    if(val.length == 8) {
        year = val.substring(0,4);
        month = val.substring(4,6);
        day = val.substring(6,8);

        result = year+sepVal+month+sepVal+day;

        return result;
    } else {
        return result;
    }
}

/******************************************************
 * Description :   날짜유효성 체크
 * @param: varCk1 : YYYY
 * @param: varCk2 : MM
 * @param: varCk3 : DD
 * @param: msg : -
 * @return:  str
 *******************************************************/
function gfn_checkDate(varCk1, varCk2, varCk3, msg) {
    if (varCk1>="0001" && varCk1<="9999" && varCk2>="01" && varCk2<="12") {
        febDays = "29";
        if ((parseInt(varCk1,10) % 4) == 0) {
            if ((parseInt(varCk1,10) % 100) == 0 && (parseInt(varCk1,10) % 400) != 0){
                febDays = "28";
            }
        }else{
            febDays = "28";
        }
        if (varCk2=="01" && varCk3>="01" && varCk3<="31") return true;
        if (varCk2=="02" && varCk3>="01" && varCk3<=febDays) return true;
        if (varCk2=="03" && varCk3>="01" && varCk3<="31") return true;
        if (varCk2=="04" && varCk3>="01" && varCk3<="30") return true;
        if (varCk2=="05" && varCk3>="01" && varCk3<="31") return true;
        if (varCk2=="06" && varCk3>="01" && varCk3<="30") return true;
        if (varCk2=="07" && varCk3>="01" && varCk3<="31") return true;
        if (varCk2=="08" && varCk3>="01" && varCk3<="31") return true;
        if (varCk2=="09" && varCk3>="01" && varCk3<="30") return true;
        if (varCk2=="10" && varCk3>="01" && varCk3<="31") return true;
        if (varCk2=="11" && varCk3>="01" && varCk3<="30") return true;
        if (varCk2=="12" && varCk3>="01" && varCk3<="31") return true;
    }
    alert(msg + "이(가) 유효하지 않은 년,월,일(YYYY-MM-DD)입니다.\n다시 확인해 주세요!");
    return false;
}



/**
 * 전체 체크박스 toggle
 * @param: p_name
 * @param: item_name 체크하고자 하는 체크박스의 이름
 * @return
 */
function gfn_checkItemAll(p_name, item_name){
    var len = $("input:checkbox[name='"+item_name+"']").length;

    if($("input:checkbox[name='"+p_name+"']").attr("checked") == 'checked'){
        for(var i=0; i < len; i++){
            $("input:checkbox[name='"+item_name+"']").attr("checked",true);
            $("input:checkbox[name='"+item_name+"']").val("1");
        }
    }else{
        for(var i=0; i < len; i++){
            $("input:checkbox[name='"+item_name+"']").attr("checked",false);
            $("input:checkbox[name='"+item_name+"']").val("0");
        }
    }
}

/**
 * 개별 체크박스 toggle
 * @param: p_name
 * @param: item_name 체크하고자 하는 체크박스의 이름
 * @return
 */
function gfn_checkItem(p_name, item_name){
    var i = 0;
    var len = $("input:checkbox[name='"+item_name+"']").length;

    $("input:checkbox[name='"+item_name+"']").each(function(index){
        if(this.checked){
            $("input:checkbox[name='"+item_name+"']").eq(index).attr("checked",true);
            i++;

        }else{
            $("input:checkbox[name='"+item_name+"']").eq(index).attr("checked",false);
            i--;
        }

    });

    if(i == len){
        $("input:checkbox[name='"+p_name+"']").attr("checked",true);
    }else{
        $("input:checkbox[name='"+p_name+"']").attr("checked",false);
    }
}

function gfn_GetMessage(pMsgCd,pBindInfo){
    var msgName;

    //메시지코드가 null이거나 ""이면 리턴
    if(pMsgCd != null && pMsgCd !="")
    {
        if(typeof(pMsgCd) == 'undifined')
        {
            msgName = "";
            retVal  = "";
        }
        else
        {
            msgName = pMsgCd;
            retVal = msgName;
        }
    }

    if(pBindInfo != null && pBindInfo != "")
    {
        if(pBindInfo.length > 0)
        {
            var arrBind = pBindInfo.split(";");
            for(var i=0; i < arrBind.length; i++)
            {
                //retVal = msgName.replace("{" + i + "}",arrBind[i]);
                retVal = msgName.split("{" + i + "}").join(arrBind[i]);
                msgName = retVal;
            }
        }
    }

    return retVal;
}

/**
 * 특수문자 체크
 * @param:검색어, 입력항목에 대한 특수문자 체크
 * @param
 * @return boolean
 */
function gfn_isSpecial(param){
    var pattern = /[\!@#$%^&*()]/gi;
    return pattern.test(param);
}

/**
 * 널 체크
 * @param:검색어, 입력항목에 대한 널 체크
 * @return boolean
 */
function gfn_isNull(param){
    if(param == null || param == ""){
        return true;
    }
    return false;
}

/******************************************************
 * Description : LPAD 함수
 * @param: orgStr : 원본문자, cnt: 붙일 갯수,  appendStr: 붙일 문자열
 * @return:
 *******************************************************/
function gfn_lpad(orgStr, cnt, appendStr)
{
    var strOrg = String(orgStr);
    var strCnt = strOrg.length;
    var result = "";

    if(strCnt < cnt) {
        for(var idx=0; idx<(cnt-strCnt); idx++) {
            result += appendStr;
        }
        result += orgStr;

    } else {
        result = strOrg;
    }

    return result;
};

/******************************************************
 * Description : 오늘날짜
 * @return: "YYYYMMDD"
 *******************************************************/
function gfn_today(){
    var now = new Date();
    var year = now.getFullYear();
    var MM = now.getMonth()+1;
    if((MM+"").length < 2){
        MM = "0"+MM;
    }
    var dd = now.getDate();
    if((dd+"").length < 2){
        dd = "0"+dd;
    }

    var dt = year+""+MM+""+dd;
    return dt;
}

/******************************************************
 * Description : 현재시간
 * @return: "20190314170805"
 *******************************************************/
function gfn_pad(n) { return n < 10 ? '0' + n : n }
function gfn_currentTime(){
    var date = new Date();
    var dt = date.getFullYear().toString()	+ gfn_pad(date.getMonth() + 1)
        + gfn_pad( date.getDate()) + gfn_pad( date.getHours() )
        + gfn_pad( date.getMinutes() ) + gfn_pad( date.getSeconds() );
    return dt;
}

/******************************************************
 * Description: 이벤트 체크
 * @param: 시작일, 마감일+1  ('20190314170805','20190319170805')
 * @return: boolean
 *******************************************************/
function gfn_chkEventDate(evtStartDt,evtEndDt){
    var eventDtYn = false;
    var today = gfn_currentTime();
    if( evtStartDt <= today && today < evtEndDt){
        eventDtYn = true;
    }
    return 	eventDtYn;
}

/******************************************************
 * Description : 기간체크
 * @param:  시작일, 마감일+1 ('20190314170805','20190319170805')
 * @return: boolean
 *******************************************************/
function gfn_chkDueDate(startDt,endDt){
    var dueDtYn = false;
    var today = gfn_currentTime();
    if( startDt <= today && today < endDt){
        dueDtYn = true;
    }
    return 	dueDtYn;
}

/******************************************************
 * Description :   숫자체크
 * @since : 2012. 07. 31
 *******************************************************/
function gfn_isNumber(control) {
    var chkYn = true;
    var val = control;
    var Num = "1234567890";
    for (i=0; i<val.length; i++) {
        if(Num.indexOf(val.substring(i,i+1))<0) {
            chkYn = false;
        }
    }
    return chkYn;
}


/******************************************************
 * Description :   콤마찍기
 * @since : 2019. 05. 20
 *******************************************************/
function gfn_numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

/******************************************************
 * Description :   랜덤숫자찍기
 * @since : 2019. 05. 20
 *******************************************************/
function gfn_randomRange(n1, n2) {
    return Math.floor( (Math.random() * (n2 - n1 + 1)) + n1 );
}

/**
 * 파일명에서 확장자명 추출
 * @param filename   파일명
 * @returns _fileExt 확장자명
 */
function getExtensionOfFilename(filename) {
    var _fileLen = filename.length;
    /**
     * lastIndexOf('.')
     * 뒤에서부터 '.'의 위치를 찾기위한 함수
     * 검색 문자의 위치를 반환한다.
     * 파일 이름에 '.'이 포함되는 경우가 있기 때문에 lastIndexOf() 사용
     */
    var _lastDot = filename.lastIndexOf('.');
    // 확장자 명만 추출한 후 소문자로 변경
    var _fileExt = filename.substring(_lastDot + 1, _fileLen).toLowerCase();
    return _fileExt;
}

function gfn_inputNumberFormat(obj) {
    obj.value = gfn_comma(gfn_uncomma(obj.value));
}

function gfn_comma(str) {
    str = String(str);
    return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,');
}

function gfn_uncomma(str) {
    str = String(str);
    return str.replace(/[^\d]+/g, '');
}

function gfn_isIos(){
    return /iPhone|iPad|iPod/i.test(navigator.userAgent)||(navigator.userAgent.indexOf('iPhone') != -1) || (navigator.userAgent.indexOf('iPod') != -1) || (navigator.userAgent.indexOf('iPad') != -1);
}

function gfn_isAndroid(){
    return /Android/i.test(navigator.userAgent);
}

function gfn_isMobile(){
    var UserAgent = navigator.userAgent;
    return UserAgent.match(/iPhone|iPod|Android|Windows CE|BlackBerry|Symbian|Windows Phone|webOS|Opera Mini|Opera Mobi|POLARIS|IEMobile|lgtelecom|nokia|SonyEricsson/i) != null || UserAgent.match(/LG|SAMSUNG|Samsung/) != null;
}

/**
 * 앱 버전이 기준 버전 보다 낮은지 체크(낮으면 true)
 * 사용법 : andVer: 안드로이드 버전(예: "1.0.9"), iosVer: IOS 버전(예: "1.1.10")
 */
function gfn_isOldAppVer(andVer, iosVer) {

    var uag = window.navigator.userAgent.toLowerCase();
    //$(".main-text").html("");
    var uagArray = uag.split(";");
    var appOs = "";
    var appVer = "";
    
    for(var i=0; i < uagArray.length; i++) {

        var keyValue = uagArray[i].split("/");
        var key = "";
        var value = "";

        if(keyValue.length > 1) {

            key = $.trim(keyValue[0]);

            for(var j=1; j < keyValue.length; j++) {

                value += $.trim(keyValue[j]);
            }
        }

        //console.log("key: '" + key + "' / value: '" + value + "'");
        //$(".main-text").html($(".main-text").html() + "<br/>key: '" + key + "' / value: '" + value + "'");

        if(key == "os") appOs = value;
        if(key == "app-version") appVer = value;
    }
    
    //alert("appVer: '" + appVer + "'");

    var strVer = andVer;
    if(appOs == "ios") strVer = iosVer;

    var arrStrVer = strVer.split(".");
    var arrAppVer = appVer.split(".");
    var k=0;

    for(k=0; k < arrStrVer.length || k < arrAppVer.length; k++) {

        if(arrStrVer[k] > arrAppVer[k]) {

            //alert("arrStrVer[" + k + "]: " + arrStrVer[k] + " / arrAppVer[" + k + "]: " + arrAppVer[k]);
            return true;
        }
    }

    if(arrStrVer[k] == arrAppVer[k] && arrStrVer.length < arrAppVer.length) return true;

    return false;
}

/**
 * 앱 버전 확인
 * 사용법 : return "1.0.1"(엡버전 리턴)
 */
function gfn_getAppVer() {

    var uag = window.navigator.userAgent.toLowerCase();
    var uagArray = uag.split(";");
    for(var i=0; i < uagArray.length; i++) {

        var keyValue = uagArray[i].split("/");
        var key = "";
        var value = "";

        if(keyValue.length > 1) {

            key = $.trim(keyValue[0]);

            for(var j=1; j < keyValue.length; j++) {

                value += $.trim(keyValue[j]);
            }
        }

        //console.log("key: '" + key + "' / value: '" + value + "'");

        if(key == "app-version") {
        
            return value;
        }
    }

    return "";
}

/**
 * 공통 ajax
 * 사용법 : gfn_ajaxCmm(type, url, param, function(data) {console.log(data)});
 */
function gfn_ajaxCmm(type, url, param, callback) {
    $.ajax({
        type: type,
        url: url,
        data: param,
        success: function(data, status, xr) {
            return callback(data);
        },
        error: function(xhr, status, error) {
            return callback(data)
        }
    });
}

//캡스락 체크
function gfn_capslock(e){
    var keyCode = e.keyCode;
    let shiftKey = e.shiftKey;
    if (((keyCode >= 65 && keyCode < 90) && !shiftKey) || ((keyCode >= 97 && keyCode <= 112) && shiftKey)) {
        $(".capsLock").addClass("on");
    } else {
        $(".capsLock").removeClass("on");
    }
}

function gfn_localLoginChck() {
    var isLocal;
    $.ajax({
        type : 'GET',
        url : '/sso/localLoginChck',
        dataType : 'json',
        async: false,
        cache: false,
        success : function(obj){
            //alert("obj = " + obj.localLoginYn);
            isLocal = obj.localLoginYn;
        }
    });
    return isLocal;
}

// 숫자만 입력받기
function onlyNumber(event){
    event = event || window.event;

    var keyID = (event.which) ? event.which : event.keyCode;
    if ( (keyID >= 48 && keyID <= 57) || (keyID >= 96 && keyID <= 105) || keyID == 8 || keyID == 46 || keyID == 37 || keyID == 39 || keyID == 9)
        return;
    else
        return false;
}

// 문자열 삭제
function removeChar(event) {
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;
    if ( keyID == 8 || keyID == 46 || keyID == 37 || keyID == 39 )
        return;
    else
        event.target.value = event.target.value.replace(/[^0-9]/g, "");
}

function gfn_getCurrentDateFormatted() {
    var date = new Date();
    var year = date.getFullYear();
    var month = ("0" + (date.getMonth() + 1)).slice(-2);
    var day = ("0" + date.getDate()).slice(-2);
    return year + "." + month + "." + day;
}

function gfn_makeMaskingName(name) {
    if (!name) return "";
    if (name.length === 1) return name;

    // 이름 첫 글자
    let firstName = name.substring(0, 2);

    // 이름 나머지 글자에 대한 마스킹
    let cnvRestName = '*'.repeat(name.length - 2);

    // 마스킹 완성된 이름
    let maskingName = firstName + cnvRestName;
    console.log("makeMaskingName =", maskingName);
    return maskingName;
}

function gfn_initPolicyInfoSelectBox(selectedEducationTopicCd) {

    $.ajax({
        type : 'GET',
        url : '/comn-cd/E01',
        dataType : 'json',
        success : function(obj){
            $('#educationTopicCd').mkOptionEdu(obj, '<option value="">선택</option>');
        },
        error : function(xhr, status, error){
            alert('처리중 에러가 발생 하였습니다.');
        }
    });

    // 교육 셀렉트박스 options 생성
    $.fn.mkOptionEdu = function(svrObj, defaultHtml){
        var selectedValue = selectedEducationTopicCd; // 선택된 값
        jQuery.each(svrObj, function(i, val){
            // 선택된 값이 있고, 해당 값과 같으면 selected 속성을 추가합니다.
            var isSelected = selectedValue && val.comnCd === selectedValue ? ' selected' : '';
            defaultHtml += '<option value="' + val.comnCd + '"' + isSelected + '>' + val.comnCdNm + '</option>';
        });
        $(this).html(defaultHtml);
    };

    $('.select-area').change(function(){
        $(this).closest(".select").find("label").text($(this).find("option:selected").text());
    });

    //도시 선택
    $('#cityDsCd').change(function(){
        if ($(this).val() != '') {
            $.ajax({
                type : 'GET',
                url : '/comn-cd/area/',
                data : {'upAreaNo' : $(this).val()},
                dataType : 'json',
                success : function(obj){
                    /*$('#rltdAreaCd').mkOption(obj, '<option value="">구군</option>');*/
                    $('#rltdAreaCd').mkOption(obj, );
                },
                error : function(xhr, status, error){
                    alert('처리중 에러가 발생 하였습니다.');
                }
            });
        } else {
            $('#rltdAreaCd').html('<option value="">구군</option>');
        }
    });

    //구군 셀렉트박스 options 생성
    $.fn.mkOption = function(svrObj, defaultHtml){
        jQuery.each($(svrObj), function(i, val){
            defaultHtml += '<option value="' + val.optKey + '">' + val.optVal + '</option>';
        });
        $(this).html(defaultHtml);
    };
}

/* 첨부파일 드래그앤드롭 사용 function */
function gfn_dragAndDrop( dropzone, fn_callback ) {
	var $dropzones = jQuery( dropzone );
	
	$dropzones.on( 'dragenter', function(e) {
		e.stopPropagation();
		e.preventDefault();

		let $dropzone = jQuery(this);
		$dropzone.css( 'background-color', '#E3F2FC' );
	} );

	$dropzones.on( 'dragleave', function(e) {
		e.stopPropagation();
		e.preventDefault();

		let $dropzone = jQuery(this);
		$dropzone.css( 'background-color', '#FFFFFF' );
	} );

	$dropzones.on( 'dragover', function(e) {
		e.stopPropagation();
		e.preventDefault();

		let $dropzone = jQuery(this);
		$dropzone.css( 'background-color', '#E3F2FC' );
	} );
	
	$dropzones.on( 'drop', function(e) {
		e.stopPropagation();
		e.preventDefault();

		let $dropzone = jQuery(this);
		let $e = $dropzone.find('input[type=file]');
		$dropzone.css( 'background-color', '#FFFFFF' );
		
		let files = e.originalEvent.dataTransfer.files;
		for( let i in files ) {
			if( typeof(files[i]) == 'object' ) {
				fn_callback($e, files[i]);
			}
		}
	} );
}

/* 로딩창 제어 */
function gfn_loading(bool, selector) {
	let $selector = jQuery(selector);
	let $popup = $selector.parents('.popup_wrap');
    
    if( bool ) {
    	let htmlStr = '<div class="loading-container">';
        htmlStr += '<div class="loading"></div>';
        htmlStr += '<div id="loading-text">loading</div>';
        htmlStr += '</div>';
        
        $selector.prepend(htmlStr);
        $selector.hasClass('pop_dim') ? $selector.show() : $popup.addClass('loading_process');
    }
    else {
        $(".loading-container").remove();
        $selector.hasClass('pop_dim') ? $selector.hide() : $popup.removeClass('loading_process');
    }
}

/* 로딩창 제어 일반 게시판 글쓰기 화면에서 */
function gfn_loading2(bool, selector) {
	let $selector = jQuery(selector);
    if( bool ) {
    	let htmlStr = '<div class="loading-container">';
        htmlStr += '<div class="loading"></div>';
        htmlStr += '<div id="loading-text">loading</div>';
        htmlStr += '</div>';
        $selector.after(htmlStr);
        $selector.show();
    }
    else {
        $(".loading-container").remove();
    }
}

/* onkeyup 이벤트 숫자가 아니면 공백 치환 */
function gfn_onlyNumber(e) {
	e.value = e.value.replace( /[^0-9]/g, '' );
}

/* onkeyup 이벤트 영문 아니면 공백 치환 */
function gfn_onlyEng(txt) {
	txt.value = txt.value.replace( /[^a-zA-Z]/g, '' );
}

/* onkeyup 이벤트 영문, 숫자 아니면 공백 치환 */
function gfn_onlyChar(txt) {
	txt.value = txt.value.replace( /[^a-zA-Z0-9]/g, '' );
}

/* 휴대폰 형식 체크 */
function gfn_isPhone(txt) {
	return /^(01[016789]{1})-?[0-9]{3,4}-?[0-9]{4}$/.test( txt );
}

/* 이메일 형식 체크 */
function gfn_isEmail(txt) {
	return /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test( txt );
}

/* 나이스 개인번호 형식 체크 */
function gfn_isNiceNumber(txt) {
	return /^[nN][0-9]{9}$/.test( txt );
}

/* 빈값 여부 체크 */
function gfn_isEmpty(txt) {
	if( typeof(txt) !== 'undefined' && txt != null && txt.trim() != '' ) {
		return false;
	}
	return true;
}

/* 이전 페이지 이동(referrer) */
function gfn_referrer(url) {
	location.href = document.referrer || (url || '/');
}

/* date 포맷 함수 d(형식 : yyyyMMddHHmmss)*/
function gfn_dateFormat(sdate, format) {
	sdate = String(sdate);
	let date = sdate.slice(0, 4) +'-'+ sdate.slice(4, 6) +'-'+ sdate.slice(6, 8);
	if( sdate.length == 10 ) {
		date += ' '+sdate.slice(8, 10);
	}
	else if( sdate.length == 12 ) {
		date += ' '+sdate.slice(8, 10) +':'+ sdate.slice(10, 12);
	}
	else if( sdate.length == 14 ) {
		date += ' '+sdate.slice(8, 10) +':'+ sdate.slice(10, 12) +':'+ sdate.slice(12, 14);
	}

	const dayMap = {0:'일', 1:'월', 2:'화', 3:'수', 4:'목', 5:'금', 6:'토'};
	date = new Date(date);
	const map = {
		yyyy : date.getFullYear()
		, MM : String(date.getMonth()+1).padStart(2, '0')
		, dd : String(date.getDate()).padStart(2, '0')
		, HH : String(date.getHours()).padStart(2, '0')
		, mm : String(date.getMinutes()).padStart(2, '0')
		, ss : String(date.getSeconds()).padStart(2, '0')
		, E : dayMap[date.getDay()]
	}
	
	return format.replace(/yyyy|MM|dd|HH|mm|ss|E/g, matched => map[matched]);
}

/* 중복체크 나이스번호 */
function gfn_checkNiceNo() {
	let $nicePrsnlNo = $('input[name=nicePrsnlNo]');
	$nicePrsnlNo.attr('d-dupl', 'N');
	
	let $desc = $('#nicePrsnlNo-desc');
	let nicePrsnlNo = gfn_niceNo();
	
   	if( gfn_isEmpty(nicePrsnlNo) ) {
   		$desc.html('<span class="error">나이스 번호를 입력해 주세요.</span>');
   		return;
	}
   	else if( nicePrsnlNo.length != 10 ) {
   		$desc.html('<span class="error">나이스 번호 형식이 맞지 않습니다.</span>');
   		return;
    }

 	// ajax 영역
   	let callback = function(type, path, result) { // 좋아요 콜백 함수
		if( type != 'success' ) {
			$desc.html('<span class="error">나이스 번호 중복 확인 중 에러가 발생하였습니다.</span>');
			return;
		}
		
		if( !result ) {
			$desc.html('<span style="color:blue;">사용 가능한 나이스 번호입니다.</span>');
			$nicePrsnlNo.attr('d-dupl', 'Y');
		}
		else {
			$desc.html('<span class="error">중복된 나이스 번호입니다.</span>');
			$nicePrsnlNo.attr('d-dupl', 'D');
		}
		
	}
	gfn_transaction( '/user/duplCheckNiceNo', callback, {nicePrsnlNo: nicePrsnlNo}, 'get', false, false, true );
}

/* 나이스번호 유효성 체크 */
function gfn_isValidNiceNo( userNiceNo ) {
	let $desc = $('#nicePrsnlNo-desc');
	let niceNo = gfn_niceNo();
	if( !gfn_isEmpty(niceNo) ) {
    	if( niceNo.length == 10 ) {
        	let $nicePrsnlNo = $('input[name=nicePrsnlNo]');
        	
        	if( gfn_isEmpty(userNiceNo) || userNiceNo != niceNo ) { // 기존 회원이 입력한 나이스 번호와 같지 않을 때만 검사
            	let checkNiceDupl = $nicePrsnlNo.attr('d-dupl');
            	if( checkNiceDupl == 'D' ) {
        			$desc.html('<span class="error">중복된 나이스 번호입니다.</span>');
        			return false;
                }
        		else if( checkNiceDupl == 'N' ) {
        			$desc.html('<span class="error">나이스 번호 중복 확인을 해주세요.</span>');
            		return false;
                }
        	}
        	
        	$nicePrsnlNo.val( niceNo );
        }
    	else {
    		$desc.html('<span class="error">나이스 번호 형식이 맞지 않습니다.</span>');
			return false;
        }
    }
    
    return true;
}

/* 나이스번호 세팅 */
function gfn_niceNo() {
    let $inputCnpsCd = $('.input_cnpsCd');
	let niceNo = "";
	$inputCnpsCd.children('input').each( function(i, item) {
		niceNo += item.value;
    } );

	return ($('.select_cnpsCd').val() + niceNo);
}

/* 나이스 번호 입력 시 체크 */
function gfn_checkNiceField(e) {
	if( e.tagName === 'INPUT' ) {
		gfn_onlyChar(e);
	}
	
	$('input[name=nicePrsnlNo]').attr('d-dupl', 'N'); // 새롭게 입력된거라 인증 검사 초기화
}

/* 나이스 번호 필드에 입력 */
function gfn_setNicePrsnlNo(nicePrsnlNo) {
	if( !gfn_isEmpty(nicePrsnlNo) ) {
		$('.select_cnpsCd option[value='+nicePrsnlNo.substring(0, 3)+']').prop('selected', true);
		
		let inputCnpsCd = nicePrsnlNo.substring(3, 10);
		$('.input_cnpsCd').children('input').each( function(i, item) {
			this.value = inputCnpsCd.charAt(i);
	    } );
	}
}

/* 나이스 번호 사용 설정 */
function gfn_isUseNiceField(use, resetValue) {
		if(resetValue) $('.select_cnpsCd option:eq(0)').prop('selected', true);
		let $inputCnpsCd = $('.input_cnpsCd');
		
		$inputCnpsCd.children('input').each( function(i, item) {
			if(resetValue) item.value = '';
			$(item).prop('disabled', use);
	    } );
	
	    $('.select_cnpsCd').prop('disabled', use);
	    use ? $inputCnpsCd.siblings('.cssbtn').hide() : $inputCnpsCd.siblings('.cssbtn').show();
	};


/* 좋아요 기능 공통 함수 처리 */
function gfn_like(pstId, isJunior, isAdmin) {
    if( gfn_isEmpty(pstId) ) {
        alert( '게시글을 선택해 주세요.' );
        return;
    }
    
	isJunior = isJunior || 'N';
	isAdmin = isAdmin || 'N';
	
	let callbackLike = function(type, path, data) { // 좋아요 콜백 함수
		if( type != 'success' ) {
			alert( '추천 처리 중 에러 발생' );
			return;
		}
		
		let $btn = $(".btn_like"), $great = $(".great");
		let likeCnt = Number( $great.text() );
        if(data === "LIKE_ADDED") { // 추천 숫자를 증가
			$btn.addClass("on").children('span').text( "추천 " + (likeCnt+1) );
            $great.text( likeCnt+1 );
            return;
		} 
		else if(data === "LIKE_REMOVED") { // 추천 숫자를 감소
            $btn.removeClass("on").children('span').text( "추천 " + (likeCnt-1) );
            $great.text( likeCnt-1 );
            return;
		} 
		
		alert("추천 처리에 실패했습니다.");
		location.reload();
	}
	
	if( isJunior == 'Y' || isAdmin == 'Y' ) {
		return gfn_transaction( '/reaction/pstLike', callbackLike, {pstId: pstId}, 'get', false, false, true ); // 좋아요 처리
	}

	let callback = function(type, path, data) { // 본인 인증 콜백 함수
		if( type != 'success' || data == '0' ) {
			alert('본인 인증 후 이용하실 수 있습니다.');
			location.href = '/cert';
			return;
		}
		
		gfn_transaction( '/reaction/pstLike', callbackLike, {pstId: pstId}, 'get', false, false, true ); // 좋아요 처리
	}
	gfn_transaction( '/cert/check', callback, null, 'get', false, false, false );
}


/******************************************************
 * Description :  Ajax Request 공통함수
 * @param:  Url : 요청URL
 * @param:  callback : 해당 UI에서 callback 받을 function명
 * @param:  param : 파라메터
 * @param:  type : 요청메소드 (Default : POST)
 * @param:  async : 비동기화통신 여부 (Default : true)
 * @param:  contentType : 컨텐츠타입 (Default : false)
 * @param:  processData : (Default : false)
 * @return :  void
 *******************************************************/
function gfn_transaction(url, callback, param, type, async, contentType, processData)
{
    let pAsync = gfn_isNull(async) ? true : async;
    let pType = gfn_isNull(type) ? "POST" : type;
    let pContentType =  gfn_isNull(contentType) ? false : contentType;
    let pProcessData =  gfn_isNull(processData) ? false : processData;
    let pArrId = url.split("/");

    $.ajax({
        url: url,
        data: param,
        type: pType,
        async: pAsync,
        processData: pProcessData,
        contentType: pContentType,
        success: function (result) {
            if(typeof callback === 'function')
            {
                callback("success", pArrId[pArrId.length-1], result)
            }
        },
        error: function (xhr) {
            if(typeof callback === 'function')
            {
                callback("error", pArrId[pArrId.length-1], xhr.statusText)
            }
        }
    });
}

/**
 * 문자열의 바이트 길이를 계산하는 함수 (UTF-8 기준으로 추정)
 * @param {String} s 계산할 문자열
 * @returns {Number} 바이트 길이
 */
function gfn_strByteLength(s)
{
	if(typeof s !== 'string') { 
		console.warn('입력값이 문자열이 아닙니다:', s);
		return 0;
    }
	var b=0, i, c;
	for(i=0; i<s.length; i++) {
		c = s.charCodeAt(i);
		// ASCII범위(0-0x7F): 1바이트
		// 0x00-0x7FF: 2바이트
		// 그 이상: 3바이트 (UTF-8 기준 단순 계산)
		b += c >> 11 ? 3 : c >> 7 ? 2 : 1;
	}
	return b;
}

$(document).ready(function() {
    $('textarea.char_count').on('input', function () {
		const maxByteLength = 4000; // Update the max length according to your need
		// 단순 길이만 가지고 count하면 DB byte와 틀림
		// let currentLength = $(this).val().length;
	    let currentByteLength = gfn_strByteLength($(this).val());

        // Limit the text length
        if (currentByteLength > maxByteLength) {
            $(this).val($(this).val().substring(0, maxByteLength));
            currentByteLength = maxByteLength;
        }

        // Update the associated count_txt for this textarea
        var text = currentByteLength + '/' + maxByteLength;
        $(this).closest('dd').find('.count_txt').text(text);
    });
});

/* 게시글 메인페이지 일반검색 창에서 통합검색 버튼 20241227 */
function searchTotal(tabType,keyword) {
    let searchTotalForm = document.createElement('form');
    searchTotalForm.setAttribute('charset','UTF-8');
    searchTotalForm.setAttribute('method','post');
    searchTotalForm.setAttribute('action','/integratedSearch/main');
    
    let field1 = document.createElement('input');
    field1.setAttribute('type', 'hidden');
    field1.setAttribute('name', 'tabType');
    field1.setAttribute('value', tabType);
    searchTotalForm.appendChild(field1);
    
    let field2 = document.createElement('input');
    field2.setAttribute('type', 'hidden');
    field2.setAttribute('name', 'keyword');
    field2.setAttribute('value', keyword);
    searchTotalForm.appendChild(field2);
    
    document.body.appendChild(searchTotalForm);
    searchTotalForm.submit();
}
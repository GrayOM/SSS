$(function(){
    // header 모바일 풀메뉴
    $('.nav_m').on('click', function(){
        $('html').addClass("fixed");
        $('.gnb_m').addClass("active");
    });
    $('.dim_bg, .menu_close').on('click', function(){
        $('html').removeClass("fixed");
        $('.gnb_m').removeClass("active");
    });

    // 스크롤 시 배경
    function handleScroll() {
        var scrollDistance = $(window).scrollTop();
        if (scrollDistance >= 46) {
            $('header').addClass('fixed');
        } else {
            $('header').removeClass('fixed');
        }

        // 커뮤니티 채팅 화면 스크롤시 상단 고정 관련 소스 추가 20241104
        var $stickyElement = $(".chat_top_wrap");
        var $chattingElement = $(".chatting_wrap");
        // var originalOffsetTop = stickyElement.offset().top;
        var originalHeight = $stickyElement.height();

        if (scrollDistance > 0) {
            $stickyElement.addClass('fixed');
            $chattingElement.css({
                marginTop: originalHeight,
            })
        } else if(scrollDistance === 0) {
            $stickyElement.removeClass('fixed');
            $chattingElement.css({
                marginTop: '2rem'
            })
        }
    }
    $(window).scroll(handleScroll);

    // 댓글 영역 textarea 자동 높이 조절-채팅 입력창 textarea도 추가 20240402
    $('.comment_area textarea, .chat_text_area textarea').each(function() {
		cmtAutoReSize(this);
	});

    // 드롭다운
    // 서브메뉴 있는 서브페이지
    $('.lnb_wrap.mob .lnb_depth_2').hide();
    $('.lnb_wrap.mob .selected_menu').click(function() {
        $(this).next().stop().slideToggle(300);
        $(this).toggleClass('down');
    });
    // 모바일 햄버거 메뉴
    $('.gnb_depth_2').hide();
    $('.gnb_depth_1').click(function() {
        $(this).next().stop().slideToggle(300);
        $(this).toggleClass('down');
        if($(this).next().css("display") == "block"){
            $(this).parents().find('.gnb_depth_2').not($(this).next()).slideUp('fast');
            $(this).parents().find('.gnb_depth_1').not($(this)).removeClass('down');
        }
        return false;            
    });
    // 상세검색 열기-20240103 추가
    $('.search_detail_cont').hide();
    $('.btn_search_detail').click(function() {
        $(this).parents().stop().find('.search_detail_cont').slideToggle(300);
        $(this).toggleClass('open');
        return false;            
    });
    // 상세검색 초기값 오픈 상태 버전 개별 스크립트-20250313 추가
    $('.search_detail_cont.def_open').show();
    $('.btn_search_detail.btn_def_open').addClass('open');
    $('.btn_search_detail.btn_def_open').click(function() {
        if($(this).hasClass('open') === true) {
            $(this).addClass('open');
            $(this).parents().stop().find('.search_detail_cont.def_open').show(300);
        } else {
            $(this).removeClass('open');
            $(this).parents().stop().find('.search_detail_cont.def_open').hide(300);
        }
        return false;            
    });
    // 아코디언 형태 리스트 공통
    // $('.list_cont').hide(); //css에서 처리(20240123)
    $('.list_item').click(function() {
        $(this).next('.list_cont').slideToggle(300);
        $(this).toggleClass('active');
        if($(this).next().css("display") == "block"){
            $(this).parents().find('.list_cont').not($(this).next()).slideUp('fast');
            $(this).parents().find('.list_item').not($(this)).removeClass('active');
        }
        return false;       
    });
    // 서브 페이지 path 2뎁스 리스트 열기 -20240306 추가
    $('.path_2depth').click(function() {
        if($('.path_2depth_wrap').hasClass("open") === true){
            $('.path_2depth_wrap').removeClass('open');
            $('.path_2depth_list').hide(100);
        } else {
            $('.path_2depth_wrap').addClass('open');
            $('.path_2depth_list').show(100);
        }
    });

    // 탭메뉴
    $("li[role='tab'], li[role='group']").click(function(){ //일부 코드 수정 20240821
        fnActiveTab( jQuery(this) );
    });
    
    $('.btn_floating').click(function(){
        $('html, body').animate({scrollTop:0},400);
        return false;
    });
    
    $('.btn_qbanner').click(function(){
        $(location).attr("href", "https://togetherschool.go.kr/teaParty");
        return false;
    });

    // 포커스 관련-20240112 추가
    $('.file_box input').on('focus', function(){
        $(this).prev('label').css('outline', '1px dashed #ccc');
    });
    $('.file_box input').on('blur click', function(){
        $(this).prev('label').css('outline', 'none');
    });

    // 게시판 상세 내용 내 테이블 가로 스크롤 생성을 위한 부모 요소 추가-20240112 추가
    $(".body_txt table").wrap("<div class='cont_tbl_wrap'></div>");

    // pc gnb 1뎁스 마우스 오버시 하위 메뉴 펼침/숨김 처리-20240408
    // if ($(window).width() < 981) { //모바일에선 작동 안하게
    //     $('.wrap:not(#main) > header .gnb nav').removeClass('over');
    // } else {
    //     $('.wrap:not(#main) > header .gnb nav > ul > li > a').each(function(){
    //         $(this).on('mouseover', function(){
    //             $(this).addClass('over');
    //             $('.wrap:not(#main) > header .gnb nav').addClass('over');
    //             if ($(window).width() < 1141) { //981~1140 너비에서 펼침 메뉴 높이값 (20240530 추가)
    //                 $('.wrap:not(#main) > header .gnb nav .web_over_2depth').stop().animate({"height":"46rem"}, 300); //메뉴 추가,변경시 높이값 변경될 영역-20241118 수정
    //             } else { //1141~ 너비에서 펼침 메뉴 높이값 (20240530 추가)
    //                 $('.wrap:not(#main) > header .gnb nav .web_over_2depth').stop().animate({"height":"44rem"}, 300); //메뉴 추가,변경시 높이값 변경될 영역-20241118 수정
    //             }
    //             $(this).next('.web_over_2depth').addClass('active');
    //             $('.wrap:not(#main) > header .gnb nav > ul > li > a').not($(this)).removeClass('over');
    //             $('.web_over_2depth').not($(this).next()).removeClass('active');
    //         });
    //     });
    //     $('.wrap:not(#main) > header .gnb nav .web_over_2depth').each(function(){
    //         $(this).on('mouseover', function(){
    //             $(this).addClass('active');
    //             $(this).prev('a').addClass('over');
    //             $('.web_over_2depth').not($(this)).removeClass('active');
    //             $('.wrap:not(#main) > header .gnb nav > ul > li > a').not($(this).prev('a')).removeClass('over');
    //         })
    //     });
    //     $('.wrap:not(#main) > header .gnb nav').on('mouseleave', function(){
    //         setTimeout(function(){
    //             $('.wrap:not(#main) > header .gnb nav').removeClass('over');
    //         }, 300);
    //         $('.wrap:not(#main) > header .gnb nav .web_over_2depth').stop().animate({"height":"0"}, 300);
    //     });
    // }

    // 알림 리스트 열기,닫기 20240517 추가
    $('header .alarm_list').hide();
    $('header .utils .btn_bell').click(function() {
        $('header .utils .alarm_list').toggle();
    });
    $('header .gnb .btn_bell').click(function() {
        $('header .gnb .alarm_list').toggle();
    });
    $(document).on('click',function(e){ //아무영역이나 클릭시 알림리스트 닫힘
        if(!(($(e.target).closest(".alarm_list").length > 0 ) || ($(e.target).closest(".btn_bell").length > 0))){
            $(".alarm_list").hide();
        }
        // 아무 영역 클릭시 쪽지보내기layer 닫힘 -조건 추가 20250325
        if(!$(e.target).hasClass('btn-name') && !$(e.target).hasClass('layer-open') && !$(e.target).hasClass('swiper-button-prev') && !$(e.target).hasClass('swiper-button-next')){
        	$('.layer-box').removeClass('visible');
        }
    });

    // 20240703 추가 : 팝업 닫기 공통
    $('.pop_close').on('click', function(){
        $(this).closest('.popup').hide();
        $(this).closest('.popup').prev('.pop_dim').hide();
    });

    // 20240912 추가
    // 쪽지 보내기 레이어 팝업
    $('.is-layer .btn-name').on('click', function(){
        // $(this).siblings('.layer-box').addClass('visible'); //기존 코드 삭제 20250324
        // 토글 기능 코드 추가 20250324
        $(this).siblings('.layer-box').toggleClass('visible');
        // 다른 오픈 버튼 클릭시 나머지 팝업 닫기 코드 추가 20250325
        $('.layer-box').not($(this).siblings('.layer-box')).removeClass('visible');
    });

    // 쪽지 보내기 팝업
    $('.is-layer .layer-open').on('click', function(){
        $('.pop_note').prev('.pop_dim').show();
        $('.pop_note').show();
    });

    $('.pop_note .pop_close').on('click', function(){
        $('.pop_note').prev('.pop_dim').hide();
        $('.pop_note').hide();
        $('.layer-box').removeClass('visible');
    });

    // 20241115 추가: 통합검색 플로팅 이벤트 배너 닫았을때 인기검색어 위치 조정
    $('.qbanner_wrap.event_banner .btn_close_boxS').on('click', function(){
        $('.qbanner_wrap.qlink.popular_searches').css("bottom","0");
        $('.qbanner_wrap.qlink.popular_searches.move').css("bottom","0");
    });
    // 20241204 추가: 통합검색 이벤트 배너 처음부터 없을때 인기검색어 위치 조정 관련
    if ($('.qbanner_wrap.event_banner').css('display') === 'none') {
        $('.qbanner_wrap.qlink.popular_searches').css("bottom","0");
        $('.qbanner_wrap.qlink.popular_searches.move').css("bottom","0");
    }

    // 다크모드 전환 버튼-20251105 추가
    $('.btn_mode_change').on('click', function(){
        $('#dark_change_pc, #dark_change_mo').each(function() {
            $(this).toggleClass('dark');
        }); 
        $('.wrap').toggleClass('dark');
        if ($('.wrap').hasClass('dark')) {
            // 'dark' 클래스가 있으면 다크 모드 상태를 저장
            sessionStorage.setItem('darkMode', 'enabled');
        } else {
            // 'dark' 클래스가 없으면 라이트 모드 상태를 저장
            sessionStorage.setItem('darkMode', 'disabled');
        }
    });
    // 다크모드 유지-sessionStorage에서 'darkMode' 상태를 가져옴
    const darkMode = sessionStorage.getItem('darkMode');
    // 저장된 값이 'enabled'이면 다크 모드 클래스 적용
    if (darkMode === 'enabled') {
        // 페이지 로드 시 'dark' 클래스를 적용할 요소들
        $('#dark_change_pc, #dark_change_mo').each(function() {
            $(this).addClass('dark');
        }); 
        $('.wrap').addClass('dark');
    } 
    // 저장된 값이 'disabled'이거나 없으면 (null) 기본 모드로 유지
});

$(window).scroll(function(){
    if ($(this).scrollTop() > 300) {
        $('.btn_floating').addClass('active');
        $('.qbanner_wrap').addClass('move');
        $('.qbanner_container').addClass('move'); // 20241115 추가: 통합검색 플로팅배너 관련
    } else{
        $('.btn_floating').removeClass('active');
        $('.qbanner_wrap').removeClass('move');
        $('.qbanner_container').removeClass('move'); // 20241115 추가: 통합검색 플로팅배너 관련
    }
});

// 댓글 영역 textarea 자동 높이 조절
function cmtAutoReSize(element) {
    // element를 jQuery 객체로 변환
    var $element = $(element);

    $element.each(function() {
        var offset;
        if (this instanceof HTMLElement) {
            // 일반 DOM 요소인 경우
            offset = this.offsetHeight - this.clientHeight;
        } else {
            // jQuery 객체인 경우
            offset = this[0].offsetHeight - this[0].clientHeight;
        }

        var resizeElement = function(el) {
            $(el).css('height', 'auto').css('height', el.scrollHeight + offset);
        };

        $(this).on('input focus', function() {
            resizeElement(this);
        });

        // 채팅 화면 내용 입력 textarea 창 벗어날 경우 높이값 초기화 추가 20240402
        var chatHeightResetElement = function(el) {
            $(el).css('height', '5rem')
        };
        $('.chat_text_area textarea').on('blur', function() {
            chatHeightResetElement(this);
        });
    });
}

// 20240703 추가 : 팝업 오픈 공통 (20240703 이후 해당 구조에 맞게 작성된 팝업에 적용 가능)
function openModal(modalname, callback) {
    $("." + modalname).show();
    $("." + modalname).prev('.pop_dim').show();
    
    if( typeof callback === 'function' ) {
    	return callback;
    }
}

// 20240801 수업나눔 탭메뉴 수정
function fnActiveTab( $tab ) {
	$tab.siblings("li[role='tab'], li[role='group']").attr("aria-selected","false").removeClass('active'); //일부 코드 수정 20240821
    $tab.attr("aria-selected","true").addClass('active');
    var tabpanid = $tab.attr("aria-controls");
    var tabpan = $("#" + tabpanid);
    $tab.parents().find(tabpan).siblings("div[role='tabpanel']").attr("aria-hidden","true");
    $tab.parents().find(tabpan).attr("aria-hidden","false");
}
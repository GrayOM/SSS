// 구글 번역 쿠키 제거 (자동 재번역 방지)
function clearGoogleTranslateCookie() {
    var domain = window.location.hostname;

    document.cookie = 'googtrans=;expires=Thu, 01 Jan 1970 00:00:01 GMT;path=/;';
    document.cookie = 'googtrans=;expires=Thu, 01 Jan 1970 00:00:01 GMT;path=/;domain=.' + domain + ';';
}

// 원문으로 완전히 복귀
function restoreOriginalPage() {
    clearGoogleTranslateCookie();

    // 배너 숨기기
    // var iframe = document.querySelector('iframe.goog-te-banner-frame');
    // if (iframe) iframe.style.display = 'none';
    // document.body.style.top = '0px';

    // 구글 내부 restore 함수 호출
    if (typeof google !== 'undefined' &&
        google.translate &&
        google.translate.TranslateElement) {

        var restoreFn = google.translate.TranslateElement.prototype._restore;
        if (restoreFn) restoreFn();
    }

    // DOM에 남은 번역 흔적 제거를 위해 새로고침
    setTimeout(function () {
        window.location.reload();
    }, 100);
}

document.addEventListener('DOMContentLoaded', function() {
    const script = document.createElement('script');
    script.src = "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit";
    document.body.appendChild(script);

    // 20251119 googleTranslate select 기능 추가: start
    const selects = document.querySelectorAll('.custom_translate');

    function applyLang(lang) {
        // 셀렉트 옵션에 해당 value가 실제로 존재하는지 확인
        selects.forEach(sel => {
            const hasOption = Array.from(sel.options).some(opt => opt.value === lang);

            // 없으면 ko로 fallback
            const finalLang = hasOption ? lang : 'ko';

            if (sel.value !== finalLang) {
                sel.value = finalLang;
            }
        });

        // Google Translate 위젯에 언어 적용
        const googleSelect = document.querySelector('.goog-te-combo');
        if (googleSelect && googleSelect.value !== lang) {
            googleSelect.value = lang;
            googleSelect.dispatchEvent(new Event('change'));
        }

        // fallback된 값까지 포함해서 저장
        localStorage.setItem('selectedLanguage', lang);
    }

    // 커스텀 셀렉트 변경 시 언어 저장 및 적용
    selects.forEach(sel => {
        sel.addEventListener('change', () => {
            const lang = sel.value;
            localStorage.setItem('selectedLanguage', lang);
            applyLang(lang);
        });
    });

    // 필요하면 여기 init 부분 다시 살려도 됨
    const storedLang = localStorage.getItem('selectedLanguage');
    const initLang = storedLang || selects[0]?.value || 'ko';
    applyLang(initLang);

    // MutationObserver 부분도 필요하면 주석 해제해서 사용
    const observer = new MutationObserver(() => {
        const googleSelect = document.querySelector('.goog-te-combo');
        if (googleSelect) {
            const lang = localStorage.getItem('selectedLanguage') || initLang;
            applyLang(lang);
            observer.disconnect();
        }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });

});

function googleTranslateElementInit() {
    var storedLang = localStorage.getItem('selectedLanguage') || 'ko';

    new google.translate.TranslateElement(
        {
            // pageLanguage: 'ko',
            includedLanguages: 'ko,de,ru,vi,es,en,it,id,ja,zh-CN,zh-TW,th,fr',
            layout: google.translate.TranslateElement.InlineLayout.VERTICAL
        },
        'google_translate_element'
    );

    // 구글 드롭다운이 만들어진 이후에 처리
    setTimeout(function () {
        var translateDropdown = document.querySelector('.goog-te-combo');
        if (!translateDropdown) return;

        // 1) 최초 로드 시 : ko 이면 번역 아예 안 함 (원문 유지)
        if (storedLang !== 'ko') {
            translateDropdown.value = storedLang;
            translateDropdown.dispatchEvent(new Event('change'));
        } else {
            // ko 이면 저장도 지우고, 구글 번역 쿠키도 제거해서 자동 번역 막기
            localStorage.removeItem('selectedLanguage');
            clearGoogleTranslateCookie();
        }

        // 2) 사용자가 언어 바꿀 때 처리
        translateDropdown.addEventListener('change', function () {
            var selectedLang = translateDropdown.value;

            // 한국어 선택 = 원문 보기
            if (selectedLang === 'ko') {
                localStorage.removeItem('selectedLanguage');
                restoreOriginalPage(); // 원문 복귀
            } else {
                localStorage.setItem('selectedLanguage', selectedLang);
            }
        });
    }, 500);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
if ( typeof(g_sAppScheme)           == "undefined" )      g_sAppScheme          = "";
if ( typeof(g_sAndroidPackageName)  == "undefined" )      g_sAndroidPackageName = "kr.imgtech.zoneplayer";
if ( typeof(g_sAppReqVerIOS)        == "undefined" )      g_sAppReqVerIOS       = "0";
if ( typeof(g_sAppReqVerAndroid)    == "undefined" )      g_sAppReqVerAndroid   = "0";
if ( typeof(g_nChromeIntentCallVer) == "undefined" )      g_nChromeIntentCallVer = 0;

///////////////////////////////////////////////////////////////////////////////////////////////////
if ( typeof(ZONE_APP_TITLE)     == "undefined" )    ZONE_APP_TITLE      = "존플레이어";
if ( typeof(ZONE_APPSTORE_URL)  == "undefined" )    ZONE_APPSTORE_URL   = "https://itunes.apple.com/in/app/ibooks/id1026414449?mt=8";
if ( typeof(ZONE_APP_MSG_ANDROID_INSTALL_CONFIRM) == "undefined" )    ZONE_APP_MSG_ANDROID_INSTALL_CONFIRM  = (ZONE_APP_TITLE + "를 설치하시면 서비스를 이용할 수 있습니다.\n설치 하시겠습니까?");
ZONE_PLAYSTORE_URL  = "market://details?id=" + g_sAndroidPackageName;

///////////////////////////////////////////////////////////////////////////////////////////////////
if ( typeof(g_bHybridApp)   == "undefined" )         g_bHybridApp            = false;
if ( typeof(g_bCallToURLScheme)   == "undefined" )   g_bCallToURLScheme      = true;
if ( typeof(g_bCallToPostMsg)   == "undefined" )     g_bCallToPostMsg        = false;
if ( ! g_bHybridApp ){
    if ( ! g_bCallToURLScheme )   g_bCallToURLScheme = true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
var g_ZP_IOS_bInstallCheck          = false;
var g_ZP_IOS_uInstallTimer          = 0;
var g_ZP_IOS_nInstallTimerInterval  = (1000 * 7);

///////////////////////////////////////////////////////////////////////////////////////////////////
var g_ZP_Android_nInstallTimerInterval  = 2500;

///////////////////////////////////////////////////////////////////////////////////////////////////
if ( typeof(g_bZonePlayerLogonUse) == "undefined" )   var g_bZonePlayerLogonUse = 0;

///////////////////////////////////////////////////////////////////////////////////////////////////
var g_sOS     = "";
var g_IsIOS     = false;
var g_IsAndroid = false;
var g_IsWindows = false;
var g_IsOSX     = false;
var g_IsChrome  = false;

function ZoneBroswerChecker()
{
    g_IsIOS     = false;
    g_IsAndroid = false;
    g_IsWindows = false;
    g_IsOSX     = false;
    g_IsChrome  = false;

    g_sOS       = ZoneGetOS();
    switch(g_sOS)
    {
        case "WINDOWS":     g_IsWindows     = true;     break;
        case "ANDROID":     g_IsAndroid     = true;     break;
        case "IOS":         g_IsIOS         = true;     break;
        case "OSX":         g_IsOSX         = true;     break;
        default:    break;
    }

    var sUserAgent = navigator.userAgent;	
    sUserAgent  = sUserAgent.toLowerCase();

    if ( sUserAgent.indexOf("chrome") >= 0 ||
         sUserAgent.indexOf("crios")  >= 0 )
    {
        g_IsChrome  = true;
    }
}

////////////////////////////////////////////////////////////////////////////////
function ZoneISOSMobile() {
    switch(ZoneGetOS())
    {
        case "WINDOWS":     return false;
        case "ANDROID":     return true;
        case "IOS":         return true;
        case "OSX":         return false;
        default:    break;
    }
    return false;
}

////////////////////////////////////////////////////////////////////////////////
function ZoneGetOS() 
{
    var userAgent = navigator.userAgent || navigator.vendor || window.opera;
    // Windows Phone must come first because its UA also contains "Android"
    if (/windows/i.test(userAgent)) {
        if (/windows phone/i.test(userAgent)) {
            return "WINDOWSPHONE";
        }
        return "WINDOWS";
    }

    if (/android/i.test(userAgent)) {
        return "ANDROID";
    }

    // iOS detection from: http://stackoverflow.com/a/9039885/177710
    if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
        return "IOS";
    }

    if (/OS X|Mac/.test(userAgent)) {
        if(navigator.maxTouchPoints>0) {
            return "IOS";
        }
        return "OSX";
    }

//iPadOS:
//Safari: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15)   AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0         Safari/605.1.15

//MacOS Catalina:
//Safari: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_0) AppleWebKit/537.36   (KHTML, like Gecko) Chrome/75.0.3770.100 Safari/537.36
    return "";
}

///////////////////////////////////////////////////////////////////////////////////////
ZoneBroswerChecker();

///////////////////////////////////////////////////////////////////////////////////////
function ZoneGetDevice()
{
    return g_sOS;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// IOS
///////////////////////////////////////////////////////////////////////////////////////////////////
var g_fIOSVersion = null;

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneGetIOSVersion()
{
    if ( g_fIOSVersion == null )
    {
        try {
            var v=(navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
            g_fIOSVersion=(isNaN(parseInt(v[1],10))? 0:parseInt(v[1],10));
            g_fIOSVersion+=(isNaN(parseInt(v[2],10))? 0:parseInt(v[2],10)*0.1);
            g_fIOSVersion+=(isNaN(parseInt(v[3],10))? 0:parseInt(v[3],10)*0.01);
        }
        catch(e) {
            g_fIOSVersion = 10.3;
        }
    }
    return g_fIOSVersion;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
var g_dateIOSExecute = new Date();

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneIOSExecute(sURL)
{
    if ( (!g_bHybridApp) && (theZoneApp() == null) ) {
        g_dateIOSExecute = new Date();
        if ( g_ZP_IOS_uInstallTimer != 0 )
        {
            clearTimeout(g_ZP_IOS_uInstallTimer);
            g_ZP_IOS_uInstallTimer = 0;
        }
        g_ZP_IOS_bInstallCheck = false;
        g_ZP_IOS_uInstallTimer = setTimeout(function()
        {
            var date = new Date();
            var nGap = date - g_dateIOSExecute;
        
            if ( nGap > ( g_ZP_IOS_nInstallTimerInterval + 1000 * 3) )
                return;

            if (!g_ZP_IOS_bInstallCheck) {
                top.window.location = ZONE_APPSTORE_URL;
            }
        }, g_ZP_IOS_nInstallTimerInterval);
    }

    ZoneIOSAppOpen(sURL);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneIOSAppOpen(sURL)
{
    //top.window.location = sURL;
    top.window.document.location.href = sURL;
    
    //var fIOSVersion = ZoneGetIOSVersion();
    //if      ( fIOSVersion >= 9.2) 
    //{
    //    top.window.open('http://.../index.html?' + sURL.replace('zoneplayer', ''));
    //}
    //else if ( fIOSVersion >= 9) 
    //	top.window.location.href = 'http://.../index.html?' + sURL.replace('zoneplayer', '');
	//else
    //    top.window.location = sURL;
}

function ZoneIsIOS() 
{
    var ua = navigator.userAgent.toLowerCase();

    if (/os x|mac/.test(ua)) {
        if(navigator.maxTouchPoints>0) {
            return true;
        }
    }

    var regExp = /ipad|iphone|ipod/i;
    return (!!ua.match(regExp));
}

function ZoneIsSafari() 
{
     var ua = navigator.userAgent.toLowerCase();
     return (ua.indexOf('safari') >= 0 && ua.indexOf('chrome') < 0 && ua.indexOf('android') < 0);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
window.onblur = function()
{
    if(ZoneIsIOS()) {
        if(ZoneIsSafari()) {
            if(window.document.visibilityState == "hidden"){
                g_ZP_IOS_bInstallCheck = true;
                clearTimeout(g_ZP_IOS_uInstallTimer);
            }
            return;
        }
    }

    g_ZP_IOS_bInstallCheck = true;
    clearTimeout(g_ZP_IOS_uInstallTimer);
}

function queryStringToJSONString(qs) {
    qs = qs || location.search.slice(1);

    var pairs = qs.split('&');
    var result = {};
    pairs.forEach(function(p) {
        var pair = p.split('=');
        var key = pair[0];
        var value = decodeURIComponent(pair[1] || '');

        if( result[key] ) {
            if( Object.prototype.toString.call( result[key] ) === '[object Array]' ) {
                result[key].push( value );
            } else {
                result[key] = [ result[key], value ];
            }
        } else {
            result[key] = value;
        }
    });

    return JSON.stringify(result);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function queryStringToJSON(qs) {
    return JSON.parse(queryStringToJSONString(qs));
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Android
///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneAndroidExecute(sURL)
{
    try {
        document.ZoneFrameAppIns.location=sURL;
    }
    catch(e) {
        top.window.location = sURL;
    }

    if ( (!g_bHybridApp) && (theZoneApp() == null) ) {
        setTimeout("ZoneAndroidInstall()", g_ZP_Android_nInstallTimerInterval);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneChromeExecute(sURL)
{
    try {
        document.ZoneFrameAppIns.location=sURL;
    }
    catch(e) {
        top.window.location = sURL;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Android
///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneAndroidInstall() 
{
    try 
    {
        var objZonePlayerFrameAppIns = document.ZoneFrameAppIns.document.body;
        var objZonePlayerDivAppIns   = document.getElementById("ZoneDivAppIns");
    } 
    catch (e) 
    {
        if ( confirm(ZONE_APP_MSG_ANDROID_INSTALL_CONFIRM) ) 
        {
            location.href = ZONE_PLAYSTORE_URL;
            return false;
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// Common Utils
///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneGetChromeVersion()
{
    var sVersion = "0.0.0.0";
    var bChrome  = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
    if (bChrome)
    {
        sVersion = parseInt(window.navigator.appVersion.match(/Chrome\/(\d+)\./)[1], 10);
    } 
    return sVersion;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
var g_theZoneApp = null;
// 하위버젼 호환성을 위해서 제작
function theZoneAPP(){
    return theZoneApp()
}

function theZoneApp()
{
    if ( g_theZoneApp != null ){
        return g_theZoneApp;
    }
    if ( g_IsIOS ){
        try{
            if ( typeof(window.webkit.messageHandlers[g_sAppPostName]) != "undefined" ){
                g_theZoneApp = window.webkit.messageHandlers[g_sAppPostName];
                return g_theZoneApp;
            }
            if ( typeof(window.webkit.messageHandlers[g_sAppScheme]) != "undefined" ){
                g_theZoneApp = window.webkit.messageHandlers[g_sAppScheme];
                return g_theZoneApp;
            }
        }
        catch(e){
        }
        return null;
    }
    else {
        try{
            if ( typeof(window[g_sAppPostName]) != "undefined" ){
                g_theZoneApp = window[g_sAppPostName];
                return g_theZoneApp;
            }
            if ( typeof(window[g_sAppScheme]) != "undefined" ){
                g_theZoneApp = window[g_sAppScheme];
                return g_theZoneApp;
            }
        }
        catch(e){
        }
        return null;
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// 하위버젼 호환성을 위해 제작
function ZoneAPPCommand(bIOS, bChrome, sURL, bCallToURLScheme, bCallToPostMsg){
    return ZoneAppCommand(bIOS, bChrome, sURL, bCallToURLScheme, bCallToPostMsg)
}

function ZoneAppCommand(bIOS, bChrome, sURL, bCallToURLScheme, bCallToPostMsg)
{
    if ( typeof(bCallToURLScheme) == "undefined" )  bCallToURLScheme = g_bCallToURLScheme;
    if ( typeof(bCallToPostMsg) == "undefined" )  bCallToPostMsg = g_bCallToPostMsg;

    if ( bCallToPostMsg ){
        if ( theZoneApp() == null ){
            bCallToPostMsg = false;
        }
        
        if ( bCallToPostMsg ){
            return ZoneNativePostMessage(sURL);
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    if ( bCallToURLScheme ) {
        if ( bIOS ){
            ZoneIOSExecute(sURL);
        }
        else{
            if ( bChrome ){
                ZoneChromeExecute(sURL);
            }
            else {
                ZoneAndroidExecute(sURL);
            }
        }
    }
    else{
        return ZoneNativeCommand("Execute", 0, 0, 0, sURL, "", "");
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneNativePostMessage(sURL)
{
    theZoneApp().postMessage( g_IsIOS ? JSON.parse(sURL) : sURL);
    return "";
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneNativeCommand(sCommand, nParam1, nParam2, nParam3, sParam1, sParam2, sParam3)
{
    var sResult = "";
    sResult = ZoneApp.Command(sCommand, nParam1, nParam2, nParam3, sParam1, sParam2, sParam3);
    return sResult;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneGenAppCommand(sCommand, sParam, sCallback, bCallToURLScheme, bCallToPostMsg, bParamURLEncode, bKSHFormat)
{
    if ( typeof(sCallback) == "undefined" )         sCallback = "";
    if ( typeof(bCallToURLScheme) == "undefined" )  bCallToURLScheme = g_bCallToURLScheme;
    if ( typeof(bCallToPostMsg) == "undefined" )    bCallToPostMsg = g_bCallToPostMsg;
    if ( typeof(bParamURLEncode) == "undefined" )   bParamURLEncode = false;

    if ( bCallToURLScheme ) {
        if (g_sAppScheme.length == 0) {
		    alert("App Scheme 정의를 먼저 합니다.");
		    return "";
	    }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    var sNewURLScheme = "";
    if ( bCallToPostMsg ){
        if ( theZoneApp() == null ){
            bCallToPostMsg = false;
        }
        
        if ( bCallToPostMsg ){
            sParam = queryStringToJSONString(sParam);
            sCallback = queryStringToJSONString(sCallback);

            sNewURLScheme =  
            "{" + 
                "\"req-version\" : \"" + (g_IsIOS ? g_sAppReqVerIOS : g_sAppReqVerAndroid) + "\"," + 
                "\"action\" : \"" + sCommand + "\"," + 
                "\"callback\"  : " + sCallback + "," + 
                "\"param\"  : " + sParam + 
            "}";

            return sNewURLScheme;
        }
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    if ( sParam != "" ){
        sParam += "&";
    }
    
    if ( sCallback != "" ){
        sParam += ("callback=" + encodeURIComponent(sCallback) + "&");
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////
    sParam += "req-version=";
    sParam += g_IsIOS ? g_sAppReqVerIOS : g_sAppReqVerAndroid;
    
    ///////////////////////////////////////////////////////////////////////////////////////////////
    sNewURLScheme = ZoneURLSchemeCommand(sCommand, sParam, bCallToURLScheme, bParamURLEncode, bKSHFormat);
    return sNewURLScheme;
}

///////////////////////////////////////////////////////////////////////////////////////////
function ZoneURLSchemeCommand(sCommand, sParam, bCallToURLScheme, bParamURLEncode, bKSHFormat)
{
    if ( typeof(bCallToURLScheme)   == "undefined" )                    bCallToURLScheme = true;
    if ( typeof(bParamURLEncode)    == "undefined" )                    bParamURLEncode = false;
    if ( typeof(bKSHFormat)         == "undefined" || (!g_IsAndroid) )  bKSHFormat = false;
    
    if ( bParamURLEncode ) sParam = encodeURIComponent(sParam);

    var sNewURLScheme;
    if ( bCallToURLScheme ) {
        if (g_IsChrome && (!g_IsIOS)) {
    	    if ( g_nChromeIntentCallVer == 0 || bKSHFormat ){
    	        sNewURLScheme = "intent://" + sCommand + "?" + 
                    ( bParamURLEncode ? encodeURIComponent(sParam) : sParam ) + 
                    "#Intent;scheme="  + g_sAppScheme +  ";package=" + g_sAndroidPackageName + ";end";
            }
            else {
                sNewURLScheme = "intent://" + g_sAppScheme + "/" + sCommand + "?"  + 
                ( bParamURLEncode ? encodeURIComponent(sParam) : sParam )
                +  "#Intent;scheme="  + g_sAppScheme +  ";package=" + g_sAndroidPackageName + ";end";
            }

        } else {
            if ( ! bKSHFormat ){
                sNewURLScheme = g_sAppScheme + "://" + sCommand + "?" + ( bParamURLEncode ? encodeURIComponent(sParam) : sParam );
            }
            else{
                sNewURLScheme = sCommand + "://" + "?" + ( bParamURLEncode ? encodeURIComponent(sParam) : sParam );
            }
        }
    }
    else{
        if ( ! bKSHFormat ){
            sNewURLScheme = g_sAppScheme + "://" + sCommand + "?" + sParam;
        }
        else{
            sNewURLScheme = sCommand + "://" + "?" + sParam;
        }
    }
    return sNewURLScheme;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneAppSchemeExecute(sCommand, sParam)
{
    return ZoneAppExecute(sCommand, sParam, sCallback, true, false)
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneAppExecute(sCommand, sParam, sCallback, bCallToURLScheme, bCallToPostMsg)
{
    sCmd = ZoneGenAppCommand(sCommand, sParam, sCallback, bCallToURLScheme, bCallToPostMsg);
    return ZoneAppCommand(g_IsIOS, g_IsChrome, sCmd, bCallToURLScheme, bCallToPostMsg);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZoneAppMakeCallback(arguments, CallbackID)
{
    var sFuncName   = "On" + g_ZoneUtils.getFunctionName(arguments);
    var sCallbackID = typeof(CallbackID) == "undefined" ? "" : CallbackID;
    var sCallback  = "fnName=" + sFuncName + "&CallbackID=" + encodeURIComponent(sCallbackID);
    return sCallback;
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function ZongOnPageLoad(){
    var sEle =  "<div style=\"position:fixed;bottom:0px;right:-300px\">" + 
                    "<iframe id=\"ZoneFrameAppIns\" name=\"ZoneFrameAppIns\" width=\"0\" height=\"0\"></iframe>" + 
                    "<div id=\"ZoneDivAppIns\"></div>" +
                "</div>";
    document.body.insertAdjacentHTML('beforeend', sEle);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
if ( g_IsAndroid ){
    if(window.addEventListener){
        window.addEventListener('load', ZongOnPageLoad);
    }
    else{
        window.attachEvent('onload', ZongOnPageLoad)
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
function OnZoneApp(json)
{
    if ( typeof(OnPageZoneApp) != "undefined" ){
        OnPageZoneApp(JSON.parse(decodeURIComponent(json)));
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////
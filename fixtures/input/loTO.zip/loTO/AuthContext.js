import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

const API_BASE_URL = process.env.REACT_APP_API_URL;

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);          // 'admin' | null
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState(localStorage.getItem('auth_token'));

  // role 기반 관리자 여부
  const isAdmin = role === 'admin';

  // 토큰 검증
  const verifyToken = async (authToken) => {
    try {
      const response = await fetch(`${API_BASE_URL}/verify`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'Content-Type': 'application/json',
        },
      });

      if (response.ok) {
        const data = await response.json();
        return { valid: true, user: data.user, role: data.role };
      }
      return { valid: false };
    } catch (error) {
      console.error('Token verification failed:', error);
      return { valid: false };
    }
  };

  // 로그인 - 관리자/일반 구분 없이 동일한 엔드포인트 사용
  const login = async (username, password) => {
    try {
      setLoading(true);

      const response = await fetch(`${API_BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (response.ok) {
        const { token: newToken, user: newUser, role: newRole } = data;

        localStorage.setItem('auth_token', newToken);
        setToken(newToken);
        setUser(newUser);
        setRole(newRole || null);
        setIsAuthenticated(true);

        return { success: true, role: newRole };
      } else {
        return { success: false, message: data.error || '로그인에 실패했습니다' };
      }
    } catch (error) {
      console.error('Login error:', error);
      return { success: false, message: '네트워크 오류가 발생했습니다' };
    } finally {
      setLoading(false);
    }
  };

  // 로그아웃
  const logout = () => {
    localStorage.removeItem('auth_token');
    setToken(null);
    setUser(null);
    setRole(null);
    setIsAuthenticated(false);
  };

  // 로또 번호 추가 (관리자만 가능)
  const addLottoNumbers = async (numbers) => {
    try {
      if (!token) throw new Error('No authentication token');

      const response = await fetch(`${API_BASE_URL}/admin/add-numbers`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ numbers }),
      });

      const data = await response.json();
      return response.ok
        ? { success: true, data }
        : { success: false, message: data.error || '번호 추가에 실패했습니다' };
    } catch (error) {
      return { success: false, message: '네트워크 오류가 발생했습니다' };
    }
  };

  // 최근 번호 조회 (관리자만)
  const getRecentNumbers = async () => {
    try {
      if (!token) throw new Error('No authentication token');

      const response = await fetch(`${API_BASE_URL}/admin/recent-numbers`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();
      return response.ok
        ? { success: true, data }
        : { success: false, message: data.error || '번호 조회에 실패했습니다' };
    } catch (error) {
      return { success: false, message: '네트워크 오류가 발생했습니다' };
    }
  };

  // 최신 번호 수동 가져오기 (관리자만)
  const fetchLatestNumbers = async () => {
    try {
      if (!token) throw new Error('No authentication token');

      const response = await fetch(`${API_BASE_URL}/admin/fetch-latest`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();
      return response.ok
        ? { success: true, data }
        : { success: false, message: data.error || '최신 번호 가져오기에 실패했습니다' };
    } catch (error) {
      return { success: false, message: '네트워크 오류가 발생했습니다' };
    }
  };

  // 스케줄러 상태 조회 (관리자만)
  const getSchedulerStatus = async () => {
    try {
      if (!token) throw new Error('No authentication token');

      const response = await fetch(`${API_BASE_URL}/admin/scheduler-status`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });

      const data = await response.json();
      return response.ok
        ? { success: true, data }
        : { success: false, message: data.error || '스케줄러 상태 조회에 실패했습니다' };
    } catch (error) {
      return { success: false, message: '네트워크 오류가 발생했습니다' };
    }
  };

  // 앱 마운트 시 저장된 토큰 검증
  useEffect(() => {
    const checkAuthentication = async () => {
      if (token) {
        const result = await verifyToken(token);
        if (result.valid) {
          setIsAuthenticated(true);
          setUser(result.user);
          setRole(result.role || null);
        } else {
          localStorage.removeItem('auth_token');
          setToken(null);
        }
      }
      setLoading(false);
    };

    checkAuthentication();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  const value = {
    isAuthenticated,
    isAdmin,
    user,
    role,
    loading,
    login,
    logout,
    addLottoNumbers,
    getRecentNumbers,
    fetchLatestNumbers,
    getSchedulerStatus,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

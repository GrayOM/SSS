import React from 'react';
import './About.css';

const About = () => {
  return (
    <div className="about-page">
      <div className="about-container">
        <div className="about-header">
          <h1 className="about-title">
            <span className="title-gradient">About Numora</span>
          </h1>
          <p className="about-subtitle">
            AI 기술로 로또 번호를 예측하는 혁신적인 서비스
          </p>
        </div>

        <div className="about-content">
          <section className="about-section">
            <div className="section-header">
              <h2 className="section-title">🧠 AI 기반 예측</h2>
            </div>
            <div className="section-content">
              <p>
                Numora는 딥러닝 기술을 활용하여 과거 로또 당첨 번호를 분석합니다. 
                신경망 모델을 통해 패턴을 학습하고, 확률적 분석을 통해 
                다음 회차의 번호를 예측합니다.
              </p>
              <div className="feature-list">
                <div className="feature-item">
                  <span className="feature-icon">📊</span>
                  <span>과거 1,000회 이상의 데이터 분석</span>
                </div>
                <div className="feature-item">
                  <span className="feature-icon">🎯</span>
                  <span>다중 레이어 신경망 모델</span>
                </div>
                <div className="feature-item">
                  <span className="feature-icon">⚡</span>
                  <span>실시간 번호 생성</span>
                </div>
              </div>
            </div>
          </section>

          <section className="about-section">
            <div className="section-header">
              <h2 className="section-title">🎲 주요 기능</h2>
            </div>
            <div className="section-content">
              <div className="features-grid">
                <div className="feature-card">
                  <div className="card-icon">🔮</div>
                  <h3 className="card-title">5게임 추천</h3>
                  <p className="card-description">
                    한 번에 5게임의 로또 번호를 
                    AI가 분석하여 추천해드립니다
                  </p>
                </div>
                <div className="feature-card">
                  <div className="card-icon">🎨</div>
                  <h3 className="card-title">시각적 표현</h3>
                  <p className="card-description">
                    번호별 색상 구분과 애니메이션으로 
                    직관적인 인터페이스를 제공합니다
                  </p>
                </div>
                <div className="feature-card">
                  <div className="card-icon">📱</div>
                  <h3 className="card-title">반응형 디자인</h3>
                  <p className="card-description">
                    PC와 모바일 모든 환경에서 
                    최적화된 경험을 제공합니다
                  </p>
                </div>
                <div className="feature-card">
                  <div className="card-icon">⚡</div>
                  <h3 className="card-title">빠른 속도</h3>
                  <p className="card-description">
                    클라우드 기반 서버로 
                    빠르고 안정적인 서비스를 제공합니다
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section className="about-section">
            <div className="section-header">
              <h2 className="section-title">⚠️ 중요 안내</h2>
            </div>
            <div className="section-content">
              <div className="warning-box">
                <div className="warning-header">
                  <span className="warning-icon">⚠️</span>
                  <h3>책임감 있는 이용</h3>
                </div>
                <ul className="warning-list">
                  <li>본 서비스는 확률적 분석을 바탕으로 하며, 당첨을 보장하지 않습니다</li>
                  <li>로또는 확률 게임이므로 과도한 구매는 삼가해 주세요</li>
                  <li>여유 자금 내에서 적절한 금액으로 즐기시길 바랍니다</li>
                  <li>AI 예측은 참고용이며, 개인의 판단이 중요합니다</li>
                </ul>
              </div>
            </div>
          </section>

          <section className="about-section">
            <div className="section-header">
              <h2 className="section-title">🚀 기술 스택</h2>
            </div>
            <div className="section-content">
              <div className="tech-stack">
                <div className="tech-category">
                  <h4 className="tech-title">Frontend</h4>
                  <div className="tech-items">
                    <span className="tech-item">React</span>
                    <span className="tech-item">CSS3</span>
                    <span className="tech-item">JavaScript</span>
                  </div>
                </div>
                <div className="tech-category">
                  <h4 className="tech-title">Backend</h4>
                  <div className="tech-items">
                    <span className="tech-item">Python</span>
                    <span className="tech-item">Flask</span>
                    <span className="tech-item">TensorFlow</span>
                  </div>
                </div>
                <div className="tech-category">
                  <h4 className="tech-title">Deployment</h4>
                  <div className="tech-items">
                    <span className="tech-item">Cloudtype</span>
                    <span className="tech-item">Vercel</span>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default About; 
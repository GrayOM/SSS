import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './Navigation.css';

const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { isAuthenticated, isAdmin, user, logout } = useAuth();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);
  const closeMenu = () => setIsMenuOpen(false);

  const isActive = (path) => location.pathname === path;

  const handleLogin = () => {
    closeMenu();
    navigate('/login');
  };

  const handleLogout = () => {
    logout();
    closeMenu();
    navigate('/');
  };

  return (
    <nav className="navigation">
      <div className="nav-container">
        <Link to="/" className="nav-logo" onClick={closeMenu}>
          <div className="logo-frame">
            <img
              src="/logo192.png"
              alt="Numora AI Logo"
              className="logo-image"
              loading="lazy"
            />
            <div className="logo-glow"></div>
          </div>
          <span className="logo-text">
            <span className="logo-main">Numora</span>
            <span className="logo-sub">AI LOTTO</span>
          </span>
        </Link>

        <div className={`nav-menu ${isMenuOpen ? 'nav-menu-active' : ''}`}>
          <Link
            to="/"
            className={`nav-link ${isActive('/') ? 'active' : ''}`}
            onClick={closeMenu}
          >
            <span className="nav-link-text">HOME</span>
          </Link>
          <Link
            to="/about"
            className={`nav-link ${isActive('/about') ? 'active' : ''}`}
            onClick={closeMenu}
          >
            <span className="nav-link-text">ABOUT</span>
          </Link>
          <Link
            to="/contact"
            className={`nav-link ${isActive('/contact') ? 'active' : ''}`}
            onClick={closeMenu}
          >
            <span className="nav-link-text">CONTACT</span>
          </Link>

          {/* 관리자로 로그인 시에만 번호 추가 탭 표시 */}
          {isAdmin && (
            <Link
              to="/admin"
              className={`nav-link admin-link ${isActive('/admin') ? 'active' : ''}`}
              onClick={closeMenu}
            >
              <span className="nav-link-text">
                <span className="admin-icon">⚙️</span>
                번호 관리
              </span>
            </Link>
          )}

          <div className="auth-section">
            {isAuthenticated ? (
              <div className="auth-user">
                <span className="user-greeting">
                  <span className="user-icon">{isAdmin ? '🛡️' : '👤'}</span>
                  {user}
                </span>
                <button className="logout-button" onClick={handleLogout}>
                  <span className="logout-icon">🚪</span>
                  로그아웃
                </button>
              </div>
            ) : (
              /* 보안: "관리자 로그인"이 아닌 일반 "로그인" 버튼으로 표시 */
              <button className="login-button-nav" onClick={handleLogin}>
                <span className="login-icon">👤</span>
                로그인
              </button>
            )}
          </div>
        </div>

        <button
          className="nav-hamburger"
          onClick={toggleMenu}
          aria-label="Toggle navigation menu"
          aria-expanded={isMenuOpen}
        >
          <span className={`hamburger-line ${isMenuOpen ? 'line1' : ''}`}></span>
          <span className={`hamburger-line ${isMenuOpen ? 'line2' : ''}`}></span>
          <span className={`hamburger-line ${isMenuOpen ? 'line3' : ''}`}></span>
        </button>
      </div>

      {isMenuOpen && <div className="nav-overlay" onClick={closeMenu}></div>}
    </nav>
  );
};

export default Navigation;

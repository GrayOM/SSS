import React from 'react';
import './Contact.css';

const Contact = () => {
  return (
    <div className="contact-page">
      <div className="contact-container">
        <div className="contact-header">
          <h1 className="contact-title">
            <span className="title-gradient">Contact Us</span>
          </h1>
          <p className="contact-subtitle">
            궁금한 점이 있으시면 언제든지 연락주세요
          </p>
        </div>

        <div className="contact-content">
          <div className="contact-cards">
            <div className="contact-card">
              <div className="card-icon">📧</div>
              <h3 className="card-title">이메일</h3>
              <p className="card-content">support@numora.com</p>
              <p className="card-description">
                기술적 문의나 제안사항을 보내주세요
              </p>
            </div>

            <div className="contact-card">
              <div className="card-icon">💬</div>
              <h3 className="card-title">채팅 상담</h3>
              <p className="card-content">평일 09:00 - 18:00</p>
              <p className="card-description">
                실시간 채팅으로 빠른 답변을 받으세요
              </p>
            </div>

            <div className="contact-card">
              <div className="card-icon">🌐</div>
              <h3 className="card-title">GitHub</h3>
              <p className="card-content">github.com/numora</p>
              <p className="card-description">
                오픈소스 프로젝트에 기여해주세요
              </p>
            </div>
          </div>

          <div className="contact-form-section">
            <h2 className="form-title">메시지 보내기</h2>
            <form className="contact-form">
              <div className="form-group">
                <label htmlFor="name">이름</label>
                <input 
                  type="text" 
                  id="name" 
                  name="name" 
                  placeholder="이름을 입력하세요"
                  required 
                />
              </div>

              <div className="form-group">
                <label htmlFor="email">이메일</label>
                <input 
                  type="email" 
                  id="email" 
                  name="email" 
                  placeholder="이메일을 입력하세요"
                  required 
                />
              </div>

              <div className="form-group">
                <label htmlFor="subject">제목</label>
                <input 
                  type="text" 
                  id="subject" 
                  name="subject" 
                  placeholder="제목을 입력하세요"
                  required 
                />
              </div>

              <div className="form-group">
                <label htmlFor="message">메시지</label>
                <textarea 
                  id="message" 
                  name="message" 
                  rows="5"
                  placeholder="메시지를 입력하세요"
                  required
                ></textarea>
              </div>

              <button type="submit" className="submit-button">
                <span className="button-text">메시지 보내기</span>
                <div className="button-glow"></div>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact; 
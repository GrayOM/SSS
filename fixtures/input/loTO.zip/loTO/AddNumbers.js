import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import './AddNumbers.css';

const AddNumbers = () => {
  const navigate = useNavigate();
  const { isAuthenticated, isAdmin, addLottoNumbers, getRecentNumbers, fetchLatestNumbers, getSchedulerStatus, user } = useAuth();

  const [numbers, setNumbers] = useState(['', '', '', '', '', '']);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState({ type: '', text: '' });
  const [recentNumbers, setRecentNumbers] = useState([]);
  const [totalCount, setTotalCount] = useState(0);

  // 자동 업데이트 스케줄러 상태
  const [schedulerStatus, setSchedulerStatus] = useState(null);
  const [isFetchingLatest, setIsFetchingLatest] = useState(false);
  const [fetchMessage, setFetchMessage] = useState({ type: '', text: '' });

  // 미인증 또는 비관리자 접근 차단
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    } else if (!isAdmin) {
      navigate('/');
    }
  }, [isAuthenticated, isAdmin, navigate]);

  const loadRecentNumbers = useCallback(async () => {
    const result = await getRecentNumbers();
    if (result.success) {
      setRecentNumbers(result.data.numbers || []);
      setTotalCount(result.data.total_count || 0);
    }
  }, [getRecentNumbers]);

  const loadSchedulerStatus = useCallback(async () => {
    const result = await getSchedulerStatus();
    if (result.success) {
      setSchedulerStatus(result.data);
    }
  }, [getSchedulerStatus]);

  useEffect(() => {
    if (isAuthenticated && isAdmin) {
      loadRecentNumbers();
      loadSchedulerStatus();
    }
  }, [isAuthenticated, isAdmin, loadRecentNumbers, loadSchedulerStatus]);

  const handleNumberChange = (index, value) => {
    const numValue = value.replace(/[^0-9]/g, '');
    if (numValue === '' || (parseInt(numValue) >= 1 && parseInt(numValue) <= 45)) {
      const newNumbers = [...numbers];
      newNumbers[index] = numValue;
      setNumbers(newNumbers);
      if (message.text) setMessage({ type: '', text: '' });
    }
  };

  const handleKeyPress = (index, e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      if (index < 5) {
        const nextInput = document.getElementById(`number-${index + 1}`);
        if (nextInput) nextInput.focus();
      } else {
        handleSubmit(e);
      }
    }
  };

  const validateNumbers = () => {
    const filledNumbers = numbers.filter((num) => num !== '');
    if (filledNumbers.length !== 6) {
      return { valid: false, message: '6개의 번호를 모두 입력해주세요' };
    }
    const invalidNumbers = numbers.filter((num) => {
      const n = parseInt(num);
      return n < 1 || n > 45;
    });
    if (invalidNumbers.length > 0) {
      return { valid: false, message: '번호는 1-45 범위여야 합니다' };
    }
    const uniqueNumbers = new Set(numbers);
    if (uniqueNumbers.size !== 6) {
      return { valid: false, message: '중복된 번호가 있습니다' };
    }
    return { valid: true, message: '' };
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const validation = validateNumbers();
    if (!validation.valid) {
      setMessage({ type: 'error', text: validation.message });
      return;
    }

    setIsSubmitting(true);
    setMessage({ type: '', text: '' });

    try {
      const numberArray = numbers.map((num) => parseInt(num));
      const result = await addLottoNumbers(numberArray);

      if (result.success) {
        setMessage({
          type: 'success',
          text: `번호가 성공적으로 추가되었습니다: ${result.data.numbers.join(', ')}`,
        });
        setNumbers(['', '', '', '', '', '']);
        await loadRecentNumbers();
      } else {
        setMessage({ type: 'error', text: result.message });
      }
    } catch {
      setMessage({ type: 'error', text: '네트워크 오류가 발생했습니다' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRandomGenerate = () => {
    const randomNumbers = [];
    while (randomNumbers.length < 6) {
      const randomNum = Math.floor(Math.random() * 45) + 1;
      if (!randomNumbers.includes(randomNum)) randomNumbers.push(randomNum);
    }
    setNumbers(randomNumbers.sort((a, b) => a - b).map(String));
    setMessage({ type: '', text: '' });
  };

  const handleClear = () => {
    setNumbers(['', '', '', '', '', '']);
    setMessage({ type: '', text: '' });
  };

  // 동행복권 API에서 최신 번호 자동 가져오기
  const handleFetchLatest = async () => {
    setIsFetchingLatest(true);
    setFetchMessage({ type: '', text: '' });

    try {
      const result = await fetchLatestNumbers();

      if (result.success) {
        const { status, added_count, message: msg } = result.data;

        if (status === 'up_to_date') {
          setFetchMessage({ type: 'info', text: `✅ ${msg}` });
        } else if (status === 'updated') {
          setFetchMessage({
            type: 'success',
            text: `🎉 ${added_count}개 회차의 번호가 자동으로 추가되었습니다!`,
          });
          await loadRecentNumbers();
        } else {
          setFetchMessage({ type: 'error', text: `⚠️ 일부 회차를 가져오지 못했습니다` });
        }
        // 스케줄러 상태도 갱신
        await loadSchedulerStatus();
      } else {
        setFetchMessage({ type: 'error', text: result.message });
      }
    } catch {
      setFetchMessage({ type: 'error', text: '네트워크 오류가 발생했습니다' });
    } finally {
      setIsFetchingLatest(false);
    }
  };

  const getStatusColor = (status) => {
    if (!status) return '#888';
    switch (status) {
      case 'updated': return '#00ff88';
      case 'up_to_date': return '#00ffff';
      case 'error': return '#ff6b6b';
      default: return '#888';
    }
  };

  const formatDate = (isoString) => {
    if (!isoString) return '-';
    const d = new Date(isoString);
    return d.toLocaleString('ko-KR', {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit',
    });
  };

  if (!isAuthenticated || !isAdmin) return null;

  return (
    <div className="add-numbers-page">
      <div className="add-numbers-container">
        <div className="page-header">
          <h1 className="page-title">
            <span className="title-gradient">로또 번호 관리</span>
          </h1>
          <p className="page-subtitle">
            관리자: <span className="user-name">{user}</span>
          </p>
          <div className="stats-info">
            총 {totalCount}개의 번호가 등록되어 있습니다
          </div>
        </div>

        {/* ── 자동 업데이트 패널 ── */}
        <div className="auto-update-panel">
          <div className="panel-header">
            <h2 className="panel-title">
              <span className="panel-icon">🤖</span>
              자동 업데이트 시스템
            </h2>
            <div className="scheduler-badge">
              {schedulerStatus?.scheduler_running ? (
                <span className="badge-active">● 스케줄러 실행 중</span>
              ) : (
                <span className="badge-inactive">○ 스케줄러 비활성</span>
              )}
            </div>
          </div>

          <div className="auto-update-info">
            <div className="info-item">
              <span className="info-label">자동 실행 주기</span>
              <span className="info-value">매주 토요일 오후 9:30 (KST)</span>
            </div>
            <div className="info-item">
              <span className="info-label">데이터 출처</span>
              <span className="info-value">동행복권 공식 API</span>
            </div>
            {schedulerStatus?.next_run && (
              <div className="info-item">
                <span className="info-label">다음 실행</span>
                <span className="info-value">{formatDate(schedulerStatus.next_run)}</span>
              </div>
            )}
            {schedulerStatus?.last_fetch && (
              <div className="info-item">
                <span className="info-label">마지막 실행</span>
                <span className="info-value" style={{ color: getStatusColor(schedulerStatus.last_fetch.status) }}>
                  {formatDate(schedulerStatus.last_fetch.timestamp)}
                  {' '}({schedulerStatus.last_fetch.status})
                </span>
              </div>
            )}
          </div>

          {fetchMessage.text && (
            <div className={`fetch-message ${fetchMessage.type}`}>
              {fetchMessage.text}
            </div>
          )}

          <button
            className={`fetch-button ${isFetchingLatest ? 'loading' : ''}`}
            onClick={handleFetchLatest}
            disabled={isFetchingLatest}
          >
            {isFetchingLatest ? (
              <>
                <div className="button-spinner-small"></div>
                <span>가져오는 중...</span>
              </>
            ) : (
              <>
                <span>🔄</span>
                <span>지금 최신 번호 가져오기</span>
              </>
            )}
          </button>
        </div>

        <div className="content-grid">
          {/* ── 번호 수동 입력 ── */}
          <div className="input-section">
            <div className="section-header">
              <h2 className="section-title">번호 직접 추가</h2>
              <div className="action-buttons">
                <button
                  type="button"
                  className="random-button"
                  onClick={handleRandomGenerate}
                  disabled={isSubmitting}
                >
                  🎲 랜덤 생성
                </button>
                <button
                  type="button"
                  className="clear-button"
                  onClick={handleClear}
                  disabled={isSubmitting}
                >
                  🗑️ 초기화
                </button>
              </div>
            </div>

            {message.text && (
              <div className={`message ${message.type}`}>
                <span className="message-icon">
                  {message.type === 'success' ? '✅' : '⚠️'}
                </span>
                {message.text}
              </div>
            )}

            <form className="numbers-form" onSubmit={handleSubmit}>
              <div className="numbers-grid">
                {numbers.map((number, index) => (
                  <div key={index} className="number-input-container">
                    <label htmlFor={`number-${index}`} className="number-label">
                      {index + 1}번
                    </label>
                    <input
                      type="text"
                      id={`number-${index}`}
                      value={number}
                      onChange={(e) => handleNumberChange(index, e.target.value)}
                      onKeyPress={(e) => handleKeyPress(index, e)}
                      className="number-input"
                      placeholder="1-45"
                      maxLength="2"
                      disabled={isSubmitting}
                    />
                  </div>
                ))}
              </div>

              <button
                type="submit"
                className={`submit-button ${isSubmitting ? 'submitting' : ''}`}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <div className="button-spinner"></div>
                    <span>추가 중...</span>
                  </>
                ) : (
                  <>
                    <span className="button-icon">💾</span>
                    <span>번호 추가</span>
                  </>
                )}
              </button>
            </form>
          </div>

          {/* ── 최근 번호 목록 ── */}
          <div className="recent-section">
            <div className="section-header">
              <h2 className="section-title">최근 추가된 번호</h2>
            </div>

            <div className="recent-numbers-list">
              {recentNumbers.length > 0 ? (
                recentNumbers.map((numberSet, index) => (
                  <div key={index} className="recent-number-item">
                    <div className="number-set">
                      {numberSet.map((num, numIndex) => (
                        <span key={numIndex} className="recent-number">
                          {num}
                        </span>
                      ))}
                    </div>
                    <div className="number-rank">#{recentNumbers.length - index}</div>
                  </div>
                ))
              ) : (
                <div className="no-numbers">아직 추가된 번호가 없습니다</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddNumbers;

import React from 'react';
import HeroSection from '../components/HeroSection';
import './Home.css';

const Home = () => {
  return (
    <div className="home-page">
      <HeroSection />
    </div>
  );
};

export default Home; 
import React from 'react';
import './LottoNumbers.css';

const LottoNumbers = ({ numbers, gameIndex, isAnimating }) => {
  if (!numbers || numbers.length !== 6) {
    return null;
  }

  const getBallColor = (number) => {
    if (number <= 10) return 'yellow';
    if (number <= 20) return 'blue';
    if (number <= 30) return 'red';
    if (number <= 40) return 'gray';
    return 'green';
  };

  return (
    <div className="lotto-game">
      <div className="game-header">
        <span className="game-number">Game {gameIndex + 1}</span>
      </div>
      <div className="lotto-numbers-container">
        {numbers.map((number, index) => (
          <div
            key={index}
            className={`lotto-ball ${getBallColor(number)} ${isAnimating ? 'animating' : ''}`}
            style={{
              animationDelay: `${index * 0.2}s`
            }}
          >
            <span className="ball-number">{number}</span>
            <div className="ball-shine"></div>
          </div>
        ))}
      </div>
    </div>
  );
};

const LottoNumbersList = ({ predictions, isLoading }) => {
  if (isLoading) {
    return (
      <div className="lotto-loading">
        <div className="loading-spinner"></div>
        <p>AI가 행운의 번호를 찾고 있습니다...</p>
      </div>
    );
  }

  if (!predictions || predictions.length === 0) {
    return (
      <div className="lotto-empty">
        <p>번호를 생성해주세요</p>
      </div>
    );
  }

  return (
    <div className="lotto-results">
      <h2 className="results-title">
        <span className="title-gradient">AI 추천 번호</span>
      </h2>
      <div className="games-container">
        {predictions.map((numbers, index) => (
          <LottoNumbers
            key={index}
            numbers={numbers}
            gameIndex={index}
            isAnimating={true}
          />
        ))}
      </div>
    </div>
  );
};

export default LottoNumbersList; 
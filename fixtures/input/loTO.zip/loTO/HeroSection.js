import React from 'react';
import { useNavigate } from 'react-router-dom';
import './HeroSection.css';

const HeroSection = () => {
  const navigate = useNavigate();

  const handleGenerateLotto = () => {
    navigate('/result');
  };

  return (
    <section className="hero-section">
      <div className="hero-background">
        <div className="floating-numbers">
          {[7, 14, 21, 28, 35, 42].map((number, index) => (
            <div
              key={index}
              className="floating-number"
              style={{
                left: `${Math.random() * 100}%`,
                animationDelay: `${index * 0.5}s`,
                animationDuration: `${4 + Math.random() * 2}s`
              }}
            >
              {number}
            </div>
          ))}
        </div>
      </div>

      <div className="hero-content">
        <div className="hero-text">
          <h1 className="hero-title">
            <span className="title-line">AI가 예측하는</span>
            <span className="title-line highlight">행운의 번호</span>
          </h1>
          <p className="hero-subtitle">
            딥러닝 기술로 분석한 로또 번호를 지금 바로 받아보세요
          </p>
          <div className="hero-features">
            <div className="feature-item">
              <div className="feature-icon">🧠</div>
              <span>AI 분석</span>
            </div>
            <div className="feature-item">
              <div className="feature-icon">📊</div>
              <span>데이터 기반</span>
            </div>
            <div className="feature-item">
              <div className="feature-icon">🎯</div>
              <span>5게임 추천</span>
            </div>
          </div>
        </div>

        <div className="hero-action">
          <button className="generate-button" onClick={handleGenerateLotto}>
            <span className="button-text">로또 번호 추천받기</span>
            <div className="button-glow"></div>
            <div className="button-particles">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="particle"></div>
              ))}
            </div>
          </button>
          <p className="button-subtitle">
            무료로 AI 추천 번호를 받아보세요
          </p>
        </div>
      </div>

      <div className="hero-decoration">
        <div className="decoration-circle circle-1"></div>
        <div className="decoration-circle circle-2"></div>
        <div className="decoration-circle circle-3"></div>
      </div>
    </section>
  );
};

export default HeroSection; 
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import LottoNumbersList from '../components/LottoNumbers';
import './Result.css';

const Result = () => {
  const navigate = useNavigate();
  const [predictions, setPredictions] = useState([]);
  const [currentRound, setCurrentRound] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);

  const API_BASE_URL = process.env.REACT_APP_API_URL;

  const fetchLottoNumbers = useCallback(async () => {
    try {
      setIsLoading(true);
      setError(null);
      
      const response = await fetch(`${API_BASE_URL}/generate-lotto`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.numbers && Array.isArray(data.numbers)) {
        setPredictions(data.numbers);
        setCurrentRound(data.round);
      } else {
        throw new Error('Invalid data format received');
      }
    } catch (err) {
      console.error('Failed to fetch lotto numbers:', err);
      setError(err.message);
      // 임시 데이터로 대체 (개발용)
      setPredictions([
        [7, 14, 21, 28, 35, 42],
        [3, 16, 23, 31, 38, 45],
        [2, 11, 19, 27, 33, 41],
        [5, 12, 24, 29, 36, 43],
        [1, 18, 25, 32, 37, 44]
      ]);
      setCurrentRound(1170);
    } finally {
      setIsLoading(false);
    }
  }, [API_BASE_URL]);

  useEffect(() => {
    fetchLottoNumbers();
  }, [fetchLottoNumbers]);

  const handleGoHome = () => {
    navigate('/');
  };

  const handleGenerateAgain = () => {
    fetchLottoNumbers();
  };

  return (
    <div className="result-page">
      <div className="result-container">
        <div className="result-header">
          <button className="back-button" onClick={handleGoHome}>
            ← 홈으로 돌아가기
          </button>
          
          {currentRound && (
            <div className="round-info">
              <span className="round-label">추천 회차</span>
              <span className="round-number">{currentRound}회</span>
            </div>
          )}
        </div>

        <div className="result-content">
          {error && (
            <div className="error-message">
              <p>⚠️ 서버 연결에 실패했습니다</p>
              <p className="error-detail">임시 데이터로 표시됩니다</p>
            </div>
          )}

          <LottoNumbersList 
            predictions={predictions} 
            isLoading={isLoading} 
          />

          {!isLoading && predictions.length > 0 && (
            <div className="result-actions">
              <button 
                className="generate-again-button"
                onClick={handleGenerateAgain}
                disabled={isLoading}
              >
                <span className="button-icon">🎲</span>
                다시 추천받기
              </button>
              
              <div className="result-tip">
                <p className="tip-title">💡 이용 팁</p>
                <ul className="tip-list">
                  <li>AI가 분석한 5게임을 모두 구매하시는 것을 추천합니다</li>
                  <li>번호는 확률적 분석이므로 당첨을 보장하지 않습니다</li>
                  <li>적당한 금액으로 즐기시길 바랍니다</li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Result; 
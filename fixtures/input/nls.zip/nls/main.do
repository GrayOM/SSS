




 

    





 




<!DOCTYPE html>
<html lang="ko" color-theme="light" id="root">
<head>
	
	    
	




 

    





 

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	
	
<title>NIS 국가정보원</title>
<!-- <meta name="viewport" content="width=1400" /> -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description"  content="대한민국 국가정보원 공식 홈페이지" /> 
<meta name="keywords"  content="국가정보원,국정원,NIS,대한민국 국가정보원,nis.go.kr,www.nis.go.kr" />
<meta name="author"  content="NIS 국가정보원" />
<meta name="subject"  content="NIS 국가정보원" />
<meta name="url"  content="https://www.nis.go.kr" />
<meta name="identifier-URL"  content="https://www.nis.go.kr" />
<link rel="shortcut icon" href="/resources/img/favicon/favicon-nis.ico" type="image/x-ico">
<link rel="icon" href="/resources/img/favicon/favicon-nis.ico" type="image/x-ico">
<link rel="favicon" href="/resources/img/favicon/favicon-nis.ico">
<meta property="og:type" content="website" />
<meta property="og:title" content="NIS 국가정보원" />
<meta property="og:description"  content="대한민국 국가정보원 공식 홈페이지" /> 
<meta property="og:url" content="https://www.nis.go.kr" /> 
<meta property="og:site_name" content="NIS 국가정보원" /> 


<meta name="twitter:type" content="website" />
<meta name="twitter:card"  content="summary" />
<meta name="twitter:title"  content="NIS 국가정보원" />
<meta name="twitter:creator"  content="NIS 국가정보원" />
<meta name="twitter:url"  content="https://www.nis.go.kr" />
<meta name="twitter:description"   content="대한민국 국가정보원 공식 홈페이지" />


<meta property="og:image" content="https://www.nis.go.kr:4016/resources/img/renewal_images/light/logo_header_nis.png" /> 
<meta name="twitter:image" content="https://www.nis.go.kr:4016/resources/img/renewal_images/light/logo_header_nis.png" /> 
<link rel="shortcut icon" href="/resources/img/favicon/favicon-nis.ico" type="image/x-ico" />

<!-- <link rel="stylesheet" type="text/css" href="/resources/assets/vendor/jquery-ui-1.12.1/jquery-ui.min.css"> -->
<!-- <link rel="stylesheet" type="text/css" href="/resources/assets/vendor/jquery-ui-1.12.1/jquery-ui.theme.min.css"> -->
<link rel="stylesheet" type="text/css" href="/resources/css/jquery-ui.css" />
<link rel="stylesheet" type="text/css" href="/resources/css/jquery.selectBox.css" />
<link rel="stylesheet" type="text/css" href="/resources/assets/vendor/fullPage/jquery.fullPage.css">
<link rel="stylesheet" type="text/css" href="/resources/assets/vendor/magnific-popup/magnific-popup.css">
<link rel="stylesheet" type="text/css" href="/resources/assets/vendor/slick/slick.css">
<link rel="stylesheet" type="text/css" href="/resources/assets/vendor/slick/slick-theme.css">

<link rel="stylesheet" type="text/css" href="/resources/css/style_renewal.css?version=20251106">

<!--[if IE 8]>
	<link rel="stylesheet" type="text/css" href="/resources/css/style-ie8.css" />
<![endif]-->
<!--[if IE 7]>
	<link rel="stylesheet" type="text/css" href="/resources/css/style-ie7.css" />
<![endif]-->
<script type="application/ld+json">
{ 
"@context": "http://schema.org",
 "@type": "Organization",
 "name": "국가정보원",
 "url": "https://nis.go.kr",
 "sameAs": [
   "https://www.facebook.com/National.Intelligence.Service",
   "https://www.instagram.com/national.intelligence.service"
 ]
}
</script>
<script type="text/javascript" src="/resources/assets/js/jquery.min.js"></script>
<script type="text/javascript" src="/resources/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/resources/js/jquery-ui.js"></script>
<script type="text/javascript" src="/resources/js/jquery.selectBox.js"></script>
<script type="text/javascript" src="/resources/js/application.js"></script>
<script type="text/javascript" src="/resources/js/makePCookie.js"></script>
<script type="text/javascript" src="/resources/js/js_renewal/common.js?v=1.0.2"></script>
<script type="text/javascript" src="/resources/js/js_renewal/common-page.js?v=1.0.2"></script>	
<script type="text/javascript">
$(document).ready(function(){
	
	//datepicker
	$(".datepicker, #from_date, #to_date").datepicker({
		/* showOn: "button",
		buttonImage: "/resources/img/jquery-ui/calendar-icon.png",
		buttonImageOnly: true,
		buttonText: "Select date", */
		prevText: '이전 달',
		nextText: '다음 달',
		monthNames: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
		monthNamesShort: ['1월','2월','3월','4월','5월','6월','7월','8월','9월','10월','11월','12월'],
		dayNames: ['일','월','화','수','목','금','토'],
		dayNamesShort: ['일','월','화','수','목','금','토'],
		dayNamesMin: ['일','월','화','수','목','금','토'],
		dateFormat: 'yy-mm-dd',
		showMonthAfterYear: true,
		yearSuffix: '년',
	});
});
function getCookie(name){
    var wcname = name + '=';
    var wcstart, wcend, end;
    var i = 0;
    while(i <= document.cookie.length) {
        wcstart = i;
        wcend   = (i + wcname.length);
        if(document.cookie.substring(wcstart, wcend) == wcname) {
            if((end = document.cookie.indexOf(';', wcend)) == -1)
                end = document.cookie.length;
            return document.cookie.substring(wcend, end);
        }
        i = document.cookie.indexOf('', i) + 1;
        if(i == 0) {
            break;
        }
    }
    return '';
}
</script>
<!-- <script src="//developers.kakao.com/sdk/js/kakao.min.js"></script> -->
<script type="text/javascript" src="/resources/js/kakao.min.js"></script>

	
</head>
  
<body>
	<ul class="skip-navigation">
        <li><a href="#container">본문 바로가기</a></li>
        <li><a href="#menus_1">주메뉴 바로가기</a></li>
    </ul>
    <div class="wrapper" id="doc">
	    
    <!-- wrap -->
        <div id="header_area">
            <!-- main header -->
			




 

    














<div class="gnb bg-gray10" id="gnb">
    <!-- 2024-08-12 추가&수정[s] -->
	 <div class="header_banner" style="">
		<div class="nuri">
			<div class="ico"></div> 이 누리집은 대한민국 공식 전자정부 누리집입니다.
		</div>
		<!-- <div class="cyberSecurity">
			<div class="inner">
				<div class="hb_logo"></div>
				<div class="txt">
					<p class="bigTxt">AI·양자·우주시대, <strong>글로벌 사이버 안보</strong>를 위한 한발 앞선 노력</p>
					<dl class="mt">
						<dt>일 정</dt>
						<dd>2024.9.10.(화) ~ 12.(목)</dd>
					</dl>
					<dl>
						<dt>장 소</dt>
						<dd>코엑스 컨퍼런스룸(남) 3층/4층 및 컨퍼런스룸E</dd>
					</dl>
				</div>
				<a href="https://cybersummit.kr" target="_new" class="more_link">자세히보기 <i></i></a>
			</div>
			<div class="banner_control">
				<div class="chkBox">
					<input type="checkbox" name="today" id="today">
					<label for="today"><span></span> 오늘 하루 보지 않기</label>
					<button type="button" class="btn_banner_close"></button>
				</div>
			</div>
		</div> -->
	</div> 
	<!-- 2024-08-12 추가&수정[e] -->
    <header>
        <div>
        	<h1>
        		<a class="logo" href="/main.do" title="홈으로 바로가기">
        			<img class="light-logo" src="/resources/img/renewal_images/light/logo_header_nis.png" alt="국가정보원">
        			<img class="dark-logo" src="/resources/img/renewal_images/dark/logo_header_nis.png" alt="국가정보원">
        		</a>
        	</h1>
        </div>
        <nav class="menus" id="menus">
            <div class="menu" id="menus_1">
            	<!-- 250922 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정 -->
                <div class="menu-link"><a href="#" class="txt-subtitle-2-600 font-gray00" data-menu-id="#menu1" aria-haspopup="true" aria-expanded="false">소식ㆍ정보</a></div>
                <div class="sub-menu bg-gray05" id="menu1">
			        <div class="sub-menu-wrapper">
			            <div class="sub-menu-list row">
			                <div class="sub-menu-row">
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/CM/1_3/list.do" class="font-gray01">알림ㆍ소식</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/CM/1_3/list.do" class="">공지사항</a></li>
			                            <li><a href="/CM/1_4/list.do" class="">보도자료</a></li>
			                            <li><a href="/CM/1_10/list.do" class="" rel="nosublink" >NIS NEWS</a></li>
			                            <li><a href="/ID/1_6_2/list.do" class="" rel="nosublink" >입법예고</a></li>
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_6_4/list.do" class="font-gray01" rel="nosublink" >생활 속 정보</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_6_4/list.do" class="" rel="nosublink">대테러용어</a></li>
			                            <!-- <li><a href="/AF/1_6_6.do" class="" rel="nosublink">여행금지국 방문자 교육</a></li> -->
			                            <li><a href="/AF/1_7_4.do" class="" rel="nosublink">정보보안 생활수칙</a></li>
			                            <li><a href="/AF/1_8_3.do" class="" rel="nosublink">국제범죄 예방요령</a></li>
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/CM/1_2_3.do?category=111신고" class="font-gray01">동영상</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/CM/1_2_3.do?category=111신고" class="" rel="nosublink">院 홍보ㆍ111신고</a></li>
			                            <li><a href="/CM/1_2_3.do?category=해외안전" class="" rel="nosublink">해외안전</a></li>
			                            <li><a href="/CM/1_2_3.do?category=대테러 신고홍보" class="" rel="nosublink">대테러ㆍ국제범죄</a></li>
			                            <li><a href="/CM/1_2_3.do?category=산업보안" class="" rel="nosublink">산업보안</a></li>
			                            <li><a href="/CM/1_2_3.do?category=사이버안보" class="" rel="nosublink">사이버안보</a></li>
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_2_1.do" class="font-gray01" rel="nosublink">발간자료</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/CM/1_2_1/list.do?category=nlaw" class="" rel="nosublink">북한</a></li>
			                            <li><a href="/CM/1_2_1/list.do?category=spy" class="" rel="nosublink">방첩</a></li>
			                            <li><a href="/CM/1_2_1/list.do?category=terror" class="" rel="nosublink">대테러</a></li>
			                            <li><a href="/CM/1_2_1/list.do?category=crime" class="" rel="nosublink">국제범죄</a></li>
			                            <li><a href="/AF/1_7_7_1.do" class="" rel="nosublink">사이버·AI안보</a></li>
			                        </ul>
			                    </div>
			                </div>
			                <div class="sub-menu-row">
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/CM/1_2_5/list.do" class="font-gray01" rel="nosublink">카드뉴스</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/CM/1_2_2/list.do" class="font-gray01" rel="nosublink">포스터ㆍ만화</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/CM/1_2_2/list.do" class="" rel="nosublink">포스터</a></li>
			                            <li><a href="/CM/1_2_4.do" class="" rel="nosublink">만화</a></li>
			                        </ul>
			                    </div>
			                </div>
			            </div>
			        </div>
			    </div>
            </div>
            <div class="menu" id="menus_2"> 
                <!-- 250922 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정 -->
                <div class="menu-link"><a href="#" class="txt-subtitle-2-600 font-gray00" data-menu-id="#menu2" aria-haspopup="true" aria-expanded="false">참여ㆍ민원</a></div>
                <div class="sub-menu bg-gray05" id="menu2">
			        <div class="sub-menu-wrapper">
			            <div class="sub-menu-list row">
			                <div class="sub-menu-row">
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/CM/1_7_2.do" title="111 신고" class="font-gray01">111 신고</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="https://career.nis.go.kr:4017" target="_blank" title="채용안내 새창열림" class="font-gray01">채용안내</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/CM/1_5_1/list.do" class="font-gray01" rel="nosublink">추리퀴즈</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/CM/1_1_1.do" class="font-gray01" rel="nosublink">안보전시관 견학</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                </div>
			                <div class="sub-menu-row">
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/CM/1_12_1.do" class="font-gray01" rel="nosublink">민원신청하기</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/CM/1_12_1.do" class="" rel="nosublink">민원 신청</a></li>
			                            <li><a href="/CM/1_12_2.do" class="" rel="nosublink">내 민원 확인하기</a></li>
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/CM/1_8_1_1.do" class="font-gray01" rel="nosublink">정보공개</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/CM/1_8_1_1.do" class="" rel="nosublink">정보공개청구</a></li>
			                            <li><a href="/CM/1_8_2.do" class="" rel="nosublink">청구처리조회</a></li>
			                            <li><a href="/CM/1_8_3/list.do" class="" rel="nosublink">정보목록</a></li>
			                            <li><a href="/CM/1_8_5.do" class="" rel="nosublink">비공개 대상 정보 기준</a></li>
			                            <li><a href="/CM/1_8_6.do" class="" rel="nosublink">불복구제 제도 및 절차</a></li>
			                            <li><a href="/CM/1_8_4.do" class="" rel="nosublink">법령ㆍ서식</a></li>
			                        </ul>
			                    </div>
			                </div>
			            </div>
			        </div>
			    </div>
            </div>
            <div class="menu" id="menus_3"> 
                <!-- 250922 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정 -->
                <div class="menu-link"><a href="#" class="txt-subtitle-2-600 font-gray00" data-menu-id="#menu3" aria-haspopup="true" aria-expanded="false">주요업무</a></div>
                <div class="sub-menu bg-gray05" id="menu3">
			        <div class="sub-menu-wrapper">
			            <div class="sub-menu-list row">
			                <div class="sub-menu-row">
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_4.do" class="font-gray01" rel="nosublink">방첩</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_4.do" class="" rel="nosublink">소개</a></li>
			                            <li><a href="/AF/1_4_1.do" class="" rel="nosublink">방첩개념</a></li>
			                            <li><a href="/AF/1_4_2.do" class="" rel="nosublink">스파이 사건</a></li>
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_6.do" class="font-gray01" rel="nosublink">대테러</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_6.do" class="" rel="nosublink">소개</a></li>
			                            <li><a href="/AF/1_6_1_1/list.do" class="" rel="nosublink">국내테러경보</a></li>
			                            <li><a href="/AF/1_6_2_1.do" class="" rel="nosublink">국제테러정보</a></li>
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_5.do" class="font-gray01" rel="nosublink">산업보안·경제질서 보호</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_5.do" class="" rel="nosublink">소개</a></li>
			                            <li><a href="/AF/1_5_1_2.do" class="" rel="nosublink">기술유출현황</a></li>
			                            <li><a href="/AF/1_5_2.do" class="" rel="nosublink">국가핵심기술</a></li>
			                            <li><a href="/AF/1_5_3.do" class="" rel="nosublink">국가첨단전략기술</a></li>
			                            <li><a href="/AF/1_5_4.do" class="" rel="nosublink">경제질서 보호</a></li>
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_11.do" class="font-gray01" rel="nosublink">방위산업보호</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_11.do" class="" rel="nosublink">소개</a></li>
			                            <li><a href="/AF/1_11_1.do" class="" rel="nosublink">방위산업기술</a></li>
			                            <li><a href="/AF/1_11_2.do" class="" rel="nosublink">전략물자</a></li>
			                        </ul>
			                    </div>
			                </div>
			                <div class="sub-menu-row">
			                   <!--  <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_3.do" class="font-gray01" rel="nosublink">해외정보</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div> -->
			                    
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_12.do" class="font-gray01" rel="nosublink">우주안보</a>
			                            <div class="divider bg-gray04"></div>
			                        </div> 
			                         <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_12.do" class="" rel="nosublink">소개</a></li>
			                            <li><a href="/AF/1_12_1.do" class="" rel="nosublink">우주안보 개념</a></li>
			                            <li><a href="/AF/1_12_2.do" class="" rel="nosublink">우주위협 유형</a></li> 
			                        </ul>
			                        
			                    </div>
			                    
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_8.do" class="font-gray01" rel="nosublink">국제범죄</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_8.do" class="" rel="nosublink">소개</a></li>
			                            <li><a href="/AF/1_8_1_1_2/list.do" class="" rel="nosublink">국제범죄 개념</a></li>
			                            <li><a href="/AF/1_8_1_2.do" class="" rel="nosublink">국제범죄 유형</a></li>
			                            <li><a href="/AF/1_8_1_3.do" class="" rel="nosublink">주요 적발사례</a></li>
			                            <!--  
			                            <li><a href="/AF/1_8_1_5.do" class="" rel="nosublink">금융범죄</a></li>
			                            <li><a href="/AF/1_8_1_6.do" class="" rel="nosublink">사이버범죄</a></li>
			                            -->
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_7.do" class="font-gray01" rel="nosublink">사이버안보</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_7.do" class="" rel="nosublink">소개</a></li>
			                          <!--<li><a href="/AF/1_7_1_1/list.do" class="" rel="nosublink">사이버위기경보</a></li>
			                           <li><a href="/AF/1_7_2_1.do" class="" rel="nosublink">보안적합성 검증</a></li>
			                            <li><a href="/AF/1_7_3_1.do" class="" rel="nosublink">암호모듈 검증</a></li> -->
			                            
			                            <li><a href="https://www.ncsc.go.kr/ko/main/cyberCrisis.html"
			                             class="new_window" rel="nosublink" target="_blank" title="새창으로 열림">사이버위기경보</a></li> <!-- 20260507 추가 -->
			                            <li><a href="https://www.ncsc.go.kr/ko/main/secCompliance.html"
			                             class="new_window" rel="nosublink" target="_blank" title="새창으로 열림">보안적합성 검증</a></li> <!-- 20260507 추가 -->
										<li><a href="https://www.ncsc.go.kr/ko/main/cryptoModule.html" 
										 class="new_window" rel="nosublink" target="_blank" title="새창으로 열림">암호모듈 검증</a></li> <!-- 20260507 추가 -->
				                            
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_1.do" class="font-gray01" rel="nosublink">안보조사</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_1.do" class="" rel="nosublink">소개</a></li>
			                            <li><a href="/AF/1_1_2.do" class="" rel="nosublink">주요 이적단체 판결사례</a></li>
			                            <li><a href="/AF/1_1_3.do" class="" rel="nosublink">주요 간첩사건</a></li>
			                            <li><a href="/AF/1_1_1.do" class="" rel="nosublink">북한의 대남 침투ㆍ도발 사건</a></li>
			                        </ul>
			                    </div>
			                </div>
			                <div class="sub-menu-row">
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_2.do" class="font-gray01" rel="nosublink">대북정보</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                    <div class="sub-menu-box">
			                    
				                     <div class="sub-menu-box">
				                        <div class="sub-menu-title">
				                            <a href="/AF/1_3.do" class="font-gray01" rel="nosublink">해외정보</a>
				                            <div class="divider bg-gray04"></div>
				                        </div>
				                    </div>
				                    
			                        <!-- <div class="sub-menu-title">
			                            <a href="/AF/1_12.do" class="font-gray01" rel="nosublink">우주안보</a>
			                            <div class="divider bg-gray04"></div>
			                        </div> 
			                         <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/AF/1_12.do" class="" rel="nosublink">소개</a></li>
			                            <li><a href="/AF/1_12_1.do" class="" rel="nosublink">우주안보 개념</a></li>
			                            <li><a href="/AF/1_12_2.do" class="" rel="nosublink">우주위협 유형</a></li> 
			                        </ul> -->
			                        
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_9.do" class="font-gray01" rel="nosublink">국가보안</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/AF/1_10.do" class="font-gray01" rel="nosublink">북한이탈주민 조사 및 임시보호</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                </div>
			            </div>
			        </div>
			    </div>
            </div>
            <div class="menu" id="menus_4">
                <!-- 250922 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정 -->
                <div class="menu-link"><a href="#" class="txt-subtitle-2-600 font-gray00" data-menu-id="#menu4" aria-haspopup="true" aria-expanded="false">기관소개</a></div>
                <div class="sub-menu bg-gray05" id="menu4">
			        <div class="sub-menu-wrapper">
			            <div class="sub-menu-list row">
			                <div class="sub-menu-row">
			                    
			                   <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/ID/1_1.do" class="font-gray01" rel="nosublink">국정원장 인사말</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                    
			                     
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/ID/1_2.do" class="font-gray01">직무</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/ID/1_3.do" class="font-gray01" rel="nosublink">원훈</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div>
			                 	 <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/ID/1_4.do" class="font-gray01" rel="nosublink">직원헌장</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                    </div> 
			               </div>
			                <div class="sub-menu-row">
			                
			                	 
			                	<div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/ID/1_5_2.do" class="font-gray01" rel="nosublink">국정원역사</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/ID/1_5_2.do" class="" rel="nosublink">주요연혁</a></li>
			                            <li><a href="/ID/1_5_3.do" class="" rel="nosublink">역대원장</a></li>
			                            <li><a href="/ID/1_5_4.do" class="" rel="nosublink">역대원훈</a></li>
			                        </ul>
			                    </div> 
			                 	 
			                	 <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/ID/1_8_1.do" class="font-gray01" rel="nosublink"  data-menu-id="#menu6">GI소개</a>
			                            <!-- <div class="divider bg-gray04"  id="menu6" ></div>
			                            <ul class="txt-spo-body-2-400 font-gray02">
                                           <li><a href="/ID/1_8_1.do" class="" rel="nosublink">국가정보원</a></li>
                                           <li><a href="/ID/1_8_2.do" class="" rel="nosublink">국가사이버안보센터</a></li>
                                           <li><a href="/ID/1_8_3.do" class="" rel="nosublink">국제범죄정보센터</a></li>
                                           <li><a href="/ID/1_8_4.do" class="" rel="nosublink">테러정보통합센터</a></li>
                                           <li><a href="/ID/1_8_6.do" class="" rel="nosublink">방첩정보공유센터</a></li>
                                           <li><a href="/ID/1_8_5.do" class="" rel="nosublink">산업기밀보호센터</a></li>
                                           <li><a href="/ID/1_8_7.do" class="" rel="nosublink">반확산센터</a></li> 
                                         </ul> -->
			                        </div>
			                    </div> 
			                    
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/ID/1_6_1_1.do" class="font-gray01" rel="nosublink">관련법령</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                        	<!-- 20210831
			                            <li><a href="/ID/1_6_1_1.do" class="">국가정보원법ㆍ직원법</a></li>
			                            <li><a href="/ID/1_6_1_2.do" class="">산업보안관계법령</a></li>
			                            <li><a href="/ID/1_6_1_3.do" class="">사이버보안 관계법령</a></li>
			                            <li><a href="/ID/1_6_1_4.do" class="">테러방지법</a></li>
			                             -->
			                            <li><a href="/ID/1_6_1_1.do" class="" rel="nosublink">국정원 소관법령</a></li>
			                            <li><a href="/ID/1_6_1_2.do" class="" rel="nosublink">타부처 소관법령</a></li>
			                        </ul>
			                    </div>
			                    <div class="sub-menu-box">
			                        <div class="sub-menu-title">
			                            <a href="/ID/1_7_1.do" class="font-gray01" rel="nosublink">센터소개</a>
			                            <div class="divider bg-gray04"></div>
			                        </div>
			                        <ul class="txt-spo-body-2-400 font-gray01">
			                            <li><a href="/ID/1_7_1.do" class="">국가사이버안보센터</a></li>
			                            <li><a href="/ID/1_7_5.do" class="" rel="nosublink">방첩정보공유센터</a></li>
			                            <li><a href="/ID/1_7_2.do" class="" rel="nosublink">산업기밀보호센터</a></li>
			                            <li><a href="/ID/1_7_3.do" class="" rel="nosublink">국제범죄정보센터</a></li>
			                            <li><a href="/ID/1_7_4.do" class="" rel="nosublink">테러정보통합센터</a></li>
			                            <!-- <li><a href="/ID/1_7_6.do" class="" rel="nosublink">반확산센터</a></li> -->
			                            <li><a href="/ID/1_7_7.do" class="" rel="nosublink">국가우주안보센터</a></li>
			                            <li><a href="/ID/1_7_8.do" class="" rel="nosublink">방위산업침해대응센터</a></li>
			                            <li><a href="/ID/1_7_9.do" class="" rel="nosublink">국가인공지능안보센터</a></li>
			                        </ul>
			                    </div>
			                </div>
			            </div>
			        </div>
			    </div>
            </div>
        </nav>
        <nav class="icon-menus">
            <a class="gnb-search active" href="javascript:void(0);" id="search_btn" title="검색" onclick="toggleSearchArea()">
                <img id="icoSearch" src="/resources/img/renewal_images/light/ico_search.png" alt ="검색"  />
            </a>
		    <div class="search-area" id="search_area">
		    	<form action="/IS/1_1.do" method="post">
			        <div class="input-box search-box bg-gray10 border-gray04">
			        	<input type="hidden" name="search" value="test" />
			        	<legend class="invisible">전체 검색</legend>
			            <input type="text" class="txt-spo-body-2-400 font-gray00" name="search" id="search_text" placeholder="" title="검색어 입력" value="">
			            <button class="search-btn" type="submit" title="검색"></button>
			        </div>
		        </form>
		        <button class="close-btn" type="button" onclick="closeSearchArea()" title="검색창 닫기"></button>
		    </div>
            <a class="gnb-mode" href="javascript:void(0);" id="change_mode_btn" title="다크 모드" onclick="changeMode()">
                <img  id="icoDark" src="/resources/img/renewal_images/light/ico_color_mode.png" alt ="다크 모드"  />
            </a>

             <!-- 251113 : 영문으로 이동버튼 활성화 -->
            <a class="gnb-lang active" href="javascript:void(0);" title="ENGLISH 새창열림" id="change_lang_btn" onclick="goEnglishSite()">
                <!-- <i class="icon language"></i> -->
                <img id="icoLang" src="/resources/img/renewal_images/light/ico_language.png" alt ="ENGLISH 새창열림" />
            </a>
            
            <!-- 250923 모바일 메뉴 : 키보드 접근 수정[s] -->
             <button type="button" aria-expanded="false" aria-label="메뉴 열기" class="gnb-menu" id="menu_btn" onclick="toggleMenu()">
                <i class="icon menu" aria-hidden="true"></i>
            </button>
            
          <!--   <div class="gnb-menu"  id="menu_btn" title="메뉴" onclick="toggleMenu()">
                <i class="icon menu"></i>
            </div> -->
            <!-- 250923 모바일 메뉴 : 키보드 접근 수정[e] -->
        </nav>   
    </header>
    <!-- 250923 웹접근성 모바일 포커스 이동 [s] -->
    <div class="mobile-menu mobile bg-gray10 border-gray04" id="mobile_menu">
        <div class="main-list bg-primary">
            <ul class="txt-subtitle-1-500">
                <!-- 250922 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정 [s]-->
                <li>
                  <a href="#" class="main-menu-link" data-menu-id="#mobileMenu1" rel="nosublink" aria-haspopup="true" aria-expanded="false">소식ㆍ정보</a>
                  <ul class="menu-list bg-gray10" id="mobileMenu1">
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" aria-haspopup="true" aria-expanded="false">알림ㆍ소식</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/CM/1_3/list.do" class="sub-menu-link">공지사항</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_4/list.do" class="sub-menu-link">보도자료</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_10/list.do" class="sub-menu-link" rel="nosublink">NIS NEWS</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_6_2/list.do" class="sub-menu-link" rel="nosublink">입법예고</a></li>
                            <li class="divider" aria-hidden="true"></li>
                        </ul>
                    </li>
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">생활 속 정보</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/AF/1_6_4/list.do" class="sub-menu-link" rel="nosublink">대테러용어</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <!-- <li><a href="/AF/1_6_6.do" class="sub-menu-link" rel="nosublink">여행금지국 방문자 교육</a></li> -->
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/AF/1_7_4.do" class="sub-menu-link" rel="nosublink">정보보안 생활수칙</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/AF/1_8_3.do" class="sub-menu-link" rel="nosublink">국제범죄 예방요령</a></li>
                            <li class="divider" aria-hidden="true"></li>
                        </ul>
                    </li>
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">동영상</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/CM/1_2_3.do?category=111신고" class="sub-menu-link" rel="nosublink"><span class="bold">院</span> 홍보ㆍ111신고</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_2_3.do?category=해외안전" class="sub-menu-link" rel="nosublink">해외안전</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_2_3.do?category=대테러 신고홍보" class="sub-menu-link" rel="nosublink">대테러ㆍ국제범죄</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_2_3.do?category=산업보안" class="sub-menu-link" rel="nosublink">산업보안</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_2_3.do?category=사이버안보" class="sub-menu-link" rel="nosublink">사이버안보</a></li>
                            <li class="divider" aria-hidden="true"></li>
                          
                        </ul>
                    </li>
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">발간자료</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/CM/1_2_1/list.do?category=nlaw" class="sub-menu-link" rel="nosublink">북한</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_2_1/list.do?category=spy" class="sub-menu-link" rel="nosublink">방첩</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_2_1/list.do?category=terror" class="sub-menu-link" rel="nosublink">대테러</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_2_1/list.do?category=crime" class="sub-menu-link" rel="nosublink">국제범죄</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/AF/1_7_7_1.do" class="sub-menu-link" rel="nosublink">사이버·AI안보</a></li>
                            <li class="divider" aria-hidden="true"></li>
                        </ul>
                    </li>
                    <li>
                        <a href="/CM/1_2_5/list.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">카드뉴스</a>
                    </li>
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">포스터ㆍ만화</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/CM/1_2_2/list.do" class="sub-menu-link" rel="nosublink">포스터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_2_4.do" class="sub-menu-link" rel="nosublink">만화</a></li>
                            <li class="divider" aria-hidden="true"></li>
                        </ul>
                    </li>
                  </ul>
                </li>
                <li class="divider" aria-hidden="true"></li>
                <li>
                  <a href="#" class="main-menu-link" data-menu-id="#mobileMenu2" rel="nosublink" aria-haspopup="true" aria-expanded="false">참여ㆍ민원</a>
                  <ul class="menu-list bg-gray10" id="mobileMenu2">
                    <li>
                          <a href="/CM/1_7_2.do" title="111 신고" class="txt-subtitle-1-500 font-primary">111 신고</a>
                    </li>
                    <li>
                        <a href="https://career.nis.go.kr:4017" target="_blank" title="채용안내 새창 열림" class="txt-subtitle-1-500 font-primary">채용안내</a>
                    </li>
                    <li>
                        <a href="/CM/1_5_1/list.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">추리퀴즈</a>
                    </li>
                    <li>
                        <a href="/CM/1_1_1.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">안보전시관 견학</a>
                    </li>
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">민원신청하기</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/CM/1_12_1.do" class="sub-menu-link" rel="nosublink">민원 신청</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_12_2.do" class="sub-menu-link" rel="nosublink">내 민원 확인하기</a></li>
                            <li class="divider" aria-hidden="true"></li>
                        </ul>
                    </li>
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">정보공개</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/CM/1_8_1_1.do" class="sub-menu-link" rel="nosublink">정보공개청구</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_8_2.do" class="sub-menu-link" rel="nosublink">청구처리조회</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_8_3/list.do" class="sub-menu-link" rel="nosublink">정보목록</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_8_5.do" class="sub-menu-link" rel="nosublink">비공개 대상 정보 기준</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_8_6.do" class="sub-menu-link" rel="nosublink">불복구제 제도 및 절차</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/CM/1_8_4.do" class="sub-menu-link" rel="nosublink">법령ㆍ서식</a></li>
                            <li class="divider" aria-hidden="true"></li>
                        </ul>
                    </li>
                  </ul>
                </li>
                 <li class="divider" aria-hidden="true"></li>
                <li>
                  <a href="#" class="main-menu-link" data-menu-id="#mobileMenu3" rel="nosublink" aria-haspopup="true" aria-expanded="false">주요업무</a>
                  <ul class="menu-list bg-gray10" id="mobileMenu3">
                      <li class="select">
                          <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                          <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">방첩</a>
                          <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                              <li><a href="/AF/1_4.do" class="sub-menu-link" rel="nosublink">소개</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_4_1.do" class="sub-menu-link" rel="nosublink">방첩개념</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_4_2.do" class="sub-menu-link" rel="nosublink">스파이 사건</a></li>
                              <li class="divider" aria-hidden="true"></li>
                          </ul>
                      </li>
                      <li class="select">
                          <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                          <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">대테러</a>
                          <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                              <li><a href="/AF/1_6.do" class="sub-menu-link" rel="nosublink">소개</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_6_1_1/list.do" class="sub-menu-link" rel="nosublink">국내테러경보</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_6_2_1.do" class="sub-menu-link" rel="nosublink">국제테러정보</a></li>
                              <li class="divider" aria-hidden="true"></li>
                          </ul>
                      </li>
                      <li class="select">
                          <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                          <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">산업보안·경제질서 보호</a>
                          <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                              <li><a href="/AF/1_5.do" class="sub-menu-link" rel="nosublink">소개</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_5_1_2.do" class="sub-menu-link" rel="nosublink">기술유출현황</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_5_2.do" class="sub-menu-link" rel="nosublink">국가핵심기술</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_5_3.do" class="sub-menu-link" rel="nosublink">국가첨단전략기술</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_5_4.do" class="sub-menu-link" rel="nosublink">경제질서 보호</a></li>
                              <li class="divider" aria-hidden="true"></li>
                          </ul>
                      </li>
                      <li class="select">
                          <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                          <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">방위산업보호</a>
                          <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                              <li><a href="/AF/1_11.do" class="sub-menu-link" rel="nosublink">소개</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_11_1.do" class="sub-menu-link" rel="nosublink">방위산업기술</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_11_2.do" class="sub-menu-link" rel="nosublink">전략물자</a></li>
                              <li class="divider" aria-hidden="true"></li>
                          </ul>
                      </li>
                      
                        <li class="select">
                          <a href="/AF/1_12.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">우주안보</a>
                          
                          <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                              <li><a href="/AF/1_12.do" class="sub-menu-link" rel="nosublink">소개</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_12_1.do" class="sub-menu-link" rel="nosublink">우주안보 개념</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_12_2.do" class="sub-menu-link" rel="nosublink">우주위협 유형</a></li>
                              <li class="divider" aria-hidden="true"></li>
                          </ul>
                          
                      </li>
                      
                   
                      <li class="select">
                          <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                          <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">국제범죄</a>
                          <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                              <li><a href="/AF/1_8.do" class="sub-menu-link" rel="nosublink">소개</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_8_1_1_2/list.do" class="sub-menu-link" rel="nosublink">국제범죄 개념</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_8_1_2.do" class="sub-menu-link" rel="nosublink">국제범죄 유형</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_8_1_3.do" class="sub-menu-link" rel="nosublink">주요 적발사례</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <!-- <li><a href="/AF/1_8_1_5.do" class="sub-menu-link" rel="nosublink">금융범죄</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_8_1_6.do" class="sub-menu-link" rel="nosublink">사이버범죄</a></li>
                              <li class="divider" aria-hidden="true"></li> -->
                          </ul>
                      </li>
                      <li class="select">
                          <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                          <a href="#" class="txt-subtitle-1-500 font-primary" aria-haspopup="true" aria-expanded="false">사이버안보</a>
                          <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                              <li><a href="/AF/1_7.do" class="sub-menu-link" rel="nosublink">소개</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <!--     
                              <li><a href="/AF/1_7_1_1/list.do" class="sub-menu-link" rel="nosublink">사이버위기경보</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_7_2_1.do" class="sub-menu-link" rel="nosublink">보안적합성 검증</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_7_3_1.do" class="sub-menu-link" rel="nosublink">암호모듈 검증</a></li> -->
                              
                            <li><a href="https://www.ncsc.go.kr/ko/main/cyberCrisis.html"
                                  class="sub-menu-link new_window" rel="nosublink" target="_blank" title="새창으로 열림">사이버위기경보</a></li> <!-- 20250311 추가 -->
                  <li class="divider" aria-hidden="true"></li> 
                              <li><a href="https://www.ncsc.go.kr/ko/main/secCompliance.html"
                                  class="sub-menu-link new_window" rel="nosublink" target="_blank" title="새창으로 열림">보안적합성 검증</a></li> <!-- 20250311 추가 -->
                  <li class="divider" aria-hidden="true"></li>
                  <li><a href="https://www.ncsc.go.kr/ko/main/cryptoModule.html" 
                  class="sub-menu-link new_window" rel="nosublink" target="_blank" title="새창으로 열림">암호모듈 검증</a></li> <!-- 20250311 추가 -->
                              
                              <li class="divider" aria-hidden="true"></li>
                          </ul>
                      </li>
                      <li class="select">
                          <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                          <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">안보조사</a>
                          <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                              <li><a href="/AF/1_1.do" class="sub-menu-link" rel="nosublink">소개</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <!--  
                              <li><a href="/AF/1_1_5.do" class="sub-menu-link" rel="nosublink">국가 대공수사 역량 강화</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              -->
                              <li><a href="/AF/1_1_2.do" class="sub-menu-link" rel="nosublink">주요 이적단체 판결사례</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_1_3.do" class="sub-menu-link" rel="nosublink">주요 간첩사건</a></li>
                              <li class="divider" aria-hidden="true"></li>
                              <li><a href="/AF/1_1_1.do" class="sub-menu-link" rel="nosublink">북한의 대남 침투ㆍ도발 사건</a></li>
                              <li class="divider" aria-hidden="true"></li>
                          </ul>
                      </li>
                      <li>
                          <a href="/AF/1_2.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">대북정보</a>
                      </li>
                   
                      <li>
                          <a href="/AF/1_3.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">해외정보</a>
                      </li>
                      
                      <li>
                          <a href="/AF/1_9.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">국가보안</a>
                      </li>
                      <li>
                          <a href="/AF/1_10.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">북한이탈주민 조사 및 임시보호</a>
                      </li>
                  </ul>
                </li>
                 <li class="divider" aria-hidden="true"></li>
                <li>
                  <a href="#" class="main-menu-link" data-menu-id="#mobileMenu4" rel="nosublink" aria-haspopup="true" aria-expanded="false">기관소개</a>
                  <ul class="menu-list bg-gray10" id="mobileMenu4">
                    <li>
                        <a href="/ID/1_1.do" class="txt-subtitle-1-500 font-primary">국정원장 인사말</a>
                    </li> 
                    <li>
                        <a href="/ID/1_2.do" class="txt-subtitle-1-500 font-primary">직무</a>
                    </li>
                    <li>
                        <a href="/ID/1_3.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">원훈</a>
                    </li>
                    <li>
                        <a href="/ID/1_4.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">직원헌장</a>
                    </li>
                    <li class="select">
                    <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">국정원역사</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/ID/1_5_2.do" class="sub-menu-link" rel="nosublink">주요연혁</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_5_3.do" class="sub-menu-link" rel="nosublink">역대원장</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_5_4.do" class="sub-menu-link" rel="nosublink">역대원훈</a></li>
                            <li class="divider" aria-hidden="true"></li>
                        </ul>
                    </li>
                    
              <!--  <li>
                        <a href="/ID/1_8_1.do" class="txt-subtitle-1-500 font-primary" rel="nosublink">GI소개</a>
                    </li> -->
                    
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" data-menu-id="#menu5" aria-haspopup="true" aria-expanded="false">GI소개</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/ID/1_8_1.do" class="sub-menu-link">국가정보원</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_8_2.do" class="sub-menu-link" rel="nosublink">국가사이버안보센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_8_3.do" class="sub-menu-link" rel="nosublink">국제범죄정보센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_8_4.do" class="sub-menu-link" rel="nosublink">테러정보통합센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_8_6.do" class="sub-menu-link" rel="nosublink">방첩정보공유센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_8_5.do" class="sub-menu-link" rel="nosublink">산업기밀보호센터</a></li>
                           <!--  <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_8_7.do" class="sub-menu-link" rel="nosublink">반확산센터</a></li> -->
                            <li class="divider" aria-hidden="true"></li> 
                            <li><a href="/ID/1_8_8.do" class="sub-menu-link" rel="nosublink">국가우주안보센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_8_9.do" class="sub-menu-link" rel="nosublink">방위산업침해대응센터</a></li>
                          <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_8_10.do" class="sub-menu-link" rel="nosublink">국가인공지능안보센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                        </ul>
                    </li>
                    
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary" rel="nosublink" aria-haspopup="true" aria-expanded="false">관련법령</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/ID/1_6_1_1.do" class="sub-menu-link" rel="nosublink">국정원 소관법령</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_6_1_2.do" class="sub-menu-link" rel="nosublink">타부처 소관법령</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <!-- 20210901
                            <li><a href="/ID/1_6_1_1.do" class="sub-menu-link">국가정보원법ㆍ직원법</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_6_1_2.do" class="sub-menu-link">산업보안관계법령</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_6_1_3.do" class="sub-menu-link">사이버보안 관계법령</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_6_1_4.do" class="sub-menu-link">테러방지법</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            -->
                        </ul>
                    </li>
                    <li class="select">
                        <!-- 250923 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정-->
                        <a href="#" class="txt-subtitle-1-500 font-primary"  aria-haspopup="true" aria-expanded="false">센터소개</a>
                        <ul class="list bg-gray05 txt-spo-body-1-400 font-gray01">
                            <li><a href="/ID/1_7_1.do" class="sub-menu-link">국가사이버안보센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_7_5.do" class="sub-menu-link" rel="nosublink">방첩정보공유센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_7_2.do" class="sub-menu-link" rel="nosublink">산업기밀보호센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_7_3.do" class="sub-menu-link" rel="nosublink">국제범죄정보센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_7_4.do" class="sub-menu-link" rel="nosublink">테러정보통합센터</a></li>
                            <!-- <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_7_6.do" class="sub-menu-link" rel="nosublink">반확산센터</a></li> -->
                            <li class="divider" aria-hidden="true"></li> 
                            <li><a href="/ID/1_7_7.do" class="sub-menu-link" rel="nosublink">국가우주안보센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_7_8.do" class="sub-menu-link" rel="nosublink">방위산업침해대응센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                            <li><a href="/ID/1_7_9.do" class="sub-menu-link" rel="nosublink">국가인공지능안보센터</a></li>
                            <li class="divider" aria-hidden="true"></li>
                        </ul>
                    </li>
                  </ul>
                </li>
                <!-- 250922 웹접근성 10-1 : 키보드 접근 및 운영 오류 수정 [e]-->
            </ul>
        </div>
        <div class="sub-list"></div>
    </div>
    <!-- 250923 웹접근성 모바일 포커스 이동 [e] -->
</div>


<script>
    function changeMode(){
  
        var colorTheme = document.getElementById('root').getAttribute("color-theme");
        if (colorTheme == "light") {
        	$('#change_mode_btn').attr('title', '일반 모드');
            document.getElementById('root').setAttribute("color-theme", "dark");
            localStorage.setItem('color-theme', "dark");
            $("#icoDark").attr("src","/resources/img/renewal_images/dark/ico_color_mode.png");
            $("#icoSearch").attr("src","/resources/img/renewal_images/dark/ico_search.png");
            $("#icoLang").attr("src","/resources/img/renewal_images/dark/ico_language.png");
        } else {
        	$('#change_mode_btn').attr('title', '다크 모드');
            document.getElementById('root').setAttribute("color-theme", "light");
            localStorage.setItem('color-theme', "light");
            $("#icoDark").attr("src","/resources/img/renewal_images/light/ico_color_mode.png");
            $("#icoSearch").attr("src","/resources/img/renewal_images/light/ico_search.png");
            $("#icoLang").attr("src","/resources/img/renewal_images/light/ico_language.png");
        }
        if (typeof changeVideoPoster == 'function' ) {
            changeVideoPoster();
        }
        
    }
    function goEnglishSite() {
    	openNewWindow = window.open("about:blank");
    	openNewWindow.location.href = "https://eng.nis.go.kr";
    }
    function toggleSearchArea(){
        if ($('#search_area').hasClass('active')) {
            closeSearchArea();
        } else {
            $('#search_area').addClass('active');
            $('#search_text').focus();
        }
    }
    function closeSearchArea(){ 
    	$("#search_btn").focus();
        $('#search_area').removeClass('active');
    }
   
    /*250923 웹접근성 개선 : 모바일 키보드 접근[s]*/
    function toggleMenu(){ 
			const $btn = $('#menu_btn');
			const $menu = $('#mobile_menu');
			
	   // 251113 영문이동 버튼 활성화 (아이콘 영역 수정)
       const $iconMenus = $btn.parents(".icon-menus");
        $iconMenus.toggleClass('active');
	    // 251113 : 영문이동 버튼 활성화	
       
        $btn.toggleClass('active');
   		$menu.toggleClass('active');

		if (!$menu.hasClass('active')) {
            resetMobileMenu();
            $('#search_btn').addClass('active');
            $('#change_lang_btn').addClass('active'); // 251217 : 영문이동 버튼 활성화 
            $('#change_mode_btn').removeClass('active');
            $('html, body').removeClass('noscroll');

			// 접근성 속성 업데이트
			$btn.attr('aria-expanded', 'false');
			$btn.attr('aria-label', '메뉴 열기');

        } else {
       //     $('#change_lang_btn').removeClass('active');
            $('#search_btn').removeClass('active');
            $('#change_mode_btn').addClass('active');
            $('html, body').addClass('noscroll');

			// 접근성 속성 업데이트
			$btn.attr('aria-expanded', 'true');
			$btn.attr('aria-label', '메뉴 닫기');
        }
        $(".video_btn").hide();
    }
    /*250923 웹접근성 개선 : 모바일 키보드 접근[e]*/
    function initPcMenu(){
        /* $('#gnb .menus .menu > .menu-link').on("click mouseover", function(e){
            e.preventDefault();
            $('#menus .menu > .menu-link').removeClass("active");
            $(this).addClass("active");
            $('#sub_menu').addClass("active");
            $('#sub_menu .sub-menu-list').removeClass('active');
            var menuId = $(e.target).data('menu-id');
            $(menuId).addClass('active');
        });
        $(window).mousemove(function(event){
            var eventTarget = event.target;
            if ( $(eventTarget).hasClass('menu-link') == false && $(eventTarget).closest('#sub_menu, #menus').length == 0 ) {
                $('#sub_menu').removeClass("active");
                $('#menus .menu > .menu-link').removeClass("active");
            }
        }); */
        
        /* 250923 웹접근성 10-1 : 키보드 접근성[s]*/
        // 1depth 메뉴 클릭/마우스오버 이벤트
        $('#gnb .menus .menu > .menu-link').on("click mouseover", function(e){
            e.preventDefault();
            $('#menus .menu > .menu-link').removeClass("active");
            $(this).addClass("active");
            
            // 서브메뉴 표시
            var menuId = $(this).find('a').data('menu-id');
            if(menuId) {
                $('.sub-menu').removeClass('active');
                $(menuId).addClass('active');
            }
        });
        
        // 1depth 메뉴 포커스 이벤트 - 탭 이동 방식
        $('#gnb .menus .menu > .menu-link a').on('focus', function(e){
            var $currentMenu = $(this).closest('.menu');
            var $subMenu = $currentMenu.find('.sub-menu');
            var menuId = $(this).data('menu-id');
            
            // 모든 메뉴 비활성화
            $('#menus .menu > .menu-link').removeClass("active");
            $('.sub-menu').removeClass('active');
            
            // 현재 메뉴 활성화
            $currentMenu.find('.menu-link').addClass("active");
            
            // 서브메뉴 표시
            if(menuId) {
                $(menuId).addClass('active');
            }
            
            // aria-expanded 속성 업데이트
            $(this).attr('aria-expanded', 'true');
        });
        
        // 1depth 메뉴 포커스 아웃 이벤트
        $('#gnb .menus .menu > .menu-link a').on('blur', function(e){
            // 포커스가 서브메뉴로 이동하는 경우가 아닐 때만 메뉴 닫기
            setTimeout(function(){
                if(!$('.sub-menu').is(':hover') && !$('.sub-menu a').is(':focus')) {
                    $('#menus .menu > .menu-link').removeClass("active");
                    $('.sub-menu').removeClass('active');
                    $('#gnb .menus .menu > .menu-link a').attr('aria-expanded', 'false');
                }
            }, 100);
        });
        
        // 마우스 이동 시 메뉴 상태 관리
        $(window).on("mousemove", function(event){
            var eventTarget = event.target;
            if ( $(eventTarget).hasClass('menu-link') == false && $(eventTarget).closest('.sub-menu, #menus').length == 0 ) {
                $('#menus .menu > .menu-link').removeClass("active");
                $('.sub-menu').removeClass('active');
                $('#gnb .menus .menu > .menu-link a').attr('aria-expanded', 'false');
            }
        });
        
        // 키보드 네비게이션 개선
        $('#gnb .menus .menu > .menu-link a').on('keydown', function(e){
            var $currentMenu = $(this).closest('.menu');
            var $subMenu = $currentMenu.find('.sub-menu');
            var $subMenuLinks = $subMenu.find('a');
            
            switch(e.keyCode) {
                case 13: // Enter
                case 32: // Space
                    e.preventDefault();
                    if($subMenu.hasClass('active')) {
                        // 서브메뉴가 열려있으면 첫 번째 서브메뉴 항목으로 포커스
                        $subMenuLinks.first().focus();
                    } else {
                        // 서브메뉴 열기
                        $subMenu.addClass('active');
                        $(this).attr('aria-expanded', 'true');
                        $subMenuLinks.first().focus();
                    }
                    break;
                case 27: // Escape
                    e.preventDefault();
                    $subMenu.removeClass('active');
                    $(this).attr('aria-expanded', 'false');
                    $(this).focus();
                    break;
                case 40: // Down Arrow
                    e.preventDefault();
                    if($subMenu.length > 0) {
                        $subMenu.addClass('active');
                        $(this).attr('aria-expanded', 'true');
                        $subMenuLinks.first().focus();
                    }
                    break;
            }
        });
        
        // 2depth 메뉴 키보드 네비게이션
        $('.sub-menu a').on('keydown', function(e){
            var $subMenu = $(this).closest('.sub-menu');
            var $subMenuLinks = $subMenu.find('a');
            var currentIndex = $subMenuLinks.index(this);
            var $parentMenu = $subMenu.closest('.menu');
            var $parentLink = $parentMenu.find('.menu-link a');
            
            switch(e.keyCode) {
                case 27: // Escape
                    e.preventDefault();
                    $subMenu.removeClass('active');
                    $parentLink.attr('aria-expanded', 'false');
                    $parentLink.focus();
                    break;
                case 38: // Up Arrow
                    e.preventDefault();
                    if(currentIndex > 0) {
                        $subMenuLinks.eq(currentIndex - 1).focus();
                    } else {
                        $parentLink.focus();
                    }
                    break;
                case 40: // Down Arrow
                    e.preventDefault();
                    if(currentIndex < $subMenuLinks.length - 1) {
                        $subMenuLinks.eq(currentIndex + 1).focus();
                    }
                    break;
                case 37: // Left Arrow
                    e.preventDefault();
                    $parentLink.focus();
                    break;
                case 39: // Right Arrow
                    e.preventDefault();
                    // 다음 1depth 메뉴로 이동
                    var $nextMenu = $parentMenu.next('.menu');
                    if($nextMenu.length > 0) {
                        $subMenu.removeClass('active');
                        $parentLink.attr('aria-expanded', 'false');
                        $nextMenu.find('.menu-link a').focus();
                    }
                    break;
            }
        });
        
        // 3depth 메뉴 키보드 네비게이션
        $('.sub-menu ul li a').on('keydown', function(e){
            var $currentLi = $(this).closest('li');
            var $allSubMenuLinks = $('.sub-menu a');
            var currentIndex = $allSubMenuLinks.index(this);
            var $subMenu = $(this).closest('.sub-menu');
            var $parentMenu = $subMenu.closest('.menu');
            var $parentLink = $parentMenu.find('.menu-link a');
            
            switch(e.keyCode) {
                case 27: // Escape
                    e.preventDefault();
                    $subMenu.removeClass('active');
                    $parentLink.focus();
                    break;
                case 38: // Up Arrow
                    e.preventDefault();
                    if(currentIndex > 0) {
                        $allSubMenuLinks.eq(currentIndex - 1).focus();
                    } else {
                        $parentLink.focus();
                    }
                    break;
                case 40: // Down Arrow
                    e.preventDefault();
                    if(currentIndex < $allSubMenuLinks.length - 1) {
                        $allSubMenuLinks.eq(currentIndex + 1).focus();
                    }
                    break;
                case 37: // Left Arrow
                    e.preventDefault();
                    // 같은 2depth 그룹의 첫 번째 항목으로 이동
                    var $subMenuBox = $(this).closest('.sub-menu-box');
                    var $firstLink = $subMenuBox.find('> .sub-menu-title a');
                    if($firstLink.length > 0) {
                        $firstLink.focus();
                    } else {
                        $parentLink.focus();
                    }
                    break;
                case 39: // Right Arrow
                    e.preventDefault();
                    // 다음 2depth 그룹의 첫 번째 항목으로 이동
                    var $nextSubMenuBox = $(this).closest('.sub-menu-box').next('.sub-menu-box');
                    if($nextSubMenuBox.length > 0) {
                        var $nextFirstLink = $nextSubMenuBox.find('> .sub-menu-title a');
                        if($nextFirstLink.length > 0) {
                            $nextFirstLink.focus();
                        }
                    } else {
                        // 다음 1depth 메뉴로 이동
                        var $nextMenu = $parentMenu.next('.menu');
                        if($nextMenu.length > 0) {
                            $subMenu.removeClass('active');
                            $parentLink.attr('aria-expanded', 'false');
                            $nextMenu.find('.menu-link a').focus();
                        }
                    }
                    break;
            }
        });
        
        // 포커스 사라졌을때, 초기화
        $('#gnb .menus .menu').on('focusin', function () {
            $(this).find('> .menu-link').addClass('active');
            $(this).find('> .menu-link a[aria-expanded]').attr('aria-expanded', 'true');
            $(this).find('> .sub-menu').addClass('active'); // 필요할 때만
        })
        .on('focusout', function () {
            const $menu = $(this);
            // 포커스가 완전히 벗어났는지 확인
            setTimeout(function () {
            const activeEl = document.activeElement;
            const stillInside = $menu.has(activeEl).length > 0 || $menu.is(activeEl);
            if (!stillInside) {
                // 이 1depth 그룹에서 포커스가 사라졌다면 비활성화
                $menu.find('> .menu-link').removeClass('active');
                $menu.find('> .menu-link a[aria-expanded]').attr('aria-expanded', 'false');
                $menu.find('> .sub-menu').removeClass('active');
            }
            }, 0);
        });
        /* 250923 웹접근성 10-1 : 키보드 접근성 [e]*/
    }
    /*250923 웹접근성 모바일 포커스 이동[s]*/
    function initMobileMenu(){
      $('#mobile_menu .main-menu-link').on('click', function(e){
          resetMobileMenu();
          $(this).addClass('active').attr('aria-expanded', 'true');
          var menuId = $(e.target).data('menu-id');
          $(menuId).addClass('active').attr('aria-expanded', 'true');
      });

      $('#mobile_menu .menu-list > .select > a').on('click', function(){
          $(this).parent('.select').siblings('.select')
              .find('a').removeClass("active").attr('aria-expanded', 'false');
          const willOpen = !$(this).hasClass('active');
          $(this)
              .toggleClass('active', willOpen)
              .attr('aria-expanded', willOpen ? 'true' : 'false');
          return false;
      });
    }

    function resetMobileMenu(){
        $('#mobile_menu .main-menu-link').removeClass("active").attr('aria-expanded', 'false');
        $('#mobile_menu .menu-list').removeClass("active").attr('aria-expanded', 'false');
        $('#mobile_menu .menu-list > .select > a').removeClass("active").attr('aria-expanded', 'false');
    }
    /*250923 웹접근성 모바일 포커스 이동[e]*/

    function getRecommendSearch(){
    	$.ajax({
    		url: '/header/recommend_search.do',
    		type: 'GET',
			cache: false,
			dataType: "json",
			success: function (json) {
				if (json.resultState == "success") {
					if (json.resultValue && json.resultValue != "") {
						$('#search_text').attr("placeholder", json.resultValue);
						if ($('#main_search_text').length > 0) {
							$('#main_search_text').attr("placeholder", json.resultValue);	
						}	
					} else {
						$('#search_text').attr("placeholder", "");
						if ($('#main_search_text').length > 0) {
							$('#main_search_text').attr("placeholder", "");	
						}
					}
				}
				else {
					$('#search_text').attr("placeholder", "");
					if ($('#main_search_text').length > 0) {
						$('#main_search_text').attr("placeholder", "");	
					}
				}
			}
		});
    }
    function initHeader(){
        initPcMenu();
        initMobileMenu();
        
        // 250923 웹접근성 개선[s]
        // 페이지 로드 시 모든 메뉴의 aria-expanded를 false로 초기화
        $('#gnb .menus .menu > .menu-link a').attr('aria-expanded', 'false');
        // 250923 웹접근성 개선[e]
    }    
    
    function getCookie(name){
        var wcname = name + '=';
        var wcstart, wcend, end;
        var i = 0;
        while(i <= document.cookie.length) {
            wcstart = i;
            wcend   = (i + wcname.length);
            if(document.cookie.substring(wcstart, wcend) == wcname) {
                if((end = document.cookie.indexOf(';', wcend)) == -1)
                    end = document.cookie.length;
                return document.cookie.substring(wcend, end);
            }
            i = document.cookie.indexOf('', i) + 1;
            if(i == 0) {
                break;
            }
        }
        return '';
    }
    function setCookie(name, value, expiredays) {
		var today = new Date();
		today.setDate(today.getDate() + expiredays);
		document.cookie = name + '=' + escape(value) + '; path=/; expires=' + today.toGMTString() + ';'
	}
    $(function(){
        initHeader();
        getRecommendSearch();
        var colorTheme = document.getElementById('root').getAttribute("color-theme");
        if(colorTheme == "dark"){
        	$("#icoDark").attr("src","/resources/img/renewal_images/dark/ico_color_mode.png");
        	$("#icoSearch").attr("src","/resources/img/renewal_images/dark/ico_search.png");
        	$("#icoLang").attr("src","/resources/img/renewal_images/dark/ico_language.png");
        }
      //  alert("121.163.121.6"); 
      /*
      	if( getCookie('main_banner') == 'close') {
      		$(".cyberSecurity").hide(); 	
      		$("#container").css("padding-top","80px");
      	}else{
      		$("#container").css("padding-top","250px");
      	}
     */
      // 2024-08-12 추가&수정[s]
       
    	// 2024-08-12 추가&수정[e]  
    });
</script>
			<!-- // main header -->
        </div>
        
        <div class="container main-container" id="container">
                <section class="section display" style="height: 100vh;">
                	<h3 class="invisible" id="display_header">메인</h3>
                    <div class="content-wrapper">
                    	<!-- <button type="button" style="width: 1px;height:1px;opacity: 0;border: 0;" class="prev-page-btn" aria-hidden="true" title=""></button> -->
                        <div class="animation-container">
                        	<div class="overlay-container"></div>
                            <video class="desktop-video" autoplay playsinline preload="auto" muted loop data-keepplaying>
                                <source src="/resources/img/renewal_images/main/main_video7.mp4" type="video/mp4">
                            </video>
                           	<p class="invisible">우리의 일상이 안전하고 행복해지는 길 대한민국의 안보가 더욱 튼튼해지는 길 "우리는 陰地에서 일하고 陽地를 指向한다." 국가정보원은 그 길을 걸어가겠습니다.</p>
                        </div>
                        <div class="content">
                            <!-- <p class="content-text txt-display-500">국민만 생각하고 <br class="line3">그곳이 어디든 <br class="line2">앞만 보고 달려갑니다.</p> -->
                            <form action="/IS/1_1.do" method="post">
                            	<input type="hidden" name="search" value="test" />
                                <div class="input-box search-box bg-gray10 border-gray04">
                                    <input type="text" class="txt-spo-body-2-400 font-gray00" name="search" id="main_search_text" placeholder="" title="검색어 입력" value="">
                                    <button class="search-btn" type="submit" title="검색"></button>
                                </div>
                            </form>
                        </div>
                        <div class="popup-btn">
                            <a class="bg-primary txt-button-2-400" href="#popup-layer" id="popup_link" aria-haspopup="true" aria-controls="popup-layer">팝업존</a>
                        </div>
                        <div class="movie-controller">
                        	MOVIE <a href="javascript:videoPlay()" title="영상 재생">PLAY</a> | <a href="javascript:videoStop()" title="영상 일시정지">STOP</a>
                        </div>
                        <div class="scroll-down">
                            <a class="scroll-down-btn" href="#news" id="scroll_down" title="페이지 아래로 이동">
                                <div class="scroll-motion-frame">
                                    <div class="scroll-shape">
                                        <span>Scroll Down</span>
                                    </div>
                                    <div class="arrow-move">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </div>
                                
                            </a>
                        </div>
                        <!-- <button type="button" style="width: 1px;height:1px;opacity: 0;border: 0;" class="next-page-btn" aria-hidden="true" title=""></button> -->
                    </div>
                </section>
                <section class="section news">
                	<h3 class="invisible" id="news_header">알려드립니다</h3>
                    <div class="content-wrapper">
                    	<!-- <button type="button" style="width: 1px;height:1px;opacity: 0;border: 0;" class="prev-page-btn" aria-hidden="true" title=""></button> -->
                    	
                        <div class="card press">
                            <div class="card-header txt-heading-2-500 font-gray00">
                                <p>보도자료</p>
                            </div>
                            <div class="card-image">
                                <img src="/resources/img/renewal_images/main/img_press_2.png" alt="" />
                                <div class="logo-image">
                                    <img src="/resources/img/renewal_images/logo_nis_black.png" alt="NIS logo" />
                                </div>
                            </div>
                            <span >
                            </span> 
                            
                           		
                            		<div class="card-body">
                            			<a href="/CM/1_4/view.do?seq=415&currentPage=1">
		                            		<p class="card-title txt-heading-3-500 text-ellipsis-2 font-gray00">국가정보원, 육군과 ‘드론안보 협력 업무협약’ 체결</p>
		                            	</a>
		                           		 
		                            	 <a href="/CM/1_4/view.do?seq=415&currentPage=1">
		                            		<p class="card-content txt-spo-body-1-400 text-ellipsis-3 font-gray01">
		                            		- 지난해 10월 해군과 업무협약에 이어, 육군과 두 번째 업무협약 체결<br/>- 최신 드론위협 정보 공유 및 대드론 통합체계 구축을 위한 전방위적 협력기반 마련
		                            		</p>
		                            	</a>
	                            	</div>
	                            	<div class="card-footer">
	                            		<!-- 보도자료 더 보기 -->
		                                <a class="more-link txt-body-2-600 font-gray00" href="/CM/1_4/list.do">보도자료 더 보기</a>
		                                
		                            </div>
                           		
                           		
                            	
                            
                        </div>
                        <!-- <button type="button" style="width: 1px;height:1px;opacity: 0;border: 0;" class="next-page-btn" aria-hidden="true" title=""></button> -->
                        
                        
	                        <div class="card sns">
	                            <div class="card-header txt-heading-2-500 font-gray00">
	                                <p>카드뉴스</p>
	                            </div>
	                            <div class="card-image">
	                            	<a href="/CM/1_2_5/view.do?seq=178&currentPage=1">
	                            		<!-- <img src="/resources/img/renewal_images/main/img_sns.png" alt="해외연계 경제질서 교란 최신사례 및 대응요령" style="display:none;" /> -->
	                            		<img src="https://www.nis.go.kr:4016/common/download.do?seq=26DF27603BBE2D4AD18CAD47DBD99B0D" alt="국제 테러 정세" />
	                            	</a>
	                            </div>
	                            <div class="card-body">
	                            	<a href="/CM/1_2_5/view.do?seq=178&currentPage=1">
	                            		<p class="card-title txt-heading-3-500 text-ellipsis-2 font-gray00">국제 테러 정세</p>
	                            	</a>
	                               
	                                <a href="/CM/1_2_5/view.do?seq=178&currentPage=1">
	                                	<p class="card-content txt-spo-body-1-400 text-ellipsis-3 font-gray01">
	                            		#테러 허브화 #신종 테러수단 
	                            		</p>
	                            	</a>
	                                
	                            </div>
	                            <div class="card-footer">
	                                <a class="more-link txt-body-2-600 font-gray00" href="/CM/1_2_5/list.do">카드뉴스 더 보기</a>
	                            </div>
	                        </div>
                        
                        
                    </div>
                </section>
                <section class="section about">
                	<h3 class="invisible" id="about_header">국가정보원</h3>
                    <div class="content-wrapper">
                    	<!-- <button type="button" style="width: 1px;height:1px;opacity: 0;border: 0;" class="prev-page-btn" aria-hidden="true" title=""></button> -->
                        <div class="content">
                            <div class="content-body">
                                <div class="content-heading txt-heading-2-500">
                                    <p></p>
                                </div>
                                <p class="content-title txt-display-500">안전하고 평화로운 대한민국을 위해<br>국가정보원이 함께합니다.</p>
                            </div>
                            <div class="content-images" id="about_slider">
                                <div class="slider-wrapper">
                                    <a class="image-card" href="/ID/1_2.do">
                                        <img src="/resources/img/renewal_images/main/img_about_1.jpg" alt=""/>
                                        <div class="image-name txt-subtitle-2-500">
                                            <p class="">직무</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="slider-wrapper">
                                    <a class="image-card" href="/ID/1_5_2.do">
                                        <img src="/resources/img/renewal_images/main/img_about_2.png" alt="" />
                                        <div class="image-name txt-subtitle-2-500">
                                            <p class="">국정원 역사</p>
                                        </div>
                                    </a>
                                </div>
                                <div class="slider-wrapper">
                                    <a class="image-card" href="/ID/1_6_1_1.do">
                                        <img src="/resources/img/renewal_images/main/img_about_3.jpg" alt="" />
                                        <div class="image-name txt-subtitle-2-500">
                                            <p class="">관련 법령</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <!-- <button type="button" style="width: 1px;height:1px;opacity: 0;border: 0;" class="next-page-btn" aria-hidden="true" title=""></button> -->
                    </div>
                </section>
                <section class="section career">
                	<h3 class="invisible" id="career_header">채용안내</h3>
                    <div class="content-wrapper">
                    	<!-- <button type="button" style="width: 1px;height:1px;opacity: 0;border: 0;" class="prev-page-btn" aria-hidden="true" title=""></button> -->
                        <div class="content">
                            <div class="content-images">
                                <div class="image career-image-1">
                                    <img src="/resources/img/renewal_images/main/img_career_3.png" alt="국가가 정말로 원하는 사람! 바로 당신입니다."/>
                                </div>
                                <div class="image career-image-2">
                                    <img src="/resources/img/renewal_images/main/img_career_2.png" alt="채용면접관이 이력서를 보고 인터뷰 하는 이미지"/>
                                </div>
                            </div>
                            <div class="content-header txt-heading-2-500 font-gray00">
                                <p>주요임무ㆍ사명</p>
                            </div>
                            
                            <div class="content-body">
                                <div class="content-title txt-display-500 font-gray00">
                                    <p>情報는 國力이다</p>
                                </div>
                                <div class="content-text">
                                    <p class="txt-subtitle-2-500 font-gray00">투철한 애국심과 사명감, 최고의 업무 전문성으로 <br>모든 안보위협에 선제적으로 대처하는 최고의 정보요원</p>
                                    <div class="career-btns">
                                        <!-- <a class="more-link txt-body-2-600 font-gray00" href="https://career.nis.go.kr:4017/info/talent.html" target="_blank" title="채용사이트 - 인재상 새창열림">인재상</a> -->
                                        <a class="more-link txt-body-2-600 font-gray00" href="https://career.nis.go.kr:4017/recruit/talent" target="_blank" title="채용사이트 - 인재상 새창열림">인재상</a>
                                        <a class="more-link txt-body-2-600 font-gray00" href="https://career.nis.go.kr:4017" target="_blank" title="채용사이트 새창열림" >채용사이트 바로가기</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- <button type="button" style="width: 1px;height:1px;opacity: 0;border: 0;" class="next-page-btn" aria-hidden="true" title=""></button> -->
                    </div>
                </section>
                 <section class="section footer-section footer-area fp-auto-height" id="footer_area">
                    <!-- footer --> 
					




 

    








 

 <!-- 260202 처리중 팝업 [s] -->
   <div class="report-modal">
      <div class="modal-inner">
        <div class="modal-text">
          <div class="loadBar">
            <div class="loadBar-spinner">
              <span></span><span></span><span></span><span></span>
              <span></span><span></span><span></span><span></span>
            </div>
          </div>
          <p class="title">처리 중입니다</p>
          <p class="text">잠시만 기다려 주시기 바랍니다</p>
        </div>
      </div>
      <div class="modal-bg"></div>
   </div>
  <!-- 260202 신고하기 팝업 [e] -->

<footer class="footer border-gray04" id="footer">
    <div class="footer-wrapper">
        <div class="footer-content">
            <nav class="menus">
                <div class="logo">
                  NIS 로고
                </div>
                <div class="menu">
                    <a href="/GD/1_2.do" class="menu-link txt-body-2-600 font-gray00">저작권 정책</a>
                </div>
                <div class="divider bg-gray04"></div>
                <div class="menu">
                    <a href="/GD/1_3_2.do" class="menu-link txt-body-2-600 font-gray00">개인정보 처리방침</a>
                </div>
                <div class="divider bg-gray04"></div>
                <div class="menu">
                    <a href="/GD/1_5/list.do" class="menu-link txt-body-2-600 font-gray00">FAQ</a>
                </div>
                <div class="divider bg-gray04"></div>
                <div class="menu">
                    <a href="/GD/1_4_1.do" class="menu-link txt-body-2-600 font-gray00">Q&amp;A</a>
                </div>
                <div class="divider bg-gray04"></div>
                <div class="menu">
                    <a href="/GD/1_6.do" class="menu-link txt-body-2-600 font-gray00">사이트맵</a>
                </div>
            </nav>
            <div class="desc txt-body-3-500">
                <p>Copyright <span>©</span> National Intelligence Service, <br>Republic of Korea</p>
            </div>
        </div>
        <div class="footer-btns">
            <nav class="icon-menus">
            	
                <a href="http://www.facebook.com/National.Intelligence.Service" target="_blank" title="국가정보원 facebook 채널 새창열림">
                    <i class="icon facebook"></i>
                    <span class="invisible">국가정보원 facebook 채널</span>
                </a>
                <a href="https://www.instagram.com/national.intelligence.service/" target="_blank" title="국가정보원 instagram 채널 새창열림">
                    <i class="icon instagram"></i>
                    <span class="invisible">국가정보원 instagram 채널</span>
                </a> 
                
                <a title="새창" href="http://www.wa.or.kr/board/list.asp?BoardID=0006" target="_blank">
            		<img alt="(사)한국장애인단체총연합회 한국웹접근성인증평가원 웹 접근성 우수사이트 인증마크(WA인증마크)" class="icon wa" src="/resources/img/renewal_images/WA_mark.png">
            	</a>
            </nav>
        </div>
    </div>
  <!--  
    <div class="floating footer-floating" id="footer_floating">
		<a class="floating-btn txt-button-500 recruit" href="https://career.nis.go.kr:4017/index.html" target="_blank" title="채용사이트"></a>
        <a class="floating-btn txt-button-500 info" href="/CM/1_3/list.do" title="알림ㆍ소식"></a>
        <a class="floating-btn txt-button-500 report" href="/CM/1_7_2.do" title="111신고"></a>
        <a class="floating-btn txt-button-500 facebook" href="http://www.facebook.com/National.Intelligence.Service" target="_blank" title="페이스북"></a>
        <a class="floating-btn txt-button-500 cyber" href="https://www.ncsc.go.kr:4018/" target="_blank" title="국가 사이버 안보센터"></a>211124 추가
    </div> -->
     
     <!-- [s]: 2022-06-29 -->
    
    <div class="floating footer-floating" id="sub_floating">
		<a class="floating-btn txt-button-500 recruit" href="https://career.nis.go.kr:4017" target="_blank" title="채용사이트 바로가기 새창"></a>
        <!-- <a class="floating-btn txt-button-500 info" href="/CM/1_3/list.do" title="알림ㆍ소식"></a> -->
        <a class="floating-btn txt-button-500 report" href="/CM/1_7_2.do" title="111신고"></a>
        <a class="floating-btn txt-button-500 facebook" href="http://www.facebook.com/National.Intelligence.Service" target="_blank" title="페이스북 바로가기 새창"></a>
        <a class="floating-btn txt-button-500 instagram" href="https://www.instagram.com/national.intelligence.service" target="_blank" title="인스타그램 바로가기 새창"></a> 
        <a class="floating-btn txt-button-500 cyber" href="https://www.ncsc.go.kr/" target="_blank" title="국가 사이버 안보센터 바로가기 새창" ></a><!-- 211124 추가 -->
        <button class="floating-menu bg-primary" type="button" id="sub-floating_menu" title="플로팅 메뉴"></button>
    </div>
    
    <!-- [e]: 2022-06-29 -->
    
    <button class="top-btn bg-primary txt-button-500" type="button" id="top_btn" title="페이지 상단으로 이동"><span>TOP</span></button>
</footer>
<span itemscope="" itemtype="http://schema.org/Organization" style="display:none;">
	<link itemprop="url" href="https://www.nis.go.kr">
	<a tabindex="-1" itemprop="sameAS"  href="https://www.facebook.com/National.Intelligence.Service">Nis페이스북</a>
</span>
<!-- //footer -->

<script> 
	/* 	function toggleNavigation(e) {
	    var $currentDepth = $(e.target).parent('.select');
	    if (!$currentDepth.hasClass('disabled')) {
	        $currentDepth.siblings('.select').children('a, .list').removeClass('active');
	        $(e.target).toggleClass('active');
	        $(e.target).siblings('.list.selected').toggleClass('active');
	    }
	    return false;
	} */
	
	// 250922 웹접근성 개선 : aria-expanded 상태 관리 추가[s]
	function toggleNavigation(e) {
	    var $currentDepth = $(e.target).parent('.select');
	    if (!$currentDepth.hasClass('disabled')) {
	        $currentDepth.siblings('.select').children('a, .list').removeClass('active');
	        $currentDepth.siblings('.select').children('a').attr('aria-expanded', 'false');
	        $(e.target).toggleClass('active');
	        $(e.target).siblings('.list.selected').toggleClass('active');
	        
	        // aria-expanded 상태 업데이트
	        var isExpanded = $(e.target).hasClass('active');
	        $(e.target).attr('aria-expanded', isExpanded);
	    }
	    return false;
	}
	// 250922 웹접근성 개선 : aria-expanded 상태 관리 추가[e]
	
	function clickMenu(e) {
	    
	    var _this = e.target;
	    var menuId = $(_this).attr('id');
	    var href = $(_this).attr('href');
	    var target = $(_this).attr('target');
	    
	    selectNavigation("#" + menuId);
	    
	    $(_this).parents('.list').removeClass('active');
	    
	    if (href == "#") {
	    	e.preventDefault();
	        var $currentDepth = $(_this).parents('.select');
	        var childMenu = $currentDepth.next('.select').not('.disabled').find('.list.selected > li > a.active');
	        
	        if (childMenu.length > 0) {
	            var childHref = childMenu.attr('href');
	            if (childHref == "#") {
	                $(childMenu).trigger('click');
	            } else {
	                location.href = childHref;
	            }
	        }
	        return false;
	    }
	    
	}
	function selectNavigation(selectedMenu, menuIndex){ 
		var menuIndex = menuIndex || 1;
	    if ($(selectedMenu).length > 0) {
	        var menuText = $(selectedMenu).html();
	        $(selectedMenu).parents('.list').siblings('a').html(menuText);
	        $(selectedMenu).parents('.list').find('a').removeClass('active');
	        $(selectedMenu).addClass('active');
	        
	        var $depth = $(selectedMenu).parents('.select');
	        $('.select').removeClass('last-child');
	        var $childNavigation = $('#navigation .select').find('ul.list[data-menu-id="'+selectedMenu+'"]');
	        if ($childNavigation.length > 0) {
	            $depth.next('.select').removeClass('disabled');
	            $depth.next('.select').addClass('last-child');
	            $childNavigation.siblings(".list").removeClass('selected');
	            $childNavigation.addClass('selected');
	            
	            //251013 웹접근성 개선 : 하위 메뉴 있을 때 aria-haspopup과 aria-expanded 속성 추가[s]
	            //$depth.next('.select').children('a').attr('aria-haspopup', 'true');
	            $depth.next('.select').children('a').attr('aria-expanded', 'false');
	            $depth.children('a').attr('aria-expanded', 'false');
	            //251013 웹접근성 개선 : 하위 메뉴 있을 때 aria-haspopup과 aria-expanded 속성 추가[e]

	            if (menuIndex && !isNaN(menuIndex) ) {
	                var $childMenu = $childNavigation.children().eq(menuIndex - 1).find('a');
	                if ( $childMenu.length > 0 ){
	                    var childMenuText = $childMenu.html();
	                    $childMenu.parents('.list').siblings('a').html(childMenuText);
	                    $childMenu.parents('.list').find('a').removeClass('active');
	                    $childMenu.addClass('active');
	                }
	            }
	        } else {
	            $depth.addClass('last-child');
	            $depth.next('.select').addClass('disabled');
	          //250926 웹접근성 개선 : 의미 없는 빈 링크 제거 [s]
	            $depth.next('.select').children('a').remove();
	            $depth.next('.select').append('<span class="txt-body-3-400 font-gray00 bg-gray10 border-gray04" aria-hidden="true"> - </span>');
							const $panel = $depth.nextAll('.select').first();
							$panel.find('ul.list').first().attr('aria-label','하위 메뉴 없음(비활성)').removeAttr('aria-labelledby');
							//250926 웹접근성 개선 : 의미 없는 빈 링크 제거 [e]
							$depth.children('a').attr('aria-expanded', 'false'); //250922 웹접근성 : area-expended 상태 관리
	             
	        }
	    }
	}
	function initNavigation(depth1, depth2, menuIndex){
	    selectNavigation(depth1);
	    selectNavigation(depth2, menuIndex); 
	    
	    if ($('#navigation').length > 0) {
	        $('#navigation > .select > a').on('click', toggleNavigation);
	        $("#navigation .list a").on("click", clickMenu);
	        $("body").on("click", function(e){
	            if ($(e.target).parents('#navigation').length <= 0) {
	                $("#navigation .select > a").removeClass('active');
	                $("#navigation .select > ul").removeClass('active');
	                // 250922 웹접근성 개선 : 메뉴 닫힐 때 aria-expanded 상태 업데이트[s]
	                $("#navigation .select > a").attr('aria-expanded', 'false');
	                // 250922 웹접근성 개선 : 메뉴 닫힐 때 aria-expanded 상태 업데이트[e]
	            }
	        });
	    }
	}
		 
	
	//[s]: 2022-06-28
	//2. 서브 페이지에 추가 부탁드립니다.
	$('#sub-floating_menu').on('click', function(){
        if ($(this).hasClass('active')) {
            $(this).removeClass('active');
            $('#sub_floating').removeClass('active');
        } else {
            $(this).addClass('active');
            $('#sub_floating').addClass('active');
        }
    });
	//[e]: 2022-06-28
	
    function setTopBtn(){
        var mobileTopPos = $('#doc').height() - $(window).height() - $('#footer_area').height();
        var margin = 15;
        if ($('#footer_area').hasClass('footer-section')) {
            $('.footer-area #top_btn').css({
                "position": "absolute",
                "bottom": "30%",
            });
        } else {
            if ($(this).scrollTop() >= mobileTopPos) {
                $('.footer-area #top_btn').css({
                    "position": "absolute",
                    "bottom": $('#footer_area').height() + margin,
                });
                $('.footer-area #footer_floating').css({
                    "position": "absolute",
                    "bottom": $('#footer_area').height() + margin + 70,
                });
            } else {
                $('.footer-area #top_btn').css({
                    "position": "fixed",
                    "bottom": "3%",
                });
                $('.footer-area #footer_floating').css({
                	"position": "fixed",
                    "bottom": "11%",
                });
            }
        }
        
    }
    function initFooter(){
    	$('#top_btn, #main_top_btn').on('click', function(e){ 
            if ( $( 'html' ).hasClass( 'fp-enabled' ) ) {
                $.fn.fullpage.moveTo('display', 'news');
            } else {
                $( 'html, body' ).animate( { scrollTop : 0 }, 400 );
            }
        });

        if ($("#top_btn").parents('.footer-area').length >= 0) {
            setTopBtn();
            $(window).on("scroll resize", setTopBtn);
        }
    }
    $(function(){
        initFooter();
        
        $('#footer_floating_menu').on('click', function(){
            if ($(this).hasClass('active')) {
                $(this).removeClass('active');
                $('#footer_floating').removeClass('active');
            } else {
                $(this).addClass('active');
                $('#footer_floating').addClass('active');
            }
        });
    });
</script>
                </section> 

            </div>
    </div>
    <div class="floating main-floating" id="main_floating">
        <button class="floating-btn txt-button-500 popup" type="button" id="popup_link2">팝업존</button>
        <a class="floating-btn txt-button-500 recruit" href="https://career.nis.go.kr:4017" target="_blank" title="채용사이트 바로가기 새창">채용사이트</a>
        <!-- <a class="floating-btn txt-button-500 info" href="/CM/1_3/list.do">알림ㆍ소식</a> -->
        <a class="floating-btn txt-button-500 report" href="/CM/1_7_2.do"  title="111 신고">111 신고</a>
        <a class="floating-btn txt-button-500 facebook" href="http://www.facebook.com/National.Intelligence.Service" target="_blank" title="페이스북 바로가기 새창">페이스북</a>
        <a class="floating-btn txt-button-500 instagram" href="https://www.instagram.com/national.intelligence.service" target="_blank" title="인스타그램 바로가기 새창">인스타그램</a>
        <a class="floating-btn txt-button-500 cyber" href="https://www.ncsc.go.kr" target="_blank" style="text-align:center;" title="국가사이버안보센터 바로가기 새창">국가사이버<br>안보센터</a><!-- 211124 추가 -->
        <button class="floating-menu bg-primary" type="button" id="main_floating_menu" title="플로팅 메뉴"></button>
    </div>
    <button class="top-btn bg-primary txt-button-500" type="button" id="main_top_btn" alt="페이지 상단으로 이동"><span>TOP</span></button>

    <div class="mfp-hide white-popup-block" id="popup-layer" role="dialog" aria-modal="true" aria-labelledby="popup_title">
        <div class="popup-wrapper">
        	<p class="invisible" id="popup_title">팝업존</p>
        	<!-- 241015 a태그 타이틀 추가 -->
            <div class="popup-content" id="popup_content">
            	
            	
            	
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=415"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국가정보원, 육군과<br/> ‘드론안보 협력 업무협약’ 체결</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=550FDDEC98912382457F07DC229064F0" alt="국가정보원, 육군과 ‘드론안보 협력 업무협약’ 체결" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=414"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원, 신임 「북한이탈주민보호센터」 인권보호관 위촉</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=0E64AD439DF1911C87107DACA908476E" alt="국정원, 신임 「북한이탈주민보호센터」 인권보호관 위촉" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=413"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원,<br/> ‘2026 국가안보 논문ㆍ<br/>아이디어 공모전’ 개최</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=23D1555967EC94AD24CF4639D7826C26" alt="국정원, ‘2026 국가안보 논문ㆍ아이디어 공모전’ 개최" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=412"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원,<br/> ‘2025년 테러정세ㆍ<br/>2026년 전망’ 책자 발간</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=249BC4C67E38B4D974553740BF70D73C" alt="국정원, ‘2025년 테러정세ㆍ2026년 전망’ 책자 발간" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=411"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원ㆍ과기정통부,<br/> 공공 클라우드 시장 진입 절차<br/> 개선방안 발표</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=5450704F319C00813EDD0AA951E2E507" alt="국정원ㆍ과기정통부, 공공 클라우드 시장 진입 절차 개선방안 발표" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=410"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원,<br/> 세계 최대 사이버방어 훈련<br/> ‘락드쉴즈 2026’ 참가</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=F86F301F308C74076C9865A73E796210" alt="국정원, 세계 최대 사이버방어 훈련 ‘락드쉴즈 2026’ 참가" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=409"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원-국가정보학회, <br/>「드론과 미래안보 컨퍼런스」 개최</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=C5EE942A0717A538E1499E3EC774FAF9" alt="국정원-국가정보학회, 「드론과 미래안보 컨퍼런스」 개최" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=406"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원, 태국 정부 요청 태국인 초대형 마약상 검거ㆍ추방 지원</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=3B77B260EC5A1014457421B2EA51E22D" alt="국정원, 태국 정부 요청 태국인 초대형 마약상 검거ㆍ추방 지원" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=405"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원, 배우 현빈을 <br/>'명예 방첩요원'에 위촉</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=1EEE19C4CB9A32C791327C9211167D6E" alt="국정원, 배우 현빈을 &#039;명예 방첩요원&#039;에 위촉" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=403"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원, ‘지능형 전력망 사이버보안 가이드라인’ 발표</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=9CC638B46D8AB6B9879EC3F42FB3F1B3" alt="국정원, ‘지능형 전력망 사이버보안 가이드라인’ 발표" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=402"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원, ‘중동 상황’ 관련<br/> 외국발 허위정보 대응에 만전</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=1C7F8757B3BFF769B7DA212E5C961A56" alt="국정원, ‘중동 상황’ 관련 외국발 허위정보 대응에 만전" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=401"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원, 중동 현지<br/> ‘우리 국민 보호ㆍ기업 안전’ <br/>다각 지원</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=95B9AC4E196517697F57938EB173211C" alt="국정원, 중동 현지 ‘우리 국민 보호ㆍ기업 안전’ 다각 지원" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=400"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원, 해외사이버안보기관과<br/>「AI 공급망위험ㆍ완화방안」<br/> 공동발표</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=B1145CFA5BDC37459FE7FBC88BAEFC6B" alt="국정원, 해외사이버안보기관&lt;br/&gt;「AI 공급망위험ㆍ완화방안」 공동발표" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=399"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>국정원, ‘중동 상황’ 대응에 정보역량 총동원</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=75AF35AED6ACCAA0ACA79FBC61F5489B" alt="국정원, ‘중동 상황’ 대응에 정보역량 총동원" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
				    
					    
				           <a class="card-wrapper"  href="https://www.nis.go.kr:4016/CM/1_4/view.do?seq=398"   target="_self" title="바로가기"   >
				        
				        
		                    <div class="card">
		                        <div class="card-top">
		                            <div class="background-overlay bg-light-black"></div>
		                            <div class="card-header">
		                                <div class="logo">
		                                    <img src="/resources/img/renewal_images/logo_nis_text.png" alt="NIS">
		                                </div>
		                                
		                            </div>
		                            <div class="card-title txt-heading-3-500">
		                                <p>‘간첩죄 개정’ 관련<br/> 국가정보원 입장</p>
		                            </div>
		                        </div>
		                        <div class="card-bottom">
		                            <div class="card-image">
		                                <img src="/common/download2.do?seq=4492457D54F1F28B099C0129AB80F256" alt="‘간첩죄 개정’ 관련 국가정보원 입장" >
		                            </div>
		                        </div>
		                    </div>
		                </a>
	                
			    
            </div>
            <div class="popup-btns">
                <button type="button" class="popup-btn txt-button-500" onclick="closePopupToday();">오늘 하루 열지 않기</button>
                <button type="button" class="popup-btn close txt-button-500" id="popup_close" onclick="closePopup();">닫기</button>
            </div>
        </div>
    </div>
    <script type="text/javascript" src="/resources/assets/vendor/fullPage/jquery.fullPage.js?v=2.9.6"></script>
	<script type="text/javascript" src="/resources/assets/vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
	<script type="text/javascript" src="/resources/assets/vendor/slick/slick.min.js?v=1.8.5"></script>
    <script type="text/javascript" src="/resources/js/js_renewal/main.js?v=1.0.7"></script>
	<script type="text/javascript">
//		window.open("https://www.nis.go.kr:4016/CM/1_3/view.do?seq=378", "popup", "top=100,left=200,height=900,width=600");
		
		setTimeout(function(){
			
			$('p:contains("국가정보원 홈페이지 개편 안내")').css('font-size','19pt').css('font-weight','bold').css('color','rgb(243, 187, 165)')
	
		},300);
	
		function videoPlay() {
			$('.desktop-video').get(0).play();
		}
		
		function videoStop() {
			$('.desktop-video').get(0).pause();
		}
		$("#sub_floating").remove();
 	
		$(document).on("keydown", function(e) { 
			
	        if(e.keyCode == "9") { // tab키
	          //백탭
	          if(e.shiftKey) { //+ shift키
	            if($(".news .sns .card-image > a").is(":focus")) {
	              $.fn.fullpage.moveTo(1); 
	              $(".display .scroll-down-btn").attr("tabindex", 0).show().focus();
	              // 이전 섹션의 포커스 가능한 마지막 요소의 tabindex 지정, 포커스한다. 
	            }
	            
	            if($(".about .slider-wrapper:nth-child(1) .image-card").is(":focus")) {
	              $.fn.fullpage.moveTo(2);
	              $(".news .press .card-footer .more-link").attr("tabindex", 0).show().focus();
	            }
	            if($(".career .content-text .more-link:nth-child(1)").is(":focus")) {
	              $.fn.fullpage.moveTo(3);
	              $(".about .slider-wrapper:nth-child(3) .image-card").attr("tabindex", 0).show().focus();
	            }
	           /*
	            if($(".footer-content .menu:nth-child(2) a").is(":focus")) {
	              $.fn.fullpage.moveTo(4);
	              $(".career .content-text .more-link:nth-child(2)").attr("tabindex", 0).show().focus();
	            }
	            */
	          } else {
	            //탭
	            if($(".display .scroll-down-btn").is(":focus")) {
	              $.fn.fullpage.moveTo(2);
	            }
	            if($(".news .press .more-link").is(":focus")) {
	              $.fn.fullpage.moveTo(3);
	            }
	            
	            if($(".about .image-card:nth-child(3)").is(":focus")) {
	              $.fn.fullpage.moveTo(4);
	            }
	           	/*
	            if($(".career .career-btns .more-link:nth-of-type(n+2)").is(":focus")) {
	              $.fn.fullpage.moveTo(5);
	            } 
	            */
	          }
	        }
	   }); 
		sessionStorage.clear();	
		$("#main_top_btn").css("right","140px")
	</script>
	
</body>

</html>
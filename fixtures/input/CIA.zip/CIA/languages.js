/**************************************************************************************
 * File: languages.js
 * This contains the sample language definitions for the form display
 *   Each field supports HTML
 */

var SupportedLanguages = {
    version: "001001-0110",
    /** Stores the HTML Label Element IDs to modify the displayed text */
    metadata: {
        dialogDescr: { labelId: "dialog-description" },
        message:     { labelId: "mlabel" },
        email:       { labelId: "elabel" },
        name:        { labelId: null},
        phone_cc:    { labelId: null},
        phone:       { labelId: "phone_label" },
        cellcc:      { labelId: null},
        cellnumber:  { labelId: "mobile_label" },
        submit:      { labelId: "submitFormButton" }, // .first.first.innerHTML
        reset:       { labelId: "submitFormButton" }, // .parent.last.value
    },

    /** English */
    en: {
        right2left:           false,
        dialogDescr:          "Use this form to contact us or report information",
        message: {
            label:                "Message &nbsp; <i>Characters Remaining: &nbsp;</i>",
            placeholder:          "Message text",
            errmsg:               null
        },
        email: {
            label:                "Email",
            placeholder:          "user@email.com",
            errmsg:               null
        },
        name: {
            label:                "Full Name (Optional)",
            placeholder:          "First and last name",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "Country code",
            errmsg:               null
        },
        phone: {
            label:                "Phone Number (Optional)",
            placeholder:          "Number",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "Country code",
            errmsg:               null
        },
        cellnumber: {
            label:                "Mobile or Cell Number (Optional)",
            placeholder:          "Number",
            errmsg:               null
        },
        banner: {
            default:              ("Your security and well-being are our primary concerns. By visiting this website from outside of the U.S. and contacting us, you may be subject to monitoring by security or intelligence services, or other third parties that do not adhere to U.S. Internet privacy laws. While we employ numerous safeguards to help minimize this risk, we suggest that you not use your home or work computer to contact us. Use instead a computer where you are entirely unknown. Although our website is encrypted, it is still possible for others to see that you have visited CIA.gov. As an added precaution, we recommend you use current web browsers and clean the computer's search and/or browser histories after you visit the website.<br />"),
            prepend:              "",
            override:             null
        },
        refid:                "Submission Reference ID",
        submit:               "SEND",
        reset:                "Clear",
        popup: {
            Title:                "Submission",
            HeaderSent:           "Sent",
            HeaderFailed:         "Failed",
            Sent:                 "",
            Failed:               "There was a problem contacting the server. Please try again later.",
            AutoClose:            "<i>Automatically closing in</i>&nbsp;",
            Close:                "Close"
        },
        error: {
            MissingMsgAndEmail:   "Please enter a valid Email address and fill out the Message field!",
            MissingEmailField:    "Please enter a valid Email address!",
            MissingMsgField:      "Please fill out the Message field!",
            MaxMsgSize:           "Max message size reached. To include more, please send an additional message."
        }
    },

    /** Arabic */
    ar: {
        right2left:           true,
        dialogDescr:          "استخدم هذا النموذج للاتصال بنا أو الإبلاغ عن المعلومات",
        message: {
            label:                "الرسالة &nbsp; <i>الأحرف المتبقية: &nbsp;</i>",
            placeholder:          "رسالة نصية",
            errmsg:               null
        },
        email: {
            label:                "بريد إلكتروني",
            placeholder:          "مستخدم@بريد إلكتروني.com",
            errmsg:               null
        },
        name: {
            label:                "الاسم الكامل (اختياري)",
            placeholder:          "الاسم الأول وأسم الجد",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "الرقم الدولي",
            errmsg:               null
        },
        phone: {
            label:                "رقم الهاتف (اختيارى)",
            placeholder:          "الرقم",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "الرقم الدولي",
            errmsg:               null
        },
        cellnumber: {
            label:                "رقم المحمول أو الجوال (اختياري)",
            placeholder:          "الرقم",
            errmsg:               null
        },
        banner: {
            default:              ("همنا الاساسي هو أمنكم ورفاهيتكم. من خلال زيارة هذا الموقع من خارج الولايات المتحدة والاتصال بنا قد تخضع للمراقبة من قبل أجهزة الأمن أو الاستخبارات أو أطراف ثالثة أخرى لا تلتزم بقوانين خصوصية الإنترنت الأمريكية. بينما نستخدم العديد من الضمانات للمساعدة في تقليل هذا الخطر، نقترح عليك عدم استخدام الكمبيوتر الشحصي أو كمبيوترالعمل للاتصال بنا. استخدم بدلا من ذلك جهاز كمبيوتر غيرمرتبط بك تماما. على الرغم من أن موقعنا مشفر إلا أنه لا يزال من الممكن للآخرين أن يروا أنك زرت  CIA.gov  كإجراء وقائي إضافي نوصي باستخدام متصفحات الويب المحدثة وتنظيف سجل البحث بعد زيارة الموقع."),
            prepend:              "",
            override:             null
        },
        refid:                "معرّف مرجع الإرسال",
        submit:               "أرسل",
        reset:                "مسح",
        popup: {
            Title:                "إرسال",
            HeaderSent:           "تم إرساله",
            HeaderFailed:         "فشل",
            Sent:                 "",
            Failed:               "حدثت مشكلة في الاتصال بالخادم. الرجاء معاودة المحاولة في وقت لاحق.",
            AutoClose:            "<i>يتم الإغلاق تلقائيًا</i>&nbsp;",
            Close:                "أغلق"
        },
        error: {
            MissingMsgAndEmail:   "الرجاء إدخال عنوان بريد إلكتروني صالح وملء خانة الرسالة!",
            MissingEmailField:    "الرجاء إدخال عنوان بريد إلكتروني صالح!",
            MissingMsgField:      "الرجاء ملء خانة الرسالة!",
            MaxMsgSize:           "تم الوصول إلى أقصى حجم للرسالة. لتوفير معلومات أكثر الرجاء القيام ببعث رسالة أخري."
        }
    },

    /** Chinese-Traditional */
    "zh-TW": {
        right2left:           false,
        dialogDescr:          "使用此表格聯繫我們或報告信息",
        message: {
            label:                "<i>剩餘字數: &nbsp;</i>",
            placeholder:          "信息内容",
            errmsg:               null
        },
        email: {
            label:                "電子郵件",
            placeholder:          "用戶名@電子郵件.com",
            errmsg:               null
        },
        name: {
            label:                "全名 (選項)",
            placeholder:          "名字和姓氏",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "電話號碼",
            errmsg:               null
        },
        phone: {
            label:                "電腦號碼 (選填)",
            placeholder:          "國碼",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "國碼",
            errmsg:               null
        },
        cellnumber: {
            label:                "手機號碼 (選填)",
            placeholder:          "手機號碼",
            errmsg:               null
        },
        banner: {
            default:              ("您的安全與福祉是我們的首要考量。在美國境外使用此網站與我們聯繫，您可能會受到安全機關或情報機構，或不受美國安全法規約束的第三方監視。雖然我們采用了多項安全措施來降低風險，但我們建議您不要使用家中或工作用的電腦與我們聯繫。請使用與您毫無任何關聯的電腦。雖然我們的網站已經加密，但他人仍然有可能發現您造訪了我們的網站。爲了以防萬一，請您在瀏覽本網站后，清除瀏覽器與電腦的搜尋歷史。"),
            prepend:              "",
            override:             null
        },
        refid:                "提交編號",
        submit:               "發送",
        reset:                "清除",
        popup: {
            Title:                "提交",
            HeaderSent:           "已發送",
            HeaderFailed:         "失敗",
            Sent:                 "",
            Failed:               "系統有誤，請稍後再試。",
            AutoClose:            "<i>自動關閉</i>&nbsp;",
            Close:                "關閉"
        },
        error: {
            MissingMsgAndEmail:   "請輸入正確的電子郵件地址並填寫信息！",
            MissingEmailField:    "請輸入正確的電子郵件地址！",
            MissingMsgField:      "請填寫信息内容！",
            MaxMsgSize:           "字限超過。請縮短或分成兩條信息發送。"
        }
    },

    /** Chinese */
    zh: {
        right2left:           false,
        dialogDescr:          "使用此表格与我们联系或报告信息",
        message: {
            label:                "<i>剩余字数： &nbsp;</i>",
            placeholder:          "信息内容",
            errmsg:               null
        },
        email: {
            label:                "电子邮件",
            placeholder:          "用户名@电子邮件.com",
            errmsg:               null
        },
        name: {
            label:                "全名（选填）",
            placeholder:          "名字和姓氏",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "电话号码",
            errmsg:               null
        },
        phone: {
            label:                "电话号码（选填）",
            placeholder:          "国码",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "国码",
            errmsg:               null
        },
        cellnumber: {
            label:                "手机号码（选填）",
            placeholder:          "手机号码",
            errmsg:               null
        },
        banner: {
            default:              ("您的安全与福祉是我们的首要考量。 在美国境外使用此网站与我们联系，您可能会受到安全机关或情报机构，或不受美国安全法规约束的第三方监视。 虽然我们采用了多项安全措施来降低风险，但我们建议您不要使用家中或工作用的电脑与我们联系。 请使用与您毫无任何关联的电脑。 虽然我们的网站已经加密，但他人仍然有可能发现您访问了我们的网站。 为了以防万一，请您在浏览本网站后，清除浏览器与电脑的搜寻历史。"),
            prepend:              "",
            override:             null
        },
        refid:                "提交编号",
        submit:               "发送",
        reset:                "清除",
        popup: {
            Title:                "提交",
            HeaderSent:           "已发送",
            HeaderFailed:         "失败",
            Sent:                 "",
            Failed:               "系统有误，请稍后再试。",
            AutoClose:            "<i>自动关闭</i>&nbsp;",
            Close:                "关闭"
        },
        error: {
            MissingMsgAndEmail:   "请输入正确的电子邮件地址并填写信息！",
            MissingEmailField:    "请输入正确的电子邮件地址！",
            MissingMsgField:      "请填写信息内容！",
            MaxMsgSize:           "字限超过。请缩短或分成两条信息发送。"
        }
    },

    /** French */
    fr: {
        right2left:           false,
        dialogDescr:          "Utilisez ce formulaire pour nous contacter ou signaler des informations",
        message: {
            label:                "<i>Nombre de caractères restants pour ce message: &nbsp;</i>",
            placeholder:          "Texte du message",
            errmsg:               null
        },
        email: {
            label:                "E-mail",
            placeholder:          "utilisateur@email.fr",
            errmsg:               null
        },
        name: {
            label:                "Nom (optionnel)",
            placeholder:          "Prénom et nom",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "Code du pays",
            errmsg:               null
        },
        phone: {
            label:                "Numéro de téléphone (optionnel)",
            placeholder:          "Numéro",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "Code du pays",
            errmsg:               null
        },
        cellnumber: {
            label:                "Numéro de téléphone portable (optionel)",
            placeholder:          "Numéro",
            errmsg:               null
        },
        banner: {
            default:              (" "),
            prepend:              "",
            override:             null
        },
        refid:                "Numéro d’identification de la soumission",
        submit:               "ENVOYER",
        reset:                "Réinitialiser",
        popup: {
            Title:                "Soumission",
            HeaderSent:           "Envoyé",
            HeaderFailed:         "Erreur",
            Sent:                 "",
            Failed:               "Un problème est survenu lors du contacte avec le serveur. Veuillez réessayer ultérieurement.",
            AutoClose:            "<i>Fermeture automatique</i>&nbsp;",
            Close:                "Fermer"
        },
        error: {
            MissingMsgAndEmail:   "Veuillez saisir une adresse e-mail valide et remplir le champ du Message!",
            MissingEmailField:    "Veuillez saisir une adresse e-mail valide!",
            MissingMsgField:      "Veuillez remplir le champ du Message!",
            MaxMsgSize:           "Taille maximale du message atteinte. Pour ajouter plus d'information, veuillez envoyer un message supplémentaire."
        }
    },

    /** German */
    de: {
        right2left:           false,
        dialogDescr:          "Benutzen sie dieses Formular zur Kontakaufnahme",
        message: {
            label:                "<i>Verbleibende Nachrichtenzeichen: &nbsp;</i>",
            placeholder:          "Text",
            errmsg:               null
        },
        email: {
            label:                "Email",
            placeholder:          "Benutzer@email.com",
            errmsg:               null
        },
        name: {
            label:                "Namen (optional)",
            placeholder:          "Vor-und Nachname",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "Landesvorwahl",
            errmsg:               null
        },
        phone: {
            label:                "Telefonnummer (optional)",
            placeholder:          "Nummer",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "Landesvorwahl",
            errmsg:               null
        },
        cellnumber: {
            label:                "Mobiltelefonnummer (optional)",
            placeholder:          "Nummer",
            errmsg:               null
        },
        banner: {
            default:              ("Ihre Sicherheit und Wohlergehen sind uns äusserst wichtig.   Da Sie sich auf dieser Webseite ausserhalb der USA  mit uns in Verbindung gesetzt haben, könnten Sie die möglicherweise von Sicherheits- oder Nachrichtendiensten oder auch weiteren Einheiten überwacht werden, die sich nicht an die US Internet Datenschutzgesetze halten.   Trotz umfangreicher Sicherungsmassnahmen dieses Risiko zu vermeiden raten wir Ihnen, Ihren Privat- oder Bürorechner nicht zur Kontaktaufnahme zu benutzen.  Obwohl unsere Webseite verschluesselt ist, kann Ihr Besuch bei CIA.gov bekannt werden.  Als weitere Vorsichtsmassnahmen empfehlen wir aktuelle Internetbrowser zu benutzen und die Such- und/oder Browserverläufe zu löschen."),
            prepend:              "",
            override:             null
        },
        refid:                "Referennznummer",
        submit:               "SCHICKEN",
        reset:                "Löschen",
        popup: {
            Title:                "Einsendung",
            HeaderSent:           "Gesendet",
            HeaderFailed:         "Erfolglos",
            Sent:                 "",
            Failed:               "Problem mit Serverkontakt. Bitte spaeter veruchen.",
            AutoClose:            "<i>Autoclose</i>&nbsp;",
            Close:                "Schliessen"
        },
        error: {
            MissingMsgAndEmail:   "Bitte aktuelle Emailadresse angeben und Nachrichtenfeld ausfüllen!",
            MissingEmailField:    "Bitte aktuelle Emailadresse angeben!",
            MissingMsgField:      " Bitte Nachrichtenfeld ausfüllen!",
            MaxMsgSize:           "Maximale Grösse erreicht. Für weitere Informationen schicken Sie bitte eine weitere Nachricht!"
        }
    },

    //** Korean */
    ko: {
        right2left:           false,
        dialogDescr:          "이 양식을 사용하여 우리에게 연락하거나 정보를 보고하십시오.",
        message: {
            label:                "<i>남아있는 문자수: &nbsp;</i>",
            placeholder:          "문의 내용",
            errmsg:               null
        },
        email: {
            label:                "이메일",
            placeholder:          "사영자@도베인.com",
            errmsg:               null
        },
        name: {
            label:                "이름(선택)",
            placeholder:          "성명",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "국가 코드",
            errmsg:               null
        },
        phone: {
            label:                "연락처 (선택)",
            placeholder:          "전화번호",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "국가 코드",
            errmsg:               null
        },
        cellnumber: {
            label:                "휴대 전화",
            placeholder:          "휴대 전화번호",
            errmsg:               null
        },
        banner: {
            default:              (" "),
            prepend:              "",
            override:             null
        },
        refid:                "제출참조 아이디",
        submit:               "제출",
        reset:                "리셋",
        popup: {
            Title:                "제출",
            HeaderSent:           "전달",
            HeaderFailed:         "에러",
            Sent:                 "",
            Failed:               "서버에 접속하는데 문제가 발생했습니다. 나중에 다시 시도하세요.",
            AutoClose:            "<i>자동 닫기</i>&nbsp;",
            Close:                "닫기"
        },
        error: {
            MissingMsgAndEmail:   "유로한 이메일 주소랑 문의 내용을 입력하십시오!",
            MissingEmailField:    "유로한 이메일 주소를 입력하십시오!",
            MissingMsgField:      "문의 내용을 입력하십시오!",
            MaxMsgSize:           "최대 문자수에 도달했습니다. 더 포함하려면 추가 메세지를 보내십시오."
        }
    },

    /** Persian */
    fa: {
        right2left:           true,
        dialogDescr:          "این فرم را برای تماس با ما و یا گزارش اطلاعات به کار ببرید.",
        message: {
            label:                "<i>تعداد کاراکتر های باقی مانده از پیام : &nbsp;</i>",
            placeholder:          "متن پیام",
            errmsg:               null
        },
        email: {
            label:                "ایمیل",
            placeholder:          "کاربر@ایمیل.کام ",
            errmsg:               null
        },
        name: {
            label:                "اسم کامل (اختیاری)",
            placeholder:          "اسم و اسم خانوادگی",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "کد کشور",
            errmsg:               null
        },
        phone: {
            label:                "شماره تلفن (اختیاری)",
            placeholder:          "شماره",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "کد کشور",
            errmsg:               null
        },
        cellnumber: {
            label:                "شماره موبایل و یا تلفن همراه (اختیاری)",
            placeholder:          "شماره",
            errmsg:               null
        },
        banner: {
            default:              (" "),
            prepend:              "",
            override:             null
        },
        refid:                "شناسه مرجع ارسال",
        submit:               "بفرستید",
        reset:                "پاک کنید",
        popup: {
            Title:                "ارسال",
            HeaderSent:           "فرستاد",
            HeaderFailed:         "ناموفق",
            Sent:                 "",
            Failed:               "مشکلی در تماس با سرور پیش آمد. لطفا بعدا دوباره تلاش کنید.",
            AutoClose:            "<i>به طور خودکار خاتمه می یابد و یا بسته می شود.</i>&nbsp;",
            Close:                "ببندید"
        },
        error: {
            MissingMsgAndEmail:   "لطفا آدرس یک ایمیل معتبر را وارد کنید و محل پیام را  پر کنید!",
            MissingEmailField:    "لطفا  آدرس یک ایمیل معتبر را  وارد کنید!",
            MissingMsgField:      "لطفا محل پیام را پر کنید!",
            MaxMsgSize:           "محل گنجایش پیامک پر شده است. لطفا برای گنجاندن مطالب بیشتر، یک پیام دیگر بفرستید."
        }
    },

    /** Russian */
    ru: {
        right2left:           false,
        dialogDescr:          "Используйте эту форму, чтобы связаться с нами или сообщить информацию",
        message: {
            label:                "<i>Осталось Символов: &nbsp;</i>",
            placeholder:          "Текст Сообщения",
            errmsg:               null
        },
        email: {
            label:                "Электронная Почта",
            placeholder:          "Имя пользователя@email.com",
            errmsg:               null
        },
        name: {
            label:                "Полное Имя (Необязательно)",
            placeholder:          "Имя и Фамилия",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "Код Страны",
            errmsg:               null
        },
        phone: {
            label:                "Номер Телефона (Необязательно)",
            placeholder:          "Номер Телефона",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "Код Страны",
            errmsg:               null
        },
        cellnumber: {
            label:                "Номер Мобильного Телефона (Необязательно)",
            placeholder:          "Номер Мобильного Телефона",
            errmsg:               null
        },
        banner: {
            default:              ("Ваша безопасность и благополучие являются нашими основными заботами. Посещая этот веб-сайт из-за пределов США и связываясь с нами, вы можете подвергаться мониторингу со стороны служб безопасности или разведки или других третьих лиц, которые не соблюдают законы США о конфиденциальности в Интернете. Хотя мы используем многочисленные меры предосторожности, чтобы помочь свести этот риск к минимуму, мы предлагаем вам не использовать свой домашний или рабочий компьютер, чтобы связаться с нами. Вместо этого используйте компьютер, где вы совершенно неизвестны. Наш веб-сайт зашифрован, но другие все еще могут видеть, что вы посетили CIA.gov. В качестве дополнительной меры предосторожности мы рекомендуем вам использовать обновленные веб-браузеры и очищать поиск компьютера и / или историю браузера после посещения веб-сайта."),
            prepend:              "",
            override:             null
        },
        refid:                "Идентификатор Отправки",
        submit:               "Отправить",
        reset:                "Сбросить",
        popup: {
            Title:                "Подача",
            HeaderSent:           "Отправлена",
            HeaderFailed:         "Не удалась",
            Sent:                 "",
            Failed:               "Возникла проблема с подключением к серверу. Повторите попытку позже.",
            AutoClose:            "<i>Автоматическое закрытие через …</i>&nbsp;",
            Close:                "Закрыть"
        },
        error: {
            MissingMsgAndEmail:   "Пожалуйста, введите действительный адрес электронной почты и заполните поле Сообщение!",
            MissingEmailField:    "Пожалуйста, введите действительный адрес электронной почты",
            MissingMsgField:      "Пожалуйста, заполните поле Сообщение!",
            MaxMsgSize:           "Сообщение достигло максимального размера. Чтобы добавить дополнительные сведения, отправьте дополнительное сообщение."
        }
    },

    /** Spanish */
    es: {
        right2left:           false,
        dialogDescr:          "Use este formulario para contactarnos o informar la información",
        message: {
            label:                "Mensaje &nbsp; <i>Caracteres restante: &nbsp;</i>",
            placeholder:          "Mensaje de texto",
            errmsg:               null
        },
        email: {
            label:                "Correo electrónico",
            placeholder:          "usuario@correo_electrónico.com",
            errmsg:               null
        },
        name: {
            label:                "Nombre completo (opcional)",
            placeholder:          "Nombre y apellido",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "Código de país",
            errmsg:               null
        },
        phone: {
            label:                "Numero de teléfono (opcional)",
            placeholder:          "Número",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "Código de país",
            errmsg:               null
        },
        cellnumber: {
            label:                "Número móvil o celular (opcional)",
            placeholder:          "Número",
            errmsg:               null
        },
        banner: {
            default:              ("Su seguridad y bienestar son nuestras principales preocupaciones. Al visitar este sitio web desde fuera de los EE. UU. y comunicarse con nosotros, puede estar sujeto a monitoreo por parte de servicios de seguridad o inteligencia, u otros terceros que no cumplan con las leyes de privacidad de Internet de los EE. UU. Si bien empleamos numerosas medidas de seguridad para ayudar a minimizar este riesgo, le sugerimos que no utilice la computadora de su casa o del trabajo para comunicarse con nosotros. Utilice en su lugar una computadora en la que sea completamente desconocido. Aunque nuestro sitio web está encriptado, aún es posible que otros vean que usted ha visitado CIA.gov. Como precaución adicional, le recomendamos que utilice los navegadores web actuales y limpie los historiales de búsqueda y/o del navegador de su computadora después de visitar el sitio web.<br />"),
            prepend:              "",
            override:             null
        },
        refid:                "ID de Referencia de Envío",
        submit:               "ENVIAR",
        reset:                "Borrar",
        popup: {
            Title:                "Envío",
            HeaderSent:           "Enviado",
            HeaderFailed:         "Fallido",
            Sent:                 "",
            Failed:               "Hubo un problema en contactar al servidor. Por favor, inténtelo de nuevo más tarde.",
            AutoClose:            "<i>Cerrando automáticamente</i>&nbsp;",
            Close:                "Finalizar"
        },
        error: {
            MissingMsgAndEmail:   "¡Ingrese una dirección de correo electrónico válida y complete el campo de mensaje!",
            MissingEmailField:    "¡Por favor, introduce una dirección de correo electrónico válida!",
            MissingMsgField:      "¡Complete el campo de mensaje!",
            MaxMsgSize:           "El tamaño de mensaje máximo alcanzado. Acorta o divide en dos mensajes."
        }
    },

    /** Ukrainian */
    uk: {
        right2left:           false,
        dialogDescr:          "Використовуйте цю форму, щоб зв'язатися з нами або повідомити інформацію",
        message: {
            label:                "<i>Залишилося символів: &nbsp;</i>",
            placeholder:          "Текст Повідомлення",
            errmsg:               null
        },
        email: {
            label:                "Електронна Пошта",
            placeholder:          "Ім'я користувача@email.com",
            errmsg:               null
        },
        name: {
            label:                "Повне Ім'я (Необов'язково)",
            placeholder:          "Ім'я та Прізвище",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "Код Країни",
            errmsg:               null
        },
        phone: {
            label:                "Номер Телефону (Необов'язково)",
            placeholder:          "Номер Телефона",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "Код Країни",
            errmsg:               null
        },
        cellnumber: {
            label:                "Номер Мобільного Телефону  (Необов'язково)",
            placeholder:          "Номер Мобильного Телефону",
            errmsg:               null
        },
        banner: {
            default:              ("Ваша безпека і благополуччя є нашою першочерговою турботою. Відвідуючи цей веб-сайт за межами США та зв'язуючись з нами, ви можете підлягати моніторингу службами безпеки або розвідки або іншими третіми особами, які не дотримуються законів США про конфіденційність в Інтернеті. Хоча ми використовуємо численні гарантії, щоб допомогти мінімізувати цей ризик, ми пропонуємо вам не використовувати свій домашній або робочий комп'ютер, щоб зв'язатися з нами. Замість цього використовуйте комп'ютер, де ви абсолютно невідомі. Наш веб-сайт зашифрований, але інші все ще можуть бачити, що ви відвідали CIA.gov. Як додатковий запобіжний захід ми рекомендуємо використовувати оновлені веб-браузери та очищати історію пошуку та / або браузера комп'ютера після відвідування веб-сайту."),
            prepend:              "",
            override:             null
        },
        refid:                "Ідентифікатор Посилання",
        submit:               "Надіслати",
        reset:                "Скинути",
        popup: {
            Title:                "Подання",
            HeaderSent:           "Надіслано",
            HeaderFailed:         "Не вдалося",
            Sent:                 "",
            Failed:               "Сталася помилка під час звернення до сервера. Повторіть спробу пізніше.",
            AutoClose:            "<i>Автоматичне закриття через …</i>&nbsp;",
            Close:                "Закрити"
        },
        error: {
            MissingMsgAndEmail:   "Будь ласка, введіть дійсну адресу електронної пошти та заповніть поле Повідомлення!",
            MissingEmailField:    "Будь ласка, введіть дійсну адресу електронної пошти",
            MissingMsgField:      "Будь ласка, Заповніть поле Повідомлення!",
            MaxMsgSize:           "Повідомлення досягло максимального розміру. Щоб додати більше, надішліть додаткове повідомлення."
        }
    },
 
    /** Vietnamese */
    vi: {
      right2left:           false,
        dialogDescr:          "Dùng mẫu đơn này để liên hệ với chúng tôi hoặc báo tin.",
        message: {
            label:                "<i>Ký tự còn lại của tin nhắn: &nbsp;</i>",
            placeholder:          "Nội dung của tin nhắn",
            errmsg:               null
        },
        email: {
            label:                "E-mail",
            placeholder:          "người dùng@email.com",
            errmsg:               null
        },
        name: {
            label:                "Họ tên đầy đủ (Không bắt buộc)",
            placeholder:          "Họ và tên",
            errmsg:               null
        },
        phone_cc: {
            label:                null,
            placeholder:          "Mã Quốc gia",
            errmsg:               null
        },
        phone: {
            label:                "Số điện thoại (Không bắt buộc)",
            placeholder:          "Số điện thoại",
            errmsg:               null
        },
        cellcc: {
            label:                null,
            placeholder:          "Mã Quốc gia",
            errmsg:               null
        },
        cellnumber: {
            label:                "Số điện thoại di động (Không bắt buộc)",
            placeholder:          "Số điện thoại",
            errmsg:               null
        },
        banner: {
            default:              (" "),
            prepend:              "",
            override:             null
        },
        refid:                "Số nhận dạng tham khảo sau khi nộp",
        submit:               "Gửi",
        reset:                "Xóa",
        popup: {
            Title:                "Nộp",
            HeaderSent:           "Đã gửi",
            HeaderFailed:         "Thất bại",
            Sent:                 "",
            Failed:               "Có sự cố khi liên lạc với máy chủ. Xin vui lòng thử lại sau.",
            AutoClose:            "<i>Tự động đóng</i>&nbsp;",
            Close:                "đóng"
        },
        error: {
            MissingMsgAndEmail:   "Vui lòng nhập địa chỉ E-mail hợp lệ và điền thông tin vào chỗ dành cho Tin nhắn!",
            MissingEmailField:    "Vui lòng nhập địa chỉ Email hợp lệ!",
            MissingMsgField:      "Vui lòng điền thông tin vào chỗ dành cho Tin nhắn!",
            MaxMsgSize:           "Đã đạt đến kích thước tối đa của tin nhắn. Để bao gồm thêm, xin vui lòng gửi tin nhắn bổ sung."
        }
    }
};
/**********************************************************************************************************************/

